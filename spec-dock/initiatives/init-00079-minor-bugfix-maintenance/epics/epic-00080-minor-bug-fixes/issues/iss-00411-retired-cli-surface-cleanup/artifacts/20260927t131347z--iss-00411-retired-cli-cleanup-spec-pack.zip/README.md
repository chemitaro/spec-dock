# iss-00411 retired CLI cleanup specification pack

## このパックについて

GitHub Issue #411 **Remove retired SpecDock CLI surfaces after scope active work cutover** の実装着手用仕様パックです。コード変更、GitHub Issue / PR 更新、commit、他 worktree / consumer の更新は行っていません。

このパックは、connected GitHub repository の次の source snapshot を厳密に確認した上で作成しました。

| 項目 | 値 |
|---|---|
| Repository | `chemitaro/spec-dock` |
| Branch | `iss-00411-retired-cli-surface-cleanup` |
| Full tip SHA | `d7c816d11bee1a73cb87273b15e486c3b669206c` |
| Issue | `#411` |
| Related cutover | Issue `#409`, PR `#410` |
| Parent | `epic-00080`, `init-00079` |
| Authoring date | `2026-09-27` |

`requirement.md`、`design.md`、`plan.md` の frontmatter は existing Issue #411 scaffold と同じ ID、title、GitHub link、parent hierarchy、dependency、date、`draft` state を維持しています。`draft` は repository の human review gate を残すためであり、実装順序と判断規則は追加判断なしで進められる粒度まで記述しています。

## ZIP 内パスと役割

| ZIP 内パス | 役割 |
|---|---|
| `README.md` | パックの provenance、使い方、integrity、未確定事項を示す入口。 |
| `requirement.md` | Issue #411 の目的、観測可能な要件、scope / out-of-scope、failure boundary、AC-411-01〜08。 |
| `design.md` | current / retired execution graph、deletion gate、package/runtime/CI/docs/tests の責務境界、rollback / testability。 |
| `plan.md` | strict planning level、Step 0〜9 の実装順、具体的な変更・検証コマンド・完了判定・失敗時復旧。 |
| `artifacts/cleanup-inventory.md` | verified source / caller / test / CI / docs の削除・更新・保持・確認待ち台帳。 |

## 適用方法

1. verified branch / SHA と実装 checkout が一致することを `plan.md` Step 0 で確認する。
2. repository の Issue #411 scaffold `requirement.md`、`design.md`、`plan.md` をこのパックの同名ファイルで置き換える。
3. `artifacts/cleanup-inventory.md` を Issue #411 directory の `artifacts/cleanup-inventory.md` として追加する。
4. `plan.md` の順序を変えず、test safety net、asset constant 分離、assertion migration、source removal、CI、docs、full verification の順に進める。
5. `VERIFY-THEN-REMOVE` 項目は inventory の gate evidence が揃うまで削除しない。
6. 実装後の実測結果は inventory completion fields と Issue report / PR body に記録する。

## 重要な実装原則

- provider authority は `src/spec_dock/`。dogfood `spec-dock/` は provider-first で更新し、byte parity を検証する。
- old public CLI の互換実行は不要。current tombstone による安全な拒否は保持する。
- `cli/legacy.py`、historical docs、migration code/tests は名前だけで削除しない。
- `installer.py` は current `ASSETS` caller を neutral `asset_layout.py` へ分離してから削除する。
- old tests は file 単位で一括削除せず、assertion を current behavior / shared invariant / history に分類して移植する。
- `.github/workflows/ci.yml` は fixed full-SHA validator を使い、`sync` を実行しない。
- `.github/workflows/provider-ci.yml` の focused matrix も old installer / harness tests から current tests へ切り替える。
- schema 3 migration、他 worktree / consumer rollout、GitHub write は out-of-scope。

## SHA-256（README 以外）

| ZIP 内パス | SHA-256 |
|---|---|
| `requirement.md` | `5748edd892e87755232a569494befab6b560522c5f018ee206aa8c100c7cb730` |
| `design.md` | `29dfa321550905b60739d0b430ce10b816e27bdaed5d61ee3662b558d25270d4` |
| `plan.md` | `ef1cf3f03a8885df3f253e00c5fa011bd63abfb8f141138238e038d92c5fa23f` |
| `artifacts/cleanup-inventory.md` | `3b79688f0bde7e8183af5772a8b2e6dd8c3c200414c4322d87b87302aff04c1f` |

`README.md` と ZIP 自体の SHA-256 は、ファイル生成後の外部納品情報として回答本文に記載します。

## 未確定事項

残っている未確定事項は product / architecture の自由判断ではなく、実装時の到達性証拠で機械的に確定する項目です。

1. **`installer.py` の current shared symbols**
   - confirmed current symbol は `ASSETS`。
   - current root scan で追加 symbol が見つかった場合のみ `asset_layout.py` へ移し、old behavior は移さない。

2. **old shell から参照される application modules の一部**
   - `application/contracts.py`、`application/issue_lifecycle.py` 等は `VERIFY-THEN-REMOVE`。
   - current command / test から到達すれば保持または shared part を current ownership へ移す。zero-caller のときだけ削除する。

3. **old test の unique current assertions**
   - assertion-level ledger で current behavior / shared invariant を移植する。
   - retired syntax / historical inventory だけなら削除する。

4. **current docs の inbound link / stale guidance**
   - `docs/github-issue-integration.md` と `docs/sync-aggregation.md` は current content へ更新する。
   - historical / migration / tombstone / spec archive は理由付き allowlist とする。

5. **GitHub Actions event SHA と checkout HEAD**
   - workflow は両者を明示比較し、不一致なら fail closed する。別 branch / default ref への fallback はしない。

これらの判定規則、確認コマンド、失敗時復旧は `design.md` と `plan.md` に固定されています。
