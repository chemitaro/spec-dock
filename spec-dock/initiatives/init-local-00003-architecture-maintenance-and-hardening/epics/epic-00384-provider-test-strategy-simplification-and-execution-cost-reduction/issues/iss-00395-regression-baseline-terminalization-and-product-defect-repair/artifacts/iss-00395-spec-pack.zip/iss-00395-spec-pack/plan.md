---
種別: 実装計画書（Issue）
ID: "iss-00395"
タイトル: "Regression Baseline Terminalization and Product Defect Repair"
関連GitHub: ["#395"]
状態: "draft"
最終更新: "2026-09-15"
依存:
  - "requirement.md"
  - "design.md"
  - "../../artifacts/20260913t144152z-adr-issue-392-provisional-merge-and-deferred-b1.md"
  - "../../plan.md"
  - "../../artifacts/rolling-wave-issue-elaboration-contract.md"
親: ["epic-00384", "init-local-00003"]
Planning Level: "implementation-ready-contract-only"
実装開始許可: false
owner_decisions_required: []
repository_evidence:
  role: "elaboration-input-provenance"
  repository: "chemitaro/spec-dock"
  branch: "iss-00395-regression-baseline-terminalization-and-product-defect-repair"
  sha: "fe9ac410a23ca4ccce2de440ef0ddb6c76c48af9"
  tree: "4ee7cf0911ed6e4e51f8d50a09e2b34c71eae599"
p392_entry_evidence:
  sha: "921bf7512c72bfa2887673cb7ec9bc512cec6ff3"
  tree: "190bc566a18cd84813c4b7c043f8724e275cb55d"
---

# iss-00395 Regression Baseline Terminalization and Product Defect Repair — 実装計画

## 1. Execution rule

本PlanはLunaMaxが迷わず実装できる順序とcommandsを固定するが、本Planの受理だけでは実装を許可しない。Product/test/ledger変更は、次の全条件を満たしたexecutionでだけ開始する。

- clean pushed spec freeze tip
- local `HEAD`、upstream、remoteのfull SHA一致
- independent `chatgpt-spec-review-strict` pass、P0/P1=0
- explicit implementation dispatch
- dispatchに`SPEC_FREEZE_SHA`とreview receipt identityが設定済み

Formal Issue start、`owner_decisions_required=[]`、dependency `ready=true`は、この許可を代替しない。

## 2. Shell constants and exact node sets

以下はbashで実行する。Commands内にfuture SHAを先書きしない。`SPEC_FREEZE_SHA`はreview済みclean pushed tipをdispatchが環境変数として渡す。

```bash
set -euo pipefail

export EXPECTED_REPOSITORY="chemitaro/spec-dock"
export ISSUE_BRANCH="iss-00395-regression-baseline-terminalization-and-product-defect-repair"
export INTEGRATION_BRANCH="codex/epic-00384-provider-test-strategy-planning"
export P392_SHA="921bf7512c72bfa2887673cb7ec9bc512cec6ff3"
export P392_TREE="190bc566a18cd84813c4b7c043f8724e275cb55d"
export ELABORATION_INPUT_SHA="fe9ac410a23ca4ccce2de440ef0ddb6c76c48af9"
export ELABORATION_INPUT_TREE="4ee7cf0911ed6e4e51f8d50a09e2b34c71eae599"
: "${SPEC_FREEZE_SHA:?SPEC_FREEZE_SHA must be set to the independently reviewed clean pushed spec tip}"

ROW_1='tests/cli_runtime/test_delete.py::TestCliDelete::test_delete_scrubbed_meta_is_not_reobserved_by_validate_sync_active'
ROW_3='tests/cli_runtime/test_import.py::TestCliImport::test_import_accepts_canonical_url_when_origin_is_credentialed_https_remote'
ROW_4='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_regression'
ROW_5='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_load_active_manifest_chain_regression'
ROW_6='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_re_resolves_inside_lock_when_parent_drifts_regression'
ROW_7='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_numeric_target_uses_resolved_current_repo_slug_for_github_read'
ROW_8='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_issue_uses_target_repo_slug_for_same_repo_url_when_present'
ROW_9='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_then_sync_artifact_path_name_content_regression'
ROW_10='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_post_import_sync_negative_path_regression'
ROW_11='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_execute_create_plan_reuse_seam'
ROW_12='tests/cli_runtime/test_runtime_shell_s11.py::TestRuntimeShellS11::test_final_api_call_site_and_structural_regression'
ROW_13='tests/cli_runtime/test_sync.py::TestCliSync::test_new_and_active_and_sync'
ROW_14='tests/cli_runtime/test_sync.py::TestCliSync::test_sync_emits_tree_puml_ready_board_at_spec_dock_root'
ROW_15='tests/cli_runtime/test_workbench.py::TestCliWorkbench::test_copied_workbench_readme_and_payloads_remain_opaque_to_runtime_commands'
ROW_2_SUCCESSOR='tests/cli_runtime/test_distribution_cutover.py::test_s40b_retained_skill_identity_matches_current_provider_and_dogfood'

ACTIVE_ROWS=(
  "$ROW_1" "$ROW_3" "$ROW_4" "$ROW_5" "$ROW_6" "$ROW_7" "$ROW_8"
  "$ROW_9" "$ROW_10" "$ROW_11" "$ROW_12" "$ROW_13" "$ROW_14" "$ROW_15"
)
S10_ROWS=("$ROW_4" "$ROW_5" "$ROW_6" "$ROW_7" "$ROW_8" "$ROW_9" "$ROW_10" "$ROW_11")
SELECTION_ROWS=("$ROW_1" "$ROW_13" "$ROW_14" "$ROW_15")
IMPLEMENTATION_PATHS=(
  full-regression-ledger.json
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py
  spec-dock/scripts/spec_dock_runtime/infra/git_cli.py
  spec-dock/spec-dock.version
  .agents/skills/spec-dock/.spec-dock-provider-slot.json
  .agents/skills/spec-dock-grill-with-docs/.spec-dock-provider-slot.json
  tests/cli_runtime/test_delete.py
  tests/cli_runtime/test_import.py
  tests/cli_runtime/test_runtime_import_s10.py
  tests/cli_runtime/test_sync.py
  tests/cli_runtime/test_workbench.py
)
```

## 3. Ordered implementation steps

### Step 0 — Permission and repository preflight

```bash
git fetch --prune origin

test "$(git rev-parse --show-toplevel)" = "$PWD"
test "$(git rev-parse --abbrev-ref HEAD)" = "$ISSUE_BRANCH"
test "$(git rev-parse HEAD)" = "$SPEC_FREEZE_SHA"
test "$(git rev-parse '@{upstream}')" = "$SPEC_FREEZE_SHA"
test "$(git ls-remote --heads origin "refs/heads/$ISSUE_BRANCH" | cut -f1)" = "$SPEC_FREEZE_SHA"
test -z "$(git status --porcelain)"
git merge-base --is-ancestor "$P392_SHA" "$SPEC_FREEZE_SHA"
test "$(git rev-parse "$P392_SHA^{tree}")" = "$P392_TREE"
test "$(git rev-parse "$ELABORATION_INPUT_SHA^{tree}")" = "$ELABORATION_INPUT_TREE"
```

Verify that spec elaboration changed only the six pack files:

```bash
python - "$ELABORATION_INPUT_SHA" "$SPEC_FREEZE_SHA" <<'PY'
from pathlib import Path
import subprocess
import sys

base, head = sys.argv[1:]
issue = Path("spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00395-regression-baseline-terminalization-and-product-defect-repair")
allowed = {
    str(issue / "requirement.md"),
    str(issue / "design.md"),
    str(issue / "plan.md"),
    str(issue / "artifacts/iss-00395-luna-max-implementation-handoff.md"),
    str(issue / "artifacts/iss-00395-human-guide.html"),
    str(issue / "artifacts/iss-00395-chatgpt-spec-pack-manifest.md"),
}
changed = set(subprocess.check_output(["git", "diff", "--name-only", f"{base}...{head}"], text=True).splitlines())
extra = sorted(changed - allowed)
missing = sorted(allowed - changed)
if extra or missing:
    raise SystemExit({"unexpected": extra, "missing": missing})
print("spec-pack-diff-ok")
PY
```

Read formal active state and managed metadata without editing them:

```bash
./spec-dock/scripts/spec-dock active show | tee /tmp/iss-00395-active-show.txt
grep -F 'iss-00395' /tmp/iss-00395-active-show.txt
python - <<'PY'
from pathlib import Path
import json

path = Path("spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00395-regression-baseline-terminalization-and-product-defect-repair/.meta.json")
payload = json.loads(path.read_text(encoding="utf-8"))
assert payload["id"] == "iss-00395"
assert payload["github"]["issue_number"] == 395
assert payload.get("depends_on", []) == []
print("issue-metadata-ok")
PY
```

Stop with zero Product/test/ledger changes if any command fails. Do not use `active set` or hand-edit `.meta.json` to repair preflight.

### Step 1 — Exact baseline and no-touch inventory

Run an exact machine check before tests:

```bash
python - <<'PY'
from pathlib import Path
import json

ledger = json.loads(Path("full-regression-ledger.json").read_text(encoding="utf-8"))
rows = ledger["failure_paths"]
expected = [
("tests/cli_runtime/test_delete.py::TestCliDelete::test_delete_scrubbed_meta_is_not_reobserved_by_validate_sync_active", "0d6c418e8c531ed77662b5bb0f166c6370f1b4d995a1ec6ac23452382c34869f", "active"),
("tests/cli_runtime/test_distribution_cutover.py::test_s40b_retained_skill_identity_matches_issue359_final_source", "8742959a307d18594743f6bec12a056268baab34024279dbeb4e57458b3a7637", "resolved"),
("tests/cli_runtime/test_import.py::TestCliImport::test_import_accepts_canonical_url_when_origin_is_credentialed_https_remote", "f149be56ae07e7b774137b1f8f5912076a82838250be9750c886aca7a8392a5f", "active"),
("tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_regression", "3f7d32388f2d60f77ec1740aac53fd6d6481f7cb04ef3f3ae7ef09463a29a980", "active"),
("tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_load_active_manifest_chain_regression", "55f2d59d2e1ce7b337462feefbde5c5a84423d07f039ff5fb5dd7bc8b10762ce", "active"),
("tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_re_resolves_inside_lock_when_parent_drifts_regression", "ab1f703094ed3335d43ff943cb9194266ee2c162758b3c732b47c1c1cee9256a", "active"),
("tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_numeric_target_uses_resolved_current_repo_slug_for_github_read", "ea4df2e82010c5a2058e5bfd5b31bb7ada7f4776f8cff44a2457fb50b8a1df70", "active"),
("tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_issue_uses_target_repo_slug_for_same_repo_url_when_present", "22d80f8db459620d13f14e34c9a7fc2ee60b73f4080ac7d181b3a7c69ab1d4f3", "active"),
("tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_then_sync_artifact_path_name_content_regression", "0dbf9314fa763929461775d43ae3e56c51bddcb742e2e329317736f5b1194ef7", "active"),
("tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_post_import_sync_negative_path_regression", "541c15d4ba9564d9256cb2651fe180c2e230760c2fa56ecb389f145fb8723d00", "active"),
("tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_execute_create_plan_reuse_seam", "44894dc46328aad1a9352cb69a93975a99701b9a9e14f8d5c9dc25470dcf6efd", "active"),
("tests/cli_runtime/test_runtime_shell_s11.py::TestRuntimeShellS11::test_final_api_call_site_and_structural_regression", "0c1088f1a15dd18d672fe5707d9add3ffe1593b6ead070d90ba553019c498790", "active"),
("tests/cli_runtime/test_sync.py::TestCliSync::test_new_and_active_and_sync", "f9b206f85a7c0ee352b4019eaed232ee02dcf896c150659fa7e8191f125951a6", "active"),
("tests/cli_runtime/test_sync.py::TestCliSync::test_sync_emits_tree_puml_ready_board_at_spec_dock_root", "3d1b673b92516964bd29b91cf29c8e03c553988dc9e0df7f0a9aee16dc545619", "active"),
("tests/cli_runtime/test_workbench.py::TestCliWorkbench::test_copied_workbench_readme_and_payloads_remain_opaque_to_runtime_commands", "20d53420c38ab501c64346e6e22a0b309b2358191fe74a54ed9c20717ddb09b9", "active"),
]
actual = [(row["nodeid"], row["fixed_point_signature_sha256"], row["lifecycle"]) for row in rows]
assert actual == expected
assert rows[1]["resolution_mode"] == "superseded"
assert rows[1]["successor_nodeid"] == "tests/cli_runtime/test_distribution_cutover.py::test_s40b_retained_skill_identity_matches_current_provider_and_dogfood"
timing = json.loads(Path("full-regression-timing-weights.json").read_text(encoding="utf-8"))
assert len(timing["node_seconds"]) == 243
print("baseline=15/14/1 timing=243")
PY
```

Record blob identities before changing files:

```bash
git ls-tree "$P392_SHA" \
  full-regression-ledger.json full-regression-timing-weights.json tests/conftest.py \
  scripts/quality/full_regression_baseline.py scripts/quality/verify_full_regression.py \
  .github/workflows/provider-ci.yml .github/workflows/provider-full-regression.yml \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/commands/new.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/contracts.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/domain/artifacts.py \
  tests/cli_runtime/test_delete.py tests/cli_runtime/test_import.py \
  tests/cli_runtime/test_runtime_import_s10.py tests/cli_runtime/test_runtime_shell_s11.py \
  tests/cli_runtime/test_sync.py tests/cli_runtime/test_workbench.py \
  | tee /tmp/iss-00395-p392-owned-blobs.txt
```

### Step 2 — First RED reproduction

#### 2.1 Current full verifier entry observation

```bash
set +e
env TMPDIR=/private/tmp uv run python -m scripts.quality.verify_full_regression --shards 4
ENTRY_FULL_RC=$?
set -e
test "$ENTRY_FULL_RC" -eq 1
ENTRY_RUN_DIR="$(find spec-dock/.workbench/full-regression -mindepth 1 -maxdepth 1 -type d | sort | tail -1)"
python - "$ENTRY_RUN_DIR/result.json" "$SPEC_FREEZE_SHA" <<'PY'
from pathlib import Path
import json
import sys

result_path, expected_sha = sys.argv[1:]
result = json.loads(Path(result_path).read_text(encoding="utf-8"))
assert result["status"] == "ledger-mismatch"
assert result["candidate_sha"] == expected_sha
violations = {(item["code"], item["nodeid"]) for item in result["evaluation"]["violations"]}
expected = {
("signature_mismatch", "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_regression"),
("signature_mismatch", "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_load_active_manifest_chain_regression"),
("signature_mismatch", "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_re_resolves_inside_lock_when_parent_drifts_regression"),
("signature_mismatch", "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_numeric_target_uses_resolved_current_repo_slug_for_github_read"),
("signature_mismatch", "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_issue_uses_target_repo_slug_for_same_repo_url_when_present"),
("signature_mismatch", "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_then_sync_artifact_path_name_content_regression"),
("signature_mismatch", "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_post_import_sync_negative_path_regression"),
("signature_mismatch", "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_execute_create_plan_reuse_seam"),
("coverage_mismatch", "tests/cli_runtime/test_runtime_shell_s11.py::TestRuntimeShellS11::test_final_api_call_site_and_structural_regression"),
("signature_mismatch", "tests/cli_runtime/test_workbench.py::TestCliWorkbench::test_copied_workbench_readme_and_payloads_remain_opaque_to_runtime_commands"),
}
assert violations == expected
assert set(result["evaluation"]["active_verified"]) == {
"tests/cli_runtime/test_delete.py::TestCliDelete::test_delete_scrubbed_meta_is_not_reobserved_by_validate_sync_active",
"tests/cli_runtime/test_import.py::TestCliImport::test_import_accepts_canonical_url_when_origin_is_credentialed_https_remote",
"tests/cli_runtime/test_sync.py::TestCliSync::test_new_and_active_and_sync",
"tests/cli_runtime/test_sync.py::TestCliSync::test_sync_emits_tree_puml_ready_board_at_spec_dock_root",
}
assert result["evaluation"]["resolved_verified"] == [
"tests/cli_runtime/test_distribution_cutover.py::test_s40b_retained_skill_identity_matches_issue359_final_source"
]
print("P392-entry-observation-ok")
PY
```

Any extra or missing violation is a stop condition. Do not continue by updating expected sets.

#### 2.2 Row 12 current GREEN / active-ledger RED

```bash
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short "$ROW_12"
```

Expected: one normal pass. This confirms that the Product thin-shell boundary is already compliant and that the full-verifier `coverage_mismatch` is caused by active ledger state. If this node fails or `commands/new.py` directly imports `domain.artifacts`, stop for drift.

#### 2.3 Product row 3 RED

```bash
set +e
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short "$ROW_3" \
  2>&1 | tee /tmp/iss-00395-row-3-red.log
ROW3_RED_RC=${PIPESTATUS[0]}
set -e
test "$ROW3_RED_RC" -eq 1
grep -F 'Current GitHub repo scope could not be resolved from origin' /tmp/iss-00395-row-3-red.log
```

Expected: only the credential-bearing origin identity resolution prevents success. The log must not contain the raw token-bearing remote outside the test source representation.

#### 2.4 S10 descriptor-port RED

```bash
set +e
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short "${S10_ROWS[@]}" \
  2>&1 | tee /tmp/iss-00395-s10-red.log
S10_RED_RC=${PIPESTATUS[0]}
set -e
test "$S10_RED_RC" -eq 1
grep -F 'copy_scaffolded_tree_at' /tmp/iss-00395-s10-red.log
```

Expected: all eight nodes fail at `_StubTemplateScaffolder` because the current port method is absent. An application assertion failure not caused by this missing method is a stop condition.

#### 2.5 Selection-only observer RED

```bash
set +e
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short "${SELECTION_ROWS[@]}" \
  2>&1 | tee /tmp/iss-00395-selection-red.log
SELECTION_RED_RC=${PIPESTATUS[0]}
set -e
test "$SELECTION_RED_RC" -eq 1
grep -E -- '--force|--no-checkout|active\.json' /tmp/iss-00395-selection-red.log
```

Expected: retired active arguments or their downstream missing-state effect explain the failures. Delete/sync/Workbench behavior itself must not show a distinct Product defect.

### Step 3 — Test harness edits before Product edits

#### 3.1 Rows 4–11

Edit only `tests/cli_runtime/test_runtime_import_s10.py::_StubTemplateScaffolder`.

1. Add `copy_scaffolded_tree_at(self, src_dir, dest_dir, dest_dir_fd, replacements)`.
2. Append `copy_scaffolded_tree_at` to `self.events` once.
3. Import current `spec_dock_runtime.infra.template_scaffolder` inside the method and delegate to its existing `copy_scaffolded_tree_at` with all four arguments.
4. Keep `copy_scaffolded_tree` and all existing row assertions.
5. Do not edit `application/create_node.py`, `application/ports.py`, or `infra/template_scaffolder.py`.

Run GREEN:

```bash
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short "${S10_ROWS[@]}"
```

Expected: `8 passed`; no skip/xfail.

#### 3.2 Rows 1、13、14、15

Make exact replacements:

- `test_delete.py`: `active set --id iss-00058 --force` -> `active set --id iss-00058`
- `test_sync.py::test_new_and_active_and_sync`: `active set iss-00003 --force` -> `active set iss-00003`
- `test_sync.py::test_sync_emits_tree_puml_ready_board_at_spec_dock_root`: `active set 305 --force --no-checkout` -> `active set 305`
- `test_workbench.py`: `active set --id scope_id --force` -> `active set --id scope_id`; assert return code 0 before reading `active.json`

Do not delete any original delete/sync/PUML/ready-board/Workbench opacity assertion.

```bash
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short "${SELECTION_ROWS[@]}"
```

Expected: `4 passed`; no skip/xfail.

### Step 4 — Strengthen row 3 observer, then repair Product boundary

#### 4.1 Test-first observer change

In the existing row 3 node, retain success text and add assertions that `p.stdout + p.stderr` contains neither `token` nor `https://token@github.com/example/repo.git`. Do not rename the node or add a new ledger row.

Rerun the row before Product edit. It must remain RED for unresolved current repo scope, not pass through a suppressed assertion.

#### 4.2 Production edits

Edit only existing symbols in `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py`.

1. `_parse_github_repo_slug`: remove the `_remote_has_userinfo` rejection; keep exact GitHub regex parsing and lowercase owner/repo result.
2. `origin_github_repo_slug`: fetch only `_remote_get_url(repo_root, push=False)` and parse it directly; do not call `origin_github_publication_endpoint`.
3. `origin_github_publication_endpoint`: after reading fetch/push URLs, explicitly reject either URL when `_remote_has_userinfo` is true; diagnostic must use `_redact_remote_url`; then parse both and keep exact slug equality.
4. Keep function signatures, exceptions for missing origin/git failures, and all non-related Git coordination code unchanged.

Focused GREEN:

```bash
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short "$ROW_3"
```

Expected: `1 passed`; stdout/stderr contain no credential material.

Run a direct publication-policy diagnostic against the provider source without writing repository state:

```bash
env PYTHONPATH=src/spec_dock/assets/spec_dock/scripts uv run python - <<'PY'
from pathlib import Path
import subprocess
import tempfile

from spec_dock_runtime.infra.git_cli import origin_github_publication_endpoint, origin_github_repo_slug

with tempfile.TemporaryDirectory() as tmp:
    repo = Path(tmp)
    subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
    subprocess.run(["git", "remote", "add", "origin", "https://token@github.com/Example/Repo.git"], cwd=repo, check=True)
    assert origin_github_repo_slug(repo) == "example/repo"
    try:
        origin_github_publication_endpoint(repo)
    except RuntimeError as exc:
        text = str(exc)
        assert "token" not in text
        assert "https://token@github.com" not in text
        assert "<credential-bearing remote>" in text
    else:
        raise AssertionError("publication endpoint accepted credential-bearing origin")

    subprocess.run(["git", "remote", "set-url", "origin", "https://github.com/Example/Repo.git"], cwd=repo, check=True)
    subprocess.run(["git", "remote", "set-url", "--push", "origin", "https://github.com/Other/Repo.git"], cwd=repo, check=True)
    try:
        origin_github_publication_endpoint(repo)
    except RuntimeError as exc:
        assert "fetch/push mismatch" in str(exc)
    else:
        raise AssertionError("publication endpoint accepted mismatched fetch/push repositories")
print("identity-publication-separation-ok")
PY
```

### Step 5 — Row 12 guard, no Product edit

```bash
python - <<'PY'
from pathlib import Path
import ast

new_path = Path("src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/commands/new.py")
contracts_path = Path("src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/contracts.py")
domain_path = Path("src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/domain/artifacts.py")
new_source = new_path.read_text(encoding="utf-8")
contracts_source = contracts_path.read_text(encoding="utf-8")
domain_source = domain_path.read_text(encoding="utf-8")
ast.parse(new_source); ast.parse(contracts_source); ast.parse(domain_source)
assert "from spec_dock_runtime.application.contracts import" in new_source
assert "CURRENT_CREATABLE_ARTIFACT_TYPES" in new_source
assert "spec_dock_runtime.domain.artifacts" not in new_source
assert "from spec_dock_runtime.domain.artifacts import" in contracts_source
assert "CURRENT_CREATABLE_ARTIFACT_TYPES" in contracts_source
assert "CURRENT_CREATABLE_ARTIFACT_TYPES" in domain_source
print("row-12-application-contract-ok")
PY

env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short "$ROW_12"
```

Expected: guard pass and `1 passed`. Do not edit the three Product files or `test_runtime_shell_s11.py`.

### Step 6 — Combined pre-ledger GREEN

Run all active historical nodes plus row 2 successor in shard mode, which bypasses global active-ledger expectation but retains real tests:

```bash
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short \
  "${ACTIVE_ROWS[@]}" "$ROW_2_SUCCESSOR"
```

Expected: `15 passed`; no failed/error/skipped/xfailed/xpassed. If any row remains non-pass, do not edit the ledger.

### Step 7 — Provider-first dogfood projection

Run source-focused gates before projection:

```bash
env TMPDIR=/private/tmp uv run pytest -q --tb=short \
  tests/cli_runtime/test_import.py \
  tests/cli_runtime/test_runtime_import_s10.py \
  tests/cli_runtime/test_runtime_shell_s11.py

env TMPDIR=/private/tmp make lint
```

Project the complete local provider candidate through the current lifecycle command:

```bash
env TMPDIR=/private/tmp uv run spec-dock update . --json | tee /tmp/iss-00395-dogfood-update.json
```

Verify the complete generated candidate identity. The runtime mirror must match provider source; the ready record and both fixed-slot markers must carry one exact new candidate digest while retaining their closed non-digest fields:

```bash
cmp -s \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py \
  spec-dock/scripts/spec_dock_runtime/infra/git_cli.py

python - <<'PY'
from pathlib import Path
import json

record = json.loads(Path("spec-dock/spec-dock.version").read_text(encoding="utf-8"))
markers = [
    json.loads(Path(".agents/skills/spec-dock/.spec-dock-provider-slot.json").read_text(encoding="utf-8")),
    json.loads(Path(".agents/skills/spec-dock-grill-with-docs/.spec-dock-provider-slot.json").read_text(encoding="utf-8")),
]
assert record == {
    "schema_version": 1,
    "state": "ready",
    "operation": None,
    "version": "0.2.4",
    "candidate_digest": record["candidate_digest"],
    "seed_policy": "preserve-only",
    "skill_slots": {
        "spec-dock": "0.2.4",
        "spec-dock-grill-with-docs": "0.2.4",
    },
}
assert isinstance(record["candidate_digest"], str) and len(record["candidate_digest"]) == 64
assert markers == [
    {
        "schema_version": 1,
        "slot": ".agents/skills/spec-dock",
        "version": "0.2.4",
        "candidate_digest": record["candidate_digest"],
    },
    {
        "schema_version": 1,
        "slot": ".agents/skills/spec-dock-grill-with-docs",
        "version": "0.2.4",
        "candidate_digest": record["candidate_digest"],
    },
]
print(f"dogfood-candidate={record['candidate_digest']}")
PY
```

Run candidate parity:

```bash
env TMPDIR=/private/tmp uv run pytest -q --tb=short \
  tests/integration/test_provider_lifecycle_dogfood.py::test_t13_source_wheel_sdist_installed_and_dogfood_candidate_are_identical
```

Expected: update completes with current lifecycle result, provider/dogfood runtime bytes match, `spec-dock.version` and both fixed-slot markers share one 64-hex new candidate digest, and parity node passes. The three identity files are expected generated changes, not lifecycle semantic changes. If projection changes `pyproject.toml` version, lifecycle source/schema/wire, two skill `SKILL.md` bytes, provider roots other than the changed runtime mirror, protected data, ledger, timing, or workflows, stop and discard the projection diff.

### Step 8 — Atomic ledger transition

Only after Step 6 and Step 7 are GREEN, update exact active rows in `full-regression-ledger.json`:

```bash
python - <<'PY'
from pathlib import Path
import json

path = Path("full-regression-ledger.json")
payload = json.loads(path.read_text(encoding="utf-8"))
rows = payload["failure_paths"]
fixed = {
"tests/cli_runtime/test_delete.py::TestCliDelete::test_delete_scrubbed_meta_is_not_reobserved_by_validate_sync_active",
"tests/cli_runtime/test_import.py::TestCliImport::test_import_accepts_canonical_url_when_origin_is_credentialed_https_remote",
"tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_regression",
"tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_load_active_manifest_chain_regression",
"tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_re_resolves_inside_lock_when_parent_drifts_regression",
"tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_numeric_target_uses_resolved_current_repo_slug_for_github_read",
"tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_issue_uses_target_repo_slug_for_same_repo_url_when_present",
"tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_then_sync_artifact_path_name_content_regression",
"tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_post_import_sync_negative_path_regression",
"tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_execute_create_plan_reuse_seam",
"tests/cli_runtime/test_runtime_shell_s11.py::TestRuntimeShellS11::test_final_api_call_site_and_structural_regression",
"tests/cli_runtime/test_sync.py::TestCliSync::test_new_and_active_and_sync",
"tests/cli_runtime/test_sync.py::TestCliSync::test_sync_emits_tree_puml_ready_board_at_spec_dock_root",
"tests/cli_runtime/test_workbench.py::TestCliWorkbench::test_copied_workbench_readme_and_payloads_remain_opaque_to_runtime_commands",
}
assert len(rows) == 15
assert {row["nodeid"] for row in rows if row["lifecycle"] == "active"} == fixed
row2_before = json.dumps(rows[1], sort_keys=True, ensure_ascii=False)
for row in rows:
    if row["nodeid"] in fixed:
        assert row["lifecycle"] == "active"
        assert "resolution_mode" not in row
        assert "successor_nodeid" not in row
        row["lifecycle"] = "resolved"
        row["resolution_mode"] = "fixed-in-place"
assert json.dumps(rows[1], sort_keys=True, ensure_ascii=False) == row2_before
path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print("ledger-transitioned-15-0-15")
PY
```

Immediately validate shape:

```bash
python - <<'PY'
from pathlib import Path
import json

rows = json.loads(Path("full-regression-ledger.json").read_text(encoding="utf-8"))["failure_paths"]
assert len(rows) == 15
assert sum(row["lifecycle"] == "active" for row in rows) == 0
assert sum(row["lifecycle"] == "resolved" for row in rows) == 15
assert sum(row.get("resolution_mode") == "fixed-in-place" for row in rows) == 14
assert sum(row.get("resolution_mode") == "superseded" for row in rows) == 1
print("baseline=15/0/15 fixed=14 superseded=1")
PY
```

### Step 9 — Focused GREEN after ledger transition

```bash
env TMPDIR=/private/tmp uv run pytest -q --tb=short tests/unit/test_full_regression_baseline.py

env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short \
  "${ACTIVE_ROWS[@]}" "$ROW_2_SUCCESSOR"
```

Expected: evaluator tests pass; exact 15 observed nodes normal pass.

### Step 10 — Working-tree full verifier GREEN（provisional）

```bash
export WORKTREE_DIFF_SHA256="$(git diff --binary | shasum -a 256 | awk '{print $1}')"
test -n "$(git status --porcelain)"
env TMPDIR=/private/tmp uv run python -m scripts.quality.verify_full_regression --shards 4
GREEN_RUN_DIR="$(find spec-dock/.workbench/full-regression -mindepth 1 -maxdepth 1 -type d | sort | tail -1)"
python - "$GREEN_RUN_DIR/result.json" "$SPEC_FREEZE_SHA" "$WORKTREE_DIFF_SHA256" <<'PY'
from pathlib import Path
import json
import sys

result_path, expected_head_sha, worktree_diff_sha256 = sys.argv[1:]
result = json.loads(Path(result_path).read_text(encoding="utf-8"))
assert result["status"] == "verified"
# The current verifier records git HEAD, not uncommitted bytes. This run is functional
# GREEN only; the exact implementation identity is established and rerun in Step 14.
assert result["candidate_sha"] == expected_head_sha
assert len(worktree_diff_sha256) == 64
assert result["evaluation"]["verified"] is True
assert result["evaluation"]["active_verified"] == []
assert len(result["evaluation"]["resolved_verified"]) == 15
assert result["evaluation"]["retired_verified"] == []
assert result["evaluation"]["violations"] == []
print(f"working-tree-full-regression-green diff_sha256={worktree_diff_sha256}")
PY
```

Expected: verifier exit 0、4 shard observations valid、duplicate/missing coverage 0、unexpected failure/error 0。ただし、このrunの`candidate_sha`は未commit変更を含まない`SPEC_FREEZE_SHA`なので、merge-ready evidenceには使わない。Step 14でexact implementation commitを作り、clean treeで同じverifierを必ず再実行する。

### Step 11 — Ordinary, lifecycle, platform, packaging, lint and validate gates

Run in this order:

```bash
env TMPDIR=/private/tmp uv run pytest -q --tb=short

env TMPDIR=/private/tmp uv run pytest -q --tb=short tests/unit/provider_lifecycle

env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short \
  tests/cli_runtime/test_distribution_cutover.py

env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short \
  tests/cli_runtime/test_provider_lifecycle_bootstrap.py \
  tests/cli_runtime/test_provider_lifecycle_handoff.py \
  tests/cli_runtime/test_generation_checkout.py \
  tests/cli_runtime/test_worktree_lifecycle_coordination.py

env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short \
  tests/integration/test_epic_00343_distribution.py

env TMPDIR=/private/tmp uv run pytest -q --tb=short \
  tests/integration/test_provider_lifecycle_dogfood.py

env TMPDIR=/private/tmp make lint
./spec-dock/scripts/spec-dock validate
```

Expected: all commands exit 0. Ordinary lane retains policy skips but has no unexpected failure. Provider lifecycle and packaging behavior remain unchanged.

### Step 12 — Ledger/timing/policy/no-touch checks

```bash
git diff --exit-code "$SPEC_FREEZE_SHA" -- \
  full-regression-timing-weights.json \
  tests/conftest.py \
  scripts/quality/full_regression_baseline.py \
  scripts/quality/verify_full_regression.py \
  tests/unit/test_full_regression_baseline.py \
  .github/workflows/provider-ci.yml \
  .github/workflows/provider-full-regression.yml \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/import_node.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/repo_context.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/ports.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/cli/bootstrap.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/create_node.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/template_scaffolder.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/commands/new.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/contracts.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/domain/artifacts.py \
  tests/cli_runtime/test_runtime_shell_s11.py
```

Parent/lifecycle/#396 no-touch:

```bash
git diff --exit-code "$SPEC_FREEZE_SHA" -- \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/requirement.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/design.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/plan.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/artifacts/provider-lifecycle-wire-contract.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/artifacts/active-failure-disposition-register.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/artifacts/epic-integration-branch-contract.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/artifacts/rolling-wave-issue-elaboration-contract.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00392-provider-lifecycle-and-regression-gate-hard-cutover \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00396-build-once-provider-gate-and-regression-policy-cutover
```

Verify exact required-fast set and timing count:

```bash
python - <<'PY'
from pathlib import Path
import ast
import json

source = Path("tests/conftest.py").read_text(encoding="utf-8")
tree = ast.parse(source)
required = None
for node in tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "REQUIRED_FAST_NODE_IDS" for target in node.targets):
        required = ast.literal_eval(node.value.args[0]) if isinstance(node.value, ast.Call) else ast.literal_eval(node.value)
        break
assert set(required) == {
"tests/unit/cli/test_cli_smoke.py::TestCliSmoke::test_active_set_by_id_succeeds_through_runtime_subprocess",
"tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_mirror_docs_match_provider_assets",
"tests/unit/infra/test_init_update.py::TestInitUpdate::test_issue_68_workflow_seed_matches_repo_root_ci_workflow",
"tests/unit/infra/test_init_update.py::TestInitUpdate::test_issue_68_provider_only_workflow_is_not_shipped_via_install_root",
}
timing = json.loads(Path("full-regression-timing-weights.json").read_text(encoding="utf-8"))
assert len(timing["node_seconds"]) == 243
print("required-fast=4 timing=243")
PY
```

### Step 13 — Exact changed-file check and cleanup

The implementation diff may contain only these tracked paths:

```text
full-regression-ledger.json
src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py
spec-dock/scripts/spec_dock_runtime/infra/git_cli.py
spec-dock/spec-dock.version
.agents/skills/spec-dock/.spec-dock-provider-slot.json
.agents/skills/spec-dock-grill-with-docs/.spec-dock-provider-slot.json
tests/cli_runtime/test_delete.py
tests/cli_runtime/test_import.py
tests/cli_runtime/test_runtime_import_s10.py
tests/cli_runtime/test_sync.py
tests/cli_runtime/test_workbench.py
```

Check mechanically:

```bash
python - "$SPEC_FREEZE_SHA" <<'PY'
import subprocess
import sys

base = sys.argv[1]
allowed = {
"full-regression-ledger.json",
"src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py",
"spec-dock/scripts/spec_dock_runtime/infra/git_cli.py",
"spec-dock/spec-dock.version",
".agents/skills/spec-dock/.spec-dock-provider-slot.json",
".agents/skills/spec-dock-grill-with-docs/.spec-dock-provider-slot.json",
"tests/cli_runtime/test_delete.py",
"tests/cli_runtime/test_import.py",
"tests/cli_runtime/test_runtime_import_s10.py",
"tests/cli_runtime/test_sync.py",
"tests/cli_runtime/test_workbench.py",
}
changed = set(subprocess.check_output(["git", "diff", "--name-only", base], text=True).splitlines())
extra = sorted(changed - allowed)
missing = sorted(allowed - changed)
if extra or missing:
    raise SystemExit({"unexpected": extra, "missing": missing})
print("implementation-file-set-ok")
PY

git diff --check
find . -type d -name __pycache__ -prune -print
find . -type f \( -name '*.pyc' -o -name '*.pyo' \) -print
git status --short
```

Do not delete `.workbench/full-regression` evidence before its result paths and hashes are captured. Do not commit caches, temporary logs, credentials, or external review receipts into tracked Product paths.

### Step 14 — Exact candidate freeze、clean rerun and independent strict review

Commit/pushはexecution packetが明示的に許可した場合だけ行う。許可がなければ、Step 13のdiff、provisional GREEN、stop-and-returnを返し、merge-readyを主張しない。

```bash
: "${COMMIT_PUSH_AUTHORIZED:?COMMIT_PUSH_AUTHORIZED is required}"
test "$COMMIT_PUSH_AUTHORIZED" = "true"

git add -- "${IMPLEMENTATION_PATHS[@]}"
test -z "$(git diff --name-only)"
git diff --cached --check
git commit -m "fix(iss-00395): terminalize regression baseline"
export IMPLEMENTATION_SHA="$(git rev-parse HEAD)"
export IMPLEMENTATION_TREE="$(git rev-parse 'HEAD^{tree}')"
git push origin "HEAD:refs/heads/$ISSUE_BRANCH"
test "$(git rev-parse '@{upstream}')" = "$IMPLEMENTATION_SHA"
test "$(git ls-remote --heads origin "refs/heads/$ISSUE_BRANCH" | cut -f1)" = "$IMPLEMENTATION_SHA"
test -z "$(git status --porcelain)"
```

Rerun the exact current verifier on the clean implementation commit and bind the result to `IMPLEMENTATION_SHA`:

```bash
env TMPDIR=/private/tmp uv run python -m scripts.quality.verify_full_regression --shards 4
EXACT_RUN_DIR="$(find spec-dock/.workbench/full-regression -mindepth 1 -maxdepth 1 -type d | sort | tail -1)"
python - "$EXACT_RUN_DIR/result.json" "$IMPLEMENTATION_SHA" <<'PY'
from pathlib import Path
import json
import sys

result_path, implementation_sha = sys.argv[1:]
result = json.loads(Path(result_path).read_text(encoding="utf-8"))
assert result["candidate_sha"] == implementation_sha
assert result["status"] == "verified"
assert result["evaluation"]["verified"] is True
assert result["evaluation"]["active_verified"] == []
assert len(result["evaluation"]["resolved_verified"]) == 15
assert result["evaluation"]["retired_verified"] == []
assert result["evaluation"]["violations"] == []
print("exact-candidate-full-regression-green")
PY
```

Rerun every merge-blocking ordinary, lifecycle, platform, package, static and metadata gate on the same clean SHA:

```bash
test "$(git rev-parse HEAD)" = "$IMPLEMENTATION_SHA"
env TMPDIR=/private/tmp uv run pytest -q --tb=short
env TMPDIR=/private/tmp uv run pytest -q --tb=short tests/unit/provider_lifecycle
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short tests/cli_runtime/test_distribution_cutover.py
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short \
  tests/cli_runtime/test_provider_lifecycle_bootstrap.py \
  tests/cli_runtime/test_provider_lifecycle_handoff.py \
  tests/cli_runtime/test_generation_checkout.py \
  tests/cli_runtime/test_worktree_lifecycle_coordination.py
env TMPDIR=/private/tmp uv run pytest --run-full-regression --full-regression-shard -q --tb=short tests/integration/test_epic_00343_distribution.py
env TMPDIR=/private/tmp uv run pytest -q --tb=short tests/integration/test_provider_lifecycle_dogfood.py
env TMPDIR=/private/tmp make lint
./spec-dock/scripts/spec-dock validate
test "$(git rev-parse HEAD)" = "$IMPLEMENTATION_SHA"
test -z "$(git status --porcelain)"
```

Then perform independent reviews against this exact full SHA:

1. Run `chatgpt-code-review-strict` in a fresh independent browser session with the complete diff, Requirement/Design/Plan, 14-row table, RED/GREEN evidence, exact clean full-verifier result and no-touch proof.
2. Acceptance: `review_status=pass`、P0/P1=0。Valid findings are remediated in a new commit on the same Issue branch; every affected gate and the exact clean full verifier are rerun on the new SHA.
3. Run `chatgpt-final-quality-gate-strict-v2` with GPT-5.6 Sol + Pro on the final clean pushed SHA.
4. Acceptance: `status=pass`、`coverage_complete=true`、P0/P1=0、`unreviewed_areas=[]`、`unresolved_items=[]`。
5. Past #392、spec-review、working-tree verifier receipts do not certify the implementation SHA.

### Step 15 — PR and human merge gate

- PR head: Issue branch only
- PR base: `codex/epic-00384-provider-test-strategy-planning`
- Direct push to integration branch: forbidden
- Agent merge/revert/required-context change/Issue close: forbidden
- Partial row PR or ledger-only PR: forbidden
- Merge authority: human only

Before human merge, confirm PR head SHA equals reviewed candidate SHA and required Provider CI checks are SUCCESS. Current full verifier evidence is attached separately because main-push workflow is not a PR required context.

### Step 16 — Post-merge same-tip B1 then B2

Human merge後、clean verification cloneでintegration branchを取得する。

```bash
set -euo pipefail
git fetch --prune origin
git checkout --detach "origin/$INTEGRATION_BRANCH"
export POST_395_MERGE_SHA="$(git rev-parse HEAD)"
export POST_395_MERGE_TREE="$(git rev-parse 'HEAD^{tree}')"
test -z "$(git status --porcelain)"
test "$(git ls-remote --heads origin "refs/heads/$INTEGRATION_BRANCH" | cut -f1)" = "$POST_395_MERGE_SHA"
```

B1 first:

```bash
env TMPDIR=/private/tmp uv run pytest -q --tb=short
env TMPDIR=/private/tmp uv run pytest -q --tb=short tests/unit/provider_lifecycle
env TMPDIR=/private/tmp uv run pytest -q --tb=short tests/integration/test_provider_lifecycle_dogfood.py
env TMPDIR=/private/tmp make lint
./spec-dock/scripts/spec-dock validate
env TMPDIR=/private/tmp uv run python -m scripts.quality.verify_full_regression --shards 4
test "$(git rev-parse HEAD)" = "$POST_395_MERGE_SHA"
```

B1 requires all current gates GREEN, provider/dogfood parity, lifecycle invariants, unexpected failure 0.

B2 second on the same SHA:

```bash
python - "$POST_395_MERGE_SHA" <<'PY'
from pathlib import Path
import json
import subprocess
import sys

expected_sha = sys.argv[1]
assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == expected_sha
rows = json.loads(Path("full-regression-ledger.json").read_text(encoding="utf-8"))["failure_paths"]
assert len(rows) == 15
assert sum(row["lifecycle"] == "active" for row in rows) == 0
assert sum(row["lifecycle"] == "resolved" for row in rows) == 15
assert sum(row.get("resolution_mode") == "fixed-in-place" for row in rows) == 14
assert sum(row.get("resolution_mode") == "superseded" for row in rows) == 1
assert len(json.loads(Path("full-regression-timing-weights.json").read_text(encoding="utf-8"))["node_seconds"]) == 243
print("B2=15/0/15 approved=0 unexpected=0")
PY
```

Record B1 and B2 with the same `POST_395_MERGE_SHA` and tree. Only after both receipts exist may human operations close #392 after B1, finish #395 after B2, and prepare #396. LunaMax does not perform those operations.

## 4. GREEN criteria

Merge-ready means all of the following are rerun and true at one clean pushed implementation SHA; working-tree-only GREEN is insufficient.

- 14 historical active nodes normal pass
- row 2 successor normal pass
- root ledger 15/0/15、14 fixed-in-place、1 superseded
- approved 0、unexpected 0、violations 0
- current full verifier exit 0 / `status=verified`
- ordinary suite pass
- provider lifecycle / platform / package / dogfood pass
- lint and SpecDock validate pass
- timing 243、required-fast 4、policy/workflows unchanged
- Product row 3 identity/publication separation proven without secret exposure
- Product row 12 current application-contract boundary unchanged
- no retired active flags、no old scaffolder fallback、no assertion weakening
- independent Code Review Strict and Final Quality Gate Strict pass
- rollback evidence complete

## 5. Stop-and-return payload

On any stop condition, return a machine-readable payload with these keys and do not select a new design:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "iss-00395-stop-and-return",
  "type": "object",
  "required": [
    "issue",
    "stage",
    "repository",
    "branch",
    "expected_p392_sha",
    "spec_freeze_sha",
    "observed_head_sha",
    "contract_id",
    "row_ordinal",
    "nodeid",
    "expected",
    "actual",
    "changed_paths",
    "secret_redacted",
    "owner_decision_required"
  ],
  "properties": {
    "issue": {"const": "iss-00395"},
    "stage": {
      "enum": [
        "preflight",
        "red",
        "test-edit",
        "product-edit",
        "dogfood",
        "ledger-transition",
        "focused-green",
        "full-verifier",
        "ordinary-gates",
        "strict-review",
        "post-merge-b1",
        "post-merge-b2"
      ]
    },
    "repository": {"const": "chemitaro/spec-dock"},
    "branch": {"const": "iss-00395-regression-baseline-terminalization-and-product-defect-repair"},
    "expected_p392_sha": {"const": "921bf7512c72bfa2887673cb7ec9bc512cec6ff3"},
    "spec_freeze_sha": {"type": "string", "pattern": "^[0-9a-f]{40}$"},
    "observed_head_sha": {"type": "string", "pattern": "^[0-9a-f]{40}$"},
    "contract_id": {"type": "string", "minLength": 1},
    "row_ordinal": {
      "anyOf": [
        {"type": "null"},
        {"enum": [1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]}
      ]
    },
    "nodeid": {
      "anyOf": [
        {"type": "null"},
        {"type": "string", "pattern": "^tests/.+::.+$"}
      ]
    },
    "expected": {"type": "string", "minLength": 1},
    "actual": {"type": "string", "minLength": 1},
    "changed_paths": {
      "type": "array",
      "items": {"type": "string", "minLength": 1},
      "uniqueItems": true
    },
    "secret_redacted": {"const": true},
    "owner_decision_required": {"const": false}
  },
  "additionalProperties": false
}
```

String values shown as runtime facts are populated with actual observations; the schema text itself is not an evidence receipt.

## 6. Rollback

### 6.1 Before merge

Abandon or revise the Issue branch. Integration branch remains P392. Do not modify integration history, close Issues or rewrite accepted commits.

### 6.2 After #395 human merge and before #396 start

If B1 or B2 fails, stop #396. Human chooses one of two actions:

- whole-merge revert to P392, followed by P392 revalidation; or
- #395 owned forward-fix, followed by complete B1/B2 rerun on the new exact tip.

A human revert command is executed only with an observed merge SHA:

```bash
: "${ISS395_MERGE_SHA:?ISS395_MERGE_SHA must be the observed human merge commit}"
git revert -m 1 "$ISS395_MERGE_SHA"
```

Agent does not execute or push this command. Ledger-only, test-only or Product-only rollback is forbidden.

### 6.3 After #396 elaboration starts

Preserve and stop #396 work. Human decides suffix disposition before reverting #395. Accepted suffixes are reverted in reverse dependency order or repaired within the current owner boundary.

## 7. Explicit exclusions

Issue #396のE384-QUAL-001 implementation/evidence、lifecycle wire変更、policy retirement、required-context transition、main mergeは本Issueの実装対象外である。これらを必要とする場合、GREENを偽装せず親へ戻す。

## 8. Completion state

本Planのauthoring完了時点では`実装開始許可: false`、`owner_decisions_required=[]`である。Product completionはhuman merge後のsame-tip B1/B2によってのみ成立する。
