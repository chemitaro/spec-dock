---
種別: artifact
ID: "iss-00395-luna-max-implementation-handoff"
タイトル: "Issue #395 LunaMax 実装引継ぎ"
状態: "draft"
作成者: "ChatGPT specification author"
最終更新: "2026-09-15"
親: ["iss-00395"]
template: "blank"
authority: "evidence"
implementation_allowed: false
owner_decisions_required: []
derived_from:
  - "../requirement.md"
  - "../design.md"
  - "../plan.md"
  - "../../../artifacts/active-failure-disposition-register.md"
  - "../../../artifacts/20260913t144152z-adr-issue-392-provisional-merge-and-deferred-b1.md"
  - "../../../artifacts/epic-integration-branch-contract.md"
  - "../../../artifacts/rolling-wave-issue-elaboration-contract.md"
reflected_to:
  - "../plan.md"
repository_evidence:
  repository: "chemitaro/spec-dock"
  branch: "iss-00395-regression-baseline-terminalization-and-product-defect-repair"
  elaboration_input_sha: "fe9ac410a23ca4ccce2de440ef0ddb6c76c48af9"
  elaboration_input_tree: "4ee7cf0911ed6e4e51f8d50a09e2b34c71eae599"
  p392_sha: "921bf7512c72bfa2887673cb7ec9bc512cec6ff3"
  p392_tree: "190bc566a18cd84813c4b7c043f8724e275cb55d"
---

# Issue #395 LunaMax 実装引継ぎ

## 1. 指示の効力

このArtifactはCodex GPT-5.6 LunaMax向けの実行指示である。ただし、現在の`implementation_allowed`は`false`である。次の条件をすべて含むexecution packetがCodexから明示的に渡されるまで、Product、test、ledger、dogfood projectionを変更しない。

1. `SPEC_FREEZE_SHA`として、Issue #395のRequirement、Design、Plan、本handoff、human guide、manifestを含むclean pushed full SHAが指定されている。
2. `SPEC_FREEZE_SHA`に対する独立`chatgpt-spec-review-strict`が`review_status=pass`、P0=0、P1=0である。
3. Review receipt identityと、review対象のrepository、branch、full SHAが一致している。
4. `IMPLEMENTATION_AUTHORIZED=true`が明示されている。
5. 同時に別Issueのwriterが存在しない。
6. Commit、push、PR準備の許可は、実装許可とは別のbooleanとして渡されている。

Formal `issue start`、active pointer、dependency `ready=true`、`owner_decisions_required=[]`、本handoffの存在は実装許可ではない。実装許可前に行えるのはread-only preflightだけである。

本handoffはProduct patchを含まない。LunaMaxは本書に従って別工程で実装候補を作成し、Codexとhuman gateへ証拠を返す。

## 2. 固定identityとP392境界

| Role | Value |
|---|---|
| Repository | `chemitaro/spec-dock` |
| Issue branch | `iss-00395-regression-baseline-terminalization-and-product-defect-repair` |
| Integration branch | `codex/epic-00384-provider-test-strategy-planning` |
| P392 Product entry SHA | `921bf7512c72bfa2887673cb7ec9bc512cec6ff3` |
| P392 Product entry tree | `190bc566a18cd84813c4b7c043f8724e275cb55d` |
| Elaboration input SHA | `fe9ac410a23ca4ccce2de440ef0ddb6c76c48af9` |
| Elaboration input tree | `4ee7cf0911ed6e4e51f8d50a09e2b34c71eae599` |
| Baseline input | 15 total / 14 active / 1 resolved |
| Timing input | 243 entries |
| Required-fast input | exact 4 nodeids |
| Target | 15 total / 0 active / 15 resolved / 14 fixed-in-place / 1 superseded |
| Approved failure target | 0 |
| Unexpected failure target | 0 |

P392とelaboration inputの間で変更されたのは、次の二つの文書だけである。

1. `spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/plan.md`
2. `spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00392-provider-lifecycle-and-regression-gate-hard-cutover/report.md`

従って、`fe9ac410a23ca4ccce2de440ef0ddb6c76c48af9`のProduct source、tests、root ledger、timing、evaluator、policy、workflowはP392と同一である。後続の`SPEC_FREEZE_SHA`はIssue #395の仕様pack commitを含むためelaboration input SHAとは異なり得るが、P392 Product entry identityを置換しない。

P392は限定された非GREEN中間状態である。P392 mergeはB1、#392 acceptance、#392 closure、#395実装許可、#396開始許可ではない。#395のhuman merge後、一つの同一exact tipでB1を先に、B2を次に確認する。

## 3. Execution packet

Codexは少なくとも次をactual valuesで渡す。

```yaml
packet_schema: 1
issue: iss-00395
repository: chemitaro/spec-dock
branch: iss-00395-regression-baseline-terminalization-and-product-defect-repair
integration_branch: codex/epic-00384-provider-test-strategy-planning
p392_sha: 921bf7512c72bfa2887673cb7ec9bc512cec6ff3
p392_tree: 190bc566a18cd84813c4b7c043f8724e275cb55d
elaboration_input_sha: fe9ac410a23ca4ccce2de440ef0ddb6c76c48af9
elaboration_input_tree: 4ee7cf0911ed6e4e51f8d50a09e2b34c71eae599
spec_freeze_sha: "<actual 40-hex clean pushed SHA>"
spec_review:
  status: pass
  p0: 0
  p1: 0
  receipt_identity: "<immutable receipt identity>"
implementation_authorized: true
commit_push_authorized: false
pr_prepare_authorized: false
concurrent_writer_absent: true
human_merge_only: true
```

`implementation_authorized=true`でも、`commit_push_authorized=false`ならLunaMaxはworking-tree candidateと証拠をCodexへ返して停止する。`pr_prepare_authorized=false`ならPR作成・更新を行わない。

## 4. Read-only preflight

### 4.1 Shell constants

以降のcommandsは同じbash sessionで実行する。

```bash
set -euo pipefail

export EXPECTED_REPOSITORY="chemitaro/spec-dock"
export ISSUE_BRANCH="iss-00395-regression-baseline-terminalization-and-product-defect-repair"
export INTEGRATION_BRANCH="codex/epic-00384-provider-test-strategy-planning"
export P392_SHA="921bf7512c72bfa2887673cb7ec9bc512cec6ff3"
export P392_TREE="190bc566a18cd84813c4b7c043f8724e275cb55d"
export ELABORATION_INPUT_SHA="fe9ac410a23ca4ccce2de440ef0ddb6c76c48af9"
export ELABORATION_INPUT_TREE="4ee7cf0911ed6e4e51f8d50a09e2b34c71eae599"

: "${SPEC_FREEZE_SHA:?SPEC_FREEZE_SHA is required}"
: "${IMPLEMENTATION_AUTHORIZED:?IMPLEMENTATION_AUTHORIZED is required}"
: "${CONCURRENT_WRITER_ABSENT:?CONCURRENT_WRITER_ABSENT is required}"

test "$IMPLEMENTATION_AUTHORIZED" = "true"
test "$CONCURRENT_WRITER_ABSENT" = "true"
```

### 4.2 Repository、branch、SHA、clean status

```bash
git fetch --prune origin

test "$(git rev-parse --show-toplevel)" = "$PWD"
test "$(git rev-parse --abbrev-ref HEAD)" = "$ISSUE_BRANCH"
test "$(git rev-parse HEAD)" = "$SPEC_FREEZE_SHA"
test "$(git rev-parse '@{upstream}')" = "$SPEC_FREEZE_SHA"
test "$(git ls-remote --heads origin "refs/heads/$ISSUE_BRANCH" | cut -f1)" = "$SPEC_FREEZE_SHA"
test -z "$(git status --porcelain)"

git merge-base --is-ancestor "$P392_SHA" "$ELABORATION_INPUT_SHA"
git merge-base --is-ancestor "$ELABORATION_INPUT_SHA" "$SPEC_FREEZE_SHA"
test "$(git rev-parse "$P392_SHA^{tree}")" = "$P392_TREE"
test "$(git rev-parse "$ELABORATION_INPUT_SHA^{tree}")" = "$ELABORATION_INPUT_TREE"
```

一つでも失敗した場合、変更0でstop-and-returnする。Reset、force checkout、別branchへのfallbackで直さない。

### 4.3 P392後のdoc-only差分

```bash
python - "$P392_SHA" "$ELABORATION_INPUT_SHA" <<'PY'
import subprocess
import sys

base, head = sys.argv[1:]
expected = {
    "spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/"
    "epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/plan.md",
    "spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/"
    "epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/"
    "iss-00392-provider-lifecycle-and-regression-gate-hard-cutover/report.md",
}
actual = set(
    subprocess.check_output(
        ["git", "diff", "--name-only", base, head],
        text=True,
    ).splitlines()
)
if actual != expected:
    raise SystemExit(
        {
            "stage": "p392-doc-only-diff",
            "expected": sorted(expected),
            "actual": sorted(actual),
        }
    )
print("p392-to-elaboration-input-doc-only-ok")
PY
```

Product、test、ledger、timing、policy、workflowがこの差分へ含まれていた場合は停止する。

### 4.4 Spec packだけの差分

```bash
python - "$ELABORATION_INPUT_SHA" "$SPEC_FREEZE_SHA" <<'PY'
from pathlib import Path
import subprocess
import sys

base, head = sys.argv[1:]
issue = Path(
    "spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/"
    "epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/"
    "issues/iss-00395-regression-baseline-terminalization-and-product-defect-repair"
)
expected = {
    str(issue / "requirement.md"),
    str(issue / "design.md"),
    str(issue / "plan.md"),
    str(issue / "artifacts/iss-00395-luna-max-implementation-handoff.md"),
    str(issue / "artifacts/iss-00395-human-guide.html"),
    str(issue / "artifacts/iss-00395-chatgpt-spec-pack-manifest.md"),
}
actual = set(
    subprocess.check_output(
        ["git", "diff", "--name-only", base, head],
        text=True,
    ).splitlines()
)
if actual != expected:
    raise SystemExit(
        {
            "stage": "spec-freeze-diff",
            "expected": sorted(expected),
            "actual": sorted(actual),
        }
    )
print("spec-freeze-pack-only-ok")
PY
```

### 4.5 Active state、metadata、validation

```bash
./spec-dock/scripts/spec-dock active show | tee /tmp/iss-00395-active-show.txt
grep -F 'iss-00395' /tmp/iss-00395-active-show.txt

python - <<'PY'
from pathlib import Path
import json

path = Path(
    "spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/"
    "epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/"
    "issues/iss-00395-regression-baseline-terminalization-and-product-defect-repair/"
    ".meta.json"
)
payload = json.loads(path.read_text(encoding="utf-8"))
assert payload["id"] == "iss-00395"
assert payload["type"] == "issue"
assert payload["github"]["repo_owner"] == "chemitaro"
assert payload["github"]["repo_name"] == "spec-dock"
assert payload["github"]["issue_number"] == 395
assert payload.get("depends_on", []) == []
print("issue-metadata-ok")
PY

./spec-dock/scripts/spec-dock validate | tee /tmp/iss-00395-validate.txt
grep -F 'nodes=236' /tmp/iss-00395-validate.txt
```

`.meta.json`、active pointer、dependency storage、generated index/tree/diagramを手編集しない。

### 4.6 Exact baseline、signature、timing

```bash
python - <<'PY'
from pathlib import Path
import json

ledger = json.loads(Path("full-regression-ledger.json").read_text(encoding="utf-8"))
rows = ledger["failure_paths"]

expected = [
    (
        "tests/cli_runtime/test_delete.py::TestCliDelete::"
        "test_delete_scrubbed_meta_is_not_reobserved_by_validate_sync_active",
        "0d6c418e8c531ed77662b5bb0f166c6370f1b4d995a1ec6ac23452382c34869f",
        "active",
    ),
    (
        "tests/cli_runtime/test_distribution_cutover.py::"
        "test_s40b_retained_skill_identity_matches_issue359_final_source",
        "8742959a307d18594743f6bec12a056268baab34024279dbeb4e57458b3a7637",
        "resolved",
    ),
    (
        "tests/cli_runtime/test_import.py::TestCliImport::"
        "test_import_accepts_canonical_url_when_origin_is_credentialed_https_remote",
        "f149be56ae07e7b774137b1f8f5912076a82838250be9750c886aca7a8392a5f",
        "active",
    ),
    (
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_parent_fallback_regression",
        "3f7d32388f2d60f77ec1740aac53fd6d6481f7cb04ef3f3ae7ef09463a29a980",
        "active",
    ),
    (
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_load_active_manifest_chain_regression",
        "55f2d59d2e1ce7b337462feefbde5c5a84423d07f039ff5fb5dd7bc8b10762ce",
        "active",
    ),
    (
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_parent_fallback_re_resolves_inside_lock_when_parent_drifts_regression",
        "ab1f703094ed3335d43ff943cb9194266ee2c162758b3c732b47c1c1cee9256a",
        "active",
    ),
    (
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_import_numeric_target_uses_resolved_current_repo_slug_for_github_read",
        "ea4df2e82010c5a2058e5bfd5b31bb7ada7f4776f8cff44a2457fb50b8a1df70",
        "active",
    ),
    (
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_import_issue_uses_target_repo_slug_for_same_repo_url_when_present",
        "22d80f8db459620d13f14e34c9a7fc2ee60b73f4080ac7d181b3a7c69ab1d4f3",
        "active",
    ),
    (
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_import_then_sync_artifact_path_name_content_regression",
        "0dbf9314fa763929461775d43ae3e56c51bddcb742e2e329317736f5b1194ef7",
        "active",
    ),
    (
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_post_import_sync_negative_path_regression",
        "541c15d4ba9564d9256cb2651fe180c2e230760c2fa56ecb389f145fb8723d00",
        "active",
    ),
    (
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_execute_create_plan_reuse_seam",
        "44894dc46328aad1a9352cb69a93975a99701b9a9e14f8d5c9dc25470dcf6efd",
        "active",
    ),
    (
        "tests/cli_runtime/test_runtime_shell_s11.py::TestRuntimeShellS11::"
        "test_final_api_call_site_and_structural_regression",
        "0c1088f1a15dd18d672fe5707d9add3ffe1593b6ead070d90ba553019c498790",
        "active",
    ),
    (
        "tests/cli_runtime/test_sync.py::TestCliSync::test_new_and_active_and_sync",
        "f9b206f85a7c0ee352b4019eaed232ee02dcf896c150659fa7e8191f125951a6",
        "active",
    ),
    (
        "tests/cli_runtime/test_sync.py::TestCliSync::"
        "test_sync_emits_tree_puml_ready_board_at_spec_dock_root",
        "3d1b673b92516964bd29b91cf29c8e03c553988dc9e0df7f0a9aee16dc545619",
        "active",
    ),
    (
        "tests/cli_runtime/test_workbench.py::TestCliWorkbench::"
        "test_copied_workbench_readme_and_payloads_remain_opaque_to_runtime_commands",
        "20d53420c38ab501c64346e6e22a0b309b2358191fe74a54ed9c20717ddb09b9",
        "active",
    ),
]

actual = [
    (
        row["nodeid"],
        row["fixed_point_signature_sha256"],
        row["lifecycle"],
    )
    for row in rows
]
assert actual == expected
assert rows[1]["resolution_mode"] == "superseded"
assert rows[1]["successor_nodeid"] == (
    "tests/cli_runtime/test_distribution_cutover.py::"
    "test_s40b_retained_skill_identity_matches_current_provider_and_dogfood"
)

timing = json.loads(
    Path("full-regression-timing-weights.json").read_text(encoding="utf-8")
)
assert len(timing["node_seconds"]) == 243
print("baseline=15/14/1 timing=243")
PY
```

### 4.7 Current source blob guard

`SPEC_FREEZE_SHA`では以下のblobsがelaboration inputと同じでなければならない。

```bash
python - "$SPEC_FREEZE_SHA" <<'PY'
import subprocess
import sys

sha = sys.argv[1]
expected = {
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py":
        "b0e34dffb3650e7cb3d202e1db243e4c75fea341",
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/commands/new.py":
        "c967fcd279d628bf3c98b1795ebd090eda5fb959",
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/contracts.py":
        "bc64a84f15b1176cb077c320c5fd5e7cb924589d",
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/domain/artifacts.py":
        "9f62ddf799f22910efeda5eebb4ba41e775241ac",
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/ports.py":
        "129380b6a0b24e111650b264afe78596a26c8a8a",
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/create_node.py":
        "ef8900a71f10df4559f2290c730f032b6d306d73",
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/template_scaffolder.py":
        "86489fdf323d0e70e52bec9d049bbd9b086c76b3",
    "tests/cli_runtime/test_delete.py":
        "3d694fdba352abea454b536b8d108e55e659aa49",
    "tests/cli_runtime/test_import.py":
        "79c6a1eb25c928b447516213833e28e6af506a1b",
    "tests/cli_runtime/test_runtime_import_s10.py":
        "6a68212573cdbecea8496e74fd5be8fcd67400c1",
    "tests/cli_runtime/test_runtime_shell_s11.py":
        "0960800ec3eb183fd2cabcf2a90a9fd220c0a62d",
    "tests/cli_runtime/test_sync.py":
        "1f99b54b9edf2edde150ea64a9d3d6bdc6958397",
    "tests/cli_runtime/test_workbench.py":
        "d86c3a8dc62014c9607f9474f076300b0fe3d8c9",
    "full-regression-ledger.json":
        "f181fd3098ef0cba8d0d17e47d00ea12fbbeb8b5",
    "full-regression-timing-weights.json":
        "bdeeb6238609c38085aaed8023b78319a3dd0c6d",
}
actual = {}
for path in expected:
    actual[path] = subprocess.check_output(
        ["git", "rev-parse", f"{sha}:{path}"],
        text=True,
    ).strip()

mismatch = {
    path: {"expected": expected[path], "actual": actual[path]}
    for path in expected
    if actual[path] != expected[path]
}
if mismatch:
    raise SystemExit({"stage": "source-blob-guard", "mismatch": mismatch})
print("source-blob-guard-ok")
PY
```

Blob driftがあれば、現行仕様入力と実装対象が一致しないため変更0で停止する。

## 5. File and symbol inventory

### 5.1 Product row 3 write surface

| Path | Existing symbol | Required responsibility |
|---|---|---|
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py` | `_remote_get_url` | Origin fetch/push URLを取得する。signatureは変更しない。 |
| 同上 | `_parse_github_repo_slug` | Read-only GitHub repository identity parserへ限定する。 |
| 同上 | `_remote_has_userinfo` | Publication policyでuserinfoを判定する。 |
| 同上 | `_redact_remote_url` | Credential-bearing URLを診断で秘匿する。 |
| 同上 | `origin_github_repo_slug` | Fetch originだけからread-only slugを解決する。 |
| 同上 | `origin_github_publication_endpoint` | Fetch/push publication endpointのuserinfo拒否とslug equalityを担う。 |

次のconsumer path/symbolはread-onlyである。

| Path | Existing symbol |
|---|---|
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/import_node.py` | `import_node_core` |
| 同上 | `_validate_url_repo_identity` |
| 同上 | `_require_numeric_import_repo_scope` |
| 同上 | `_resolve_import_issue_view_repo_slug` |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/repo_context.py` | `require_current_repo_slug` |
| 同上 | `resolve_current_repo_slug` |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/ports.py` | `GitGateway.origin_github_repo_slug` |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/cli/bootstrap.py` | `_GitGateway.origin_github_repo_slug` |

Public/internal signaturesを変更しない。Importのsame-repository policy、numeric targetのcurrent scope requirement、foreign URL rejectionを弱めない。

### 5.2 Rows 4–11 test harness write surface

| Path | Existing symbol | Action |
|---|---|---|
| `tests/cli_runtime/test_runtime_import_s10.py` | `_StubTemplateScaffolder` | Current descriptor-bound methodを追加する。 |
| 同上 | `_StubTemplateScaffolder.copy_scaffolded_tree` | 他test互換のため削除しない。 |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/ports.py` | `TemplateScaffolder.copy_scaffolded_tree_at` | Read-only current port。 |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/create_node.py` | `execute_create_plan` | Read-only。Held descriptor経路を維持する。 |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/template_scaffolder.py` | `copy_scaffolded_tree_at` | Read-only current adapter。 |

追加するtest-double methodのcall shapeは次で固定する。

```python
def copy_scaffolded_tree_at(
    self,
    src_dir: Path,
    dest_dir: Path,
    dest_dir_fd: int,
    replacements: dict[str, str],
) -> list[Path]:
```

Methodはeventを一度記録し、current `spec_dock_runtime.infra.template_scaffolder.copy_scaffolded_tree_at`へ同じ四引数を委譲する。本番をobsolete `copy_scaffolded_tree`へ戻さない。

### 5.3 Rows 1、13、14、15 selection-only observer write surface

| Row | Path | Current obsolete invocation | Required invocation |
|---:|---|---|---|
| 1 | `tests/cli_runtime/test_delete.py` | `active set --id iss-00058 --force` | `active set --id iss-00058` |
| 13 | `tests/cli_runtime/test_sync.py` | `active set iss-00003 --force` | `active set iss-00003` |
| 14 | `tests/cli_runtime/test_sync.py` | `active set 305 --force --no-checkout` | `active set 305` |
| 15 | `tests/cli_runtime/test_workbench.py` | `active set --id scope_id --force` | `active set --id scope_id` |

`commands/active.py::_add_active_set_arguments`が公開するpositional target、`--id`、`--github-issue`だけを使う。Row 15は`active.json`を読む前にactive commandのreturn code 0をassertする。

### 5.4 Row 12 current application contract boundary

次の依存方向を保持する。

```text
commands/new.py
  -> application/contracts.py::CURRENT_CREATABLE_ARTIFACT_TYPES
     -> domain/artifacts.py::CURRENT_CREATABLE_ARTIFACT_TYPES
```

| Path | Existing responsibility |
|---|---|
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/commands/new.py` | `CURRENT_CREATABLE_ARTIFACT_TYPES`を`application.contracts`からimportする。 |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/contracts.py` | Domain catalogueをapplication contractとしてre-exportする。 |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/domain/artifacts.py` | Catalogue valueのsingle source。 |
| `tests/cli_runtime/test_runtime_shell_s11.py` | Layered API structureを検査する。 |

Verified blobsとASTが一致する限り、row 12のProduct/test sourceは変更しない。Row 12はnormal pass観測後、ledgerを`resolved/fixed-in-place`へ移すだけである。

### 5.5 Dogfood generated write surface

次はprovider source変更後にcurrent lifecycle commandで生成する。手編集しない。

- `spec-dock/scripts/spec_dock_runtime/infra/git_cli.py`
- `spec-dock/spec-dock.version`
- `.agents/skills/spec-dock/.spec-dock-provider-slot.json`
- `.agents/skills/spec-dock-grill-with-docs/.spec-dock-provider-slot.json`

### 5.6 Root ledger write surface

`full-regression-ledger.json`のrows 1、3–15だけを`resolved/fixed-in-place`へ一括遷移する。Nodeid、signature、status、disposition、historical top-level fieldsを変更しない。Row 2はbyte-semanticに保持する。

### 5.7 No-touch

- `full-regression-timing-weights.json`
- `tests/conftest.py`
- `scripts/quality/full_regression_baseline.py`
- `scripts/quality/verify_full_regression.py`
- `tests/unit/test_full_regression_baseline.py`
- `.github/workflows/provider-ci.yml`
- `.github/workflows/provider-full-regression.yml`
- #392 lifecycle source、Wire、record、migration、uninstall、recovery、coordination、bootstrap
- Parent Epic R/D/P、ADRs、Register、Integration Branch Contract、Rolling-Wave Contract
- #396のRequirement、Design、Plan、Product source
- `E384-QUAL-001`
- managed `.meta.json`、active state、dependency storage、generated index/tree/diagram
- required contexts、branch protection、merge、revert、Issue close、main

## 6. Exact 14-row work table

| Row | Exact nodeid | Historical signature SHA-256 | Surface | Required correction and protected behavior |
|---:|---|---|---|---|
| 1 | `tests/cli_runtime/test_delete.py::TestCliDelete::test_delete_scrubbed_meta_is_not_reobserved_by_validate_sync_active` | `0d6c418e8c531ed77662b5bb0f166c6370f1b4d995a1ec6ac23452382c34869f` | Test observer | Remove `--force`; deleted metadata remains absent after validate、sync、active observation。 |
| 3 | `tests/cli_runtime/test_import.py::TestCliImport::test_import_accepts_canonical_url_when_origin_is_credentialed_https_remote` | `f149be56ae07e7b774137b1f8f5912076a82838250be9750c886aca7a8392a5f` | Product + observer | Separate read-only identity from publication policy; preserve same-repo acceptance、publication strictness、credential secrecy。 |
| 4 | `tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_regression` | `3f7d32388f2d60f77ec1740aac53fd6d6481f7cb04ef3f3ae7ef09463a29a980` | Test double | Add current descriptor-bound port; accepted parent fallback remains unchanged。 |
| 5 | `tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_load_active_manifest_chain_regression` | `55f2d59d2e1ce7b337462feefbde5c5a84423d07f039ff5fb5dd7bc8b10762ce` | Test double | Keep current active manifest chain and absence of retired workflow authority。 |
| 6 | `tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_re_resolves_inside_lock_when_parent_drifts_regression` | `ab1f703094ed3335d43ff943cb9194266ee2c162758b3c732b47c1c1cee9256a` | Test double | Preserve lock-side parent re-resolution and second-parent creation。 |
| 7 | `tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_numeric_target_uses_resolved_current_repo_slug_for_github_read` | `ea4df2e82010c5a2058e5bfd5b31bb7ada7f4776f8cff44a2457fb50b8a1df70` | Test double | Preserve current repo slug passed to GitHub read and stored linkage。 |
| 8 | `tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_issue_uses_target_repo_slug_for_same_repo_url_when_present` | `22d80f8db459620d13f14e34c9a7fc2ee60b73f4080ac7d181b3a7c69ab1d4f3` | Test double | Preserve explicit target slug and same-repo validation。 |
| 9 | `tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_then_sync_artifact_path_name_content_regression` | `0dbf9314fa763929461775d43ae3e56c51bddcb742e2e329317736f5b1194ef7` | Test double | Preserve accepted artifact path、name、content and generated projection。 |
| 10 | `tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_post_import_sync_negative_path_regression` | `541c15d4ba9564d9256cb2651fe180c2e230760c2fa56ecb389f145fb8723d00` | Test double | Preserve observable sync failure and committed import result。 |
| 11 | `tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_execute_create_plan_reuse_seam` | `44894dc46328aad1a9352cb69a93975a99701b9a9e14f8d5c9dc25470dcf6efd` | Test double | Preserve one `execute_create_plan`、rules symlink、no second writer。 |
| 12 | `tests/cli_runtime/test_runtime_shell_s11.py::TestRuntimeShellS11::test_final_api_call_site_and_structural_regression` | `0c1088f1a15dd18d672fe5707d9add3ffe1593b6ead070d90ba553019c498790` | Product contract, current no-edit | Preserve `commands -> application.contracts -> domain` and all structural assertions; ledger transition only。 |
| 13 | `tests/cli_runtime/test_sync.py::TestCliSync::test_new_and_active_and_sync` | `f9b206f85a7c0ee352b4019eaed232ee02dcf896c150659fa7e8191f125951a6` | Test observer | Remove `--force`; preserve new/active/sync convergence。 |
| 14 | `tests/cli_runtime/test_sync.py::TestCliSync::test_sync_emits_tree_puml_ready_board_at_spec_dock_root` | `3d1b673b92516964bd29b91cf29c8e03c553988dc9e0df7f0a9aee16dc545619` | Test observer | Remove `--force --no-checkout`; preserve tree、PUML、ready-board outputs。 |
| 15 | `tests/cli_runtime/test_workbench.py::TestCliWorkbench::test_copied_workbench_readme_and_payloads_remain_opaque_to_runtime_commands` | `20d53420c38ab501c64346e6e22a0b309b2358191fe74a54ed9c20717ddb09b9` | Test observer | Remove `--force`; assert active success before read; preserve opaque bytes and projection observations。 |

Row 2はread-only resolved/supersededである。Successorは次のexact nodeidのまま保持する。

```text
tests/cli_runtime/test_distribution_cutover.py::test_s40b_retained_skill_identity_matches_current_provider_and_dogfood
```

## 7. Exact node constants

以降のfocused commandsで使用する。

```bash
ROW_1='tests/cli_runtime/test_delete.py::TestCliDelete::test_delete_scrubbed_meta_is_not_reobserved_by_validate_sync_active'
ROW_3='tests/cli_runtime/test_import.py::TestCliImport::test_import_accepts_canonical_url_when_origin_is_credentialed_https_remote'
ROW_4='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_regression'
ROW_5='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_load_active_manifest_chain_regression'
ROW_6='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_parent_fallback_re_resolves_inside_lock_when_parent_drifts_regression'
ROW_7='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_numeric_target_uses_resolved_current_repo_slug_for_github_read'
ROW_8='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_issue_uses_target_repo_slug_for_same_repo_url_when_present'
ROW_9='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_import_then_sync_artifact_path_name_content_regression'
ROW_10='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_post_import_sync_negative_path_regression'
ROW_11='tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::test_execute_create_plan_reuse_seam'
ROW_12='tests/cli_runtime/test_runtime_shell_s11.py::TestRuntimeShellS11::test_final_api_call_site_and_structural_regression'
ROW_13='tests/cli_runtime/test_sync.py::TestCliSync::test_new_and_active_and_sync'
ROW_14='tests/cli_runtime/test_sync.py::TestCliSync::test_sync_emits_tree_puml_ready_board_at_spec_dock_root'
ROW_15='tests/cli_runtime/test_workbench.py::TestCliWorkbench::test_copied_workbench_readme_and_payloads_remain_opaque_to_runtime_commands'
ROW_2_SUCCESSOR='tests/cli_runtime/test_distribution_cutover.py::test_s40b_retained_skill_identity_matches_current_provider_and_dogfood'

ACTIVE_ROWS=(
  "$ROW_1"
  "$ROW_3"
  "$ROW_4"
  "$ROW_5"
  "$ROW_6"
  "$ROW_7"
  "$ROW_8"
  "$ROW_9"
  "$ROW_10"
  "$ROW_11"
  "$ROW_12"
  "$ROW_13"
  "$ROW_14"
  "$ROW_15"
)

S10_ROWS=(
  "$ROW_4"
  "$ROW_5"
  "$ROW_6"
  "$ROW_7"
  "$ROW_8"
  "$ROW_9"
  "$ROW_10"
  "$ROW_11"
)

SELECTION_ROWS=(
  "$ROW_1"
  "$ROW_13"
  "$ROW_14"
  "$ROW_15"
)
```

## 8. Test-first RED reproduction

### 8.1 Current full verifier entry observation

```bash
set +e
env TMPDIR=/private/tmp uv run python -m scripts.quality.verify_full_regression --shards 4
ENTRY_FULL_RC=$?
set -e

test "$ENTRY_FULL_RC" -eq 1

ENTRY_RUN_DIR="$(
  find spec-dock/.workbench/full-regression \
    -mindepth 1 \
    -maxdepth 1 \
    -type d \
    | sort \
    | tail -1
)"

python - "$ENTRY_RUN_DIR/result.json" "$SPEC_FREEZE_SHA" <<'PY'
from pathlib import Path
import json
import sys

result_path, expected_sha = sys.argv[1:]
result = json.loads(Path(result_path).read_text(encoding="utf-8"))

assert result["status"] == "ledger-mismatch"
assert result["candidate_sha"] == expected_sha
assert result["evaluation"]["verified"] is False

violations = {
    (item["code"], item["nodeid"])
    for item in result["evaluation"]["violations"]
}
expected = {
    (
        "signature_mismatch",
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_parent_fallback_regression",
    ),
    (
        "signature_mismatch",
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_load_active_manifest_chain_regression",
    ),
    (
        "signature_mismatch",
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_parent_fallback_re_resolves_inside_lock_when_parent_drifts_regression",
    ),
    (
        "signature_mismatch",
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_import_numeric_target_uses_resolved_current_repo_slug_for_github_read",
    ),
    (
        "signature_mismatch",
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_import_issue_uses_target_repo_slug_for_same_repo_url_when_present",
    ),
    (
        "signature_mismatch",
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_import_then_sync_artifact_path_name_content_regression",
    ),
    (
        "signature_mismatch",
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_post_import_sync_negative_path_regression",
    ),
    (
        "signature_mismatch",
        "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
        "test_execute_create_plan_reuse_seam",
    ),
    (
        "coverage_mismatch",
        "tests/cli_runtime/test_runtime_shell_s11.py::TestRuntimeShellS11::"
        "test_final_api_call_site_and_structural_regression",
    ),
    (
        "signature_mismatch",
        "tests/cli_runtime/test_workbench.py::TestCliWorkbench::"
        "test_copied_workbench_readme_and_payloads_remain_opaque_to_runtime_commands",
    ),
}
assert violations == expected

assert set(result["evaluation"]["active_verified"]) == {
    "tests/cli_runtime/test_delete.py::TestCliDelete::"
    "test_delete_scrubbed_meta_is_not_reobserved_by_validate_sync_active",
    "tests/cli_runtime/test_import.py::TestCliImport::"
    "test_import_accepts_canonical_url_when_origin_is_credentialed_https_remote",
    "tests/cli_runtime/test_sync.py::TestCliSync::test_new_and_active_and_sync",
    "tests/cli_runtime/test_sync.py::TestCliSync::"
    "test_sync_emits_tree_puml_ready_board_at_spec_dock_root",
}
assert result["evaluation"]["resolved_verified"] == [
    "tests/cli_runtime/test_distribution_cutover.py::"
    "test_s40b_retained_skill_identity_matches_issue359_final_source"
]
assert result["evaluation"]["retired_verified"] == []

print("entry-full-verifier-exact-p392-set-ok")
PY
```

Extra violation、missing violation、#392-owned failure、unexpected failureが一つでもあれば停止する。

### 8.2 Row 12 node GREEN、active-ledger RED

```bash
env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  "$ROW_12"
```

Expected: `1 passed`。Current full verifierのrow 12 `coverage_mismatch`は、nodeがnormal passしている一方でledgerがactiveであることによる。Nodeが失敗した場合はsource driftとして停止する。

### 8.3 Row 3 RED

```bash
set +e
env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  "$ROW_3" \
  2>&1 | tee /tmp/iss-00395-row-3-red.log
ROW_3_RED_RC=${PIPESTATUS[0]}
set -e

test "$ROW_3_RED_RC" -eq 1
grep -F \
  'Current GitHub repo scope could not be resolved from origin' \
  /tmp/iss-00395-row-3-red.log
```

Expected: read-only current repository identityがcredential-bearing HTTPS originから解決できず失敗する。Publication userinfo policyを緩和して通してはならない。

### 8.4 Rows 4–11 descriptor-port RED

```bash
set +e
env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  "${S10_ROWS[@]}" \
  2>&1 | tee /tmp/iss-00395-s10-red.log
S10_RED_RC=${PIPESTATUS[0]}
set -e

test "$S10_RED_RC" -eq 1
grep -F 'copy_scaffolded_tree_at' /tmp/iss-00395-s10-red.log
```

Expected: eight nodesが`_StubTemplateScaffolder`にcurrent `copy_scaffolded_tree_at`がないため失敗する。別のapplication behavior failureが混在した場合は停止する。

### 8.5 Rows 1、13、14、15 selection-only RED

```bash
set +e
env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  "${SELECTION_ROWS[@]}" \
  2>&1 | tee /tmp/iss-00395-selection-red.log
SELECTION_RED_RC=${PIPESTATUS[0]}
set -e

test "$SELECTION_RED_RC" -eq 1
grep -E -- '--force|--no-checkout|active\.json' /tmp/iss-00395-selection-red.log
```

Expected: retired active arguments、またはその失敗後に未生成stateを読むことが原因である。Delete、sync、Workbench opacityの別Product defectが観測された場合は停止する。

## 9. Ordered implementation sequence

### 9.1 Rows 4–11 test doubleを最初に修正する

変更対象は`tests/cli_runtime/test_runtime_import_s10.py::_StubTemplateScaffolder`だけである。

1. Current `copy_scaffolded_tree_at`と同じsignatureのmethodを追加する。
2. `self.events`へ`copy_scaffolded_tree_at`を一度記録する。
3. Method内でcurrent `spec_dock_runtime.infra.template_scaffolder.copy_scaffolded_tree_at`をimportし、`src_dir`、`dest_dir`、`dest_dir_fd`、`replacements`をそのまま渡す。
4. Existing `copy_scaffolded_tree`を削除しない。
5. Existing assertions、active-state reads、parent resolution、GitHub reads、artifact projection assertionsを削除・弱化しない。
6. `application/create_node.py`、`application/ports.py`、`infra/template_scaffolder.py`を変更しない。

GREEN command:

```bash
env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  "${S10_ROWS[@]}"
```

Expected: `8 passed`、skip 0、xfail 0、xpass 0、error 0。

### 9.2 Rows 1、13、14、15 selection-only observerを修正する

Exact replacements:

- Row 1: `active set --id iss-00058 --force`を`active set --id iss-00058`へ変更する。
- Row 13: `active set iss-00003 --force`を`active set iss-00003`へ変更する。
- Row 14: `active set 305 --force --no-checkout`を`active set 305`へ変更する。
- Row 15: `active set --id scope_id --force`を`active set --id scope_id`へ変更し、`active.json` readより先にreturn code 0をassertする。

次を保持する。

- Row 1のdelete後非再観測
- Row 13のnew/active/sync収束
- Row 14のtree、PUML、ready-board内容
- Row 15のWorkbench README/payload bytes、active fields、validate/sync/deps/active observation前後比較

GREEN command:

```bash
env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  "${SELECTION_ROWS[@]}"
```

Expected: `4 passed`、skip 0、xfail 0、xpass 0、error 0。

### 9.3 Row 3 observerを先に強化する

Existing row 3 nodeをrenameせず、successful import assertionを保持したまま、`p.stdout + p.stderr`について次を追加する。

- Synthetic credential text `token`を含まない。
- `https://token@github.com/example/repo.git`を含まない。
- Existing success textを`stdout`に含む。

Product edit前に同nodeを再実行し、repository identity unresolvedでREDのままであることを確認する。Secret assertionを削除してGREENにしてはならない。

### 9.4 Product row 3を修正する

変更対象は、provider-side sourceの次の三existing symbolだけである。

1. `_parse_github_repo_slug`
   - `_remote_has_userinfo`によるpolicy rejectionをidentity parserから除去する。
   - GitHub host/path parsing、owner/repo non-empty、lowercase normalized slugを維持する。
   - Raw URLまたはcredentialをreturnしない。

2. `origin_github_repo_slug`
   - `origin_github_publication_endpoint`を呼ばない。
   - `_remote_get_url(repo_root, push=False)`からfetch originだけを取得する。
   - `_parse_github_repo_slug`の結果をread-only identityとして返す。

3. `origin_github_publication_endpoint`
   - Fetch URLとpush URLを取得する。
   - `_parse_github_repo_slug`より前に、fetchまたはpushのuserinfoを明示的に拒否する。
   - Diagnosticでは必ず`_redact_remote_url`を使用する。
   - Fetch/pushの両方がGitHub repository identityへparseできることを要求する。
   - Fetch slugとpush slugのexact equalityを維持する。
   - Accepted時だけ`(fetch_slug, push_url)`を返す。

`_remote_get_url`、`_remote_has_userinfo`、`_redact_remote_url`のsignatureを変更しない。New public function、new port、new CLI flag、new request/result typeを追加しない。

Row 3 GREEN:

```bash
env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  "$ROW_3"
```

Expected: `1 passed`、combined stdout/stderrへsynthetic credential material 0。

Publication strictness diagnostic:

```bash
env PYTHONPATH=src/spec_dock/assets/spec_dock/scripts \
  uv run python - <<'PY'
from pathlib import Path
import subprocess
import tempfile

from spec_dock_runtime.infra.git_cli import (
    origin_github_publication_endpoint,
    origin_github_repo_slug,
)

with tempfile.TemporaryDirectory() as temporary:
    repository = Path(temporary)
    subprocess.run(["git", "init", "-q"], cwd=repository, check=True)
    subprocess.run(
        [
            "git",
            "remote",
            "add",
            "origin",
            "https://token@github.com/Example/Repo.git",
        ],
        cwd=repository,
        check=True,
    )

    assert origin_github_repo_slug(repository) == "example/repo"

    try:
        origin_github_publication_endpoint(repository)
    except RuntimeError as error:
        text = str(error)
        assert "https://token@github.com" not in text
        assert "token@" not in text
        assert "<credential-bearing remote>" in text
    else:
        raise AssertionError(
            "publication endpoint accepted credential-bearing origin"
        )

    subprocess.run(
        [
            "git",
            "remote",
            "set-url",
            "origin",
            "https://github.com/Example/Repo.git",
        ],
        cwd=repository,
        check=True,
    )
    subprocess.run(
        [
            "git",
            "remote",
            "set-url",
            "--push",
            "origin",
            "https://github.com/Other/Repo.git",
        ],
        cwd=repository,
        check=True,
    )

    try:
        origin_github_publication_endpoint(repository)
    except RuntimeError as error:
        assert "fetch/push mismatch" in str(error)
    else:
        raise AssertionError(
            "publication endpoint accepted mismatched fetch/push repositories"
        )

print("identity-publication-separation-ok")
PY
```

Expected: read-only identity resolves to`example/repo`、publicationはuserinfoをredacted rejection、fetch/push mismatchをreject。

### 9.5 Row 12 source drift guard

Row 12のsourceを変更する前に、次を実行する。Passした場合はProduct/test sourceを変更しない。

```bash
python - <<'PY'
from pathlib import Path
import ast

new_path = Path(
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/commands/new.py"
)
contracts_path = Path(
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/"
    "application/contracts.py"
)
domain_path = Path(
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/"
    "domain/artifacts.py"
)

new_source = new_path.read_text(encoding="utf-8")
contracts_source = contracts_path.read_text(encoding="utf-8")
domain_source = domain_path.read_text(encoding="utf-8")

ast.parse(new_source)
ast.parse(contracts_source)
ast.parse(domain_source)

assert "from spec_dock_runtime.application.contracts import" in new_source
assert "CURRENT_CREATABLE_ARTIFACT_TYPES" in new_source
assert "spec_dock_runtime.domain.artifacts" not in new_source

assert "from spec_dock_runtime.domain.artifacts import" in contracts_source
assert "CURRENT_CREATABLE_ARTIFACT_TYPES" in contracts_source
assert "CURRENT_CREATABLE_ARTIFACT_TYPES" in domain_source

print("row-12-application-contract-ok")
PY

env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  "$ROW_12"
```

Expected: guard pass、`1 passed`。次のいずれかならsource driftとしてstop-and-returnする。

- `commands/new.py`が`domain.artifacts`を直接importしている。
- `application/contracts.py`がcatalogueをre-exportしていない。
- `domain/artifacts.py`がsingle catalogue authorityでない。
- Structural nodeがnormal passしない。
- Accepted boundaryを回復するために新しいlayer、type、catalogue copyが必要になる。

### 9.6 Combined pre-ledger GREEN

14 active historical nodesとrow 2 successorを、global ledger completeness checkを使わないshard modeで実行する。

```bash
env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  "${ACTIVE_ROWS[@]}" \
  "$ROW_2_SUCCESSOR"
```

Expected: `15 passed`、failed 0、error 0、skipped 0、xfailed 0、xpassed 0。これを満たす前にledgerを変更しない。

### 9.7 Provider-first dogfood projection

Provider sourceに対するfocused gatesを先に実行する。

```bash
env TMPDIR=/private/tmp uv run pytest \
  -q \
  --tb=short \
  tests/cli_runtime/test_import.py \
  tests/cli_runtime/test_runtime_import_s10.py \
  tests/cli_runtime/test_runtime_shell_s11.py

env TMPDIR=/private/tmp make lint
```

Expected: exit 0。

次にcurrent lifecycle commandでcomplete dogfood candidateへ投影する。

```bash
env TMPDIR=/private/tmp uv run spec-dock update . --json \
  | tee /tmp/iss-00395-dogfood-update.json
```

Generated filesを手編集しない。Projection後に次を検査する。

```bash
cmp -s \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py \
  spec-dock/scripts/spec_dock_runtime/infra/git_cli.py

python - <<'PY'
from pathlib import Path
import json

record = json.loads(
    Path("spec-dock/spec-dock.version").read_text(encoding="utf-8")
)
spec_dock_marker = json.loads(
    Path(
        ".agents/skills/spec-dock/.spec-dock-provider-slot.json"
    ).read_text(encoding="utf-8")
)
grill_marker = json.loads(
    Path(
        ".agents/skills/spec-dock-grill-with-docs/"
        ".spec-dock-provider-slot.json"
    ).read_text(encoding="utf-8")
)

assert record["schema_version"] == 1
assert record["state"] == "ready"
assert record["operation"] is None
assert record["version"] == "0.2.4"
assert record["seed_policy"] == "preserve-only"
assert record["skill_slots"] == {
    "spec-dock": "0.2.4",
    "spec-dock-grill-with-docs": "0.2.4",
}
assert isinstance(record["candidate_digest"], str)
assert len(record["candidate_digest"]) == 64

assert spec_dock_marker == {
    "schema_version": 1,
    "slot": ".agents/skills/spec-dock",
    "version": "0.2.4",
    "candidate_digest": record["candidate_digest"],
}
assert grill_marker == {
    "schema_version": 1,
    "slot": ".agents/skills/spec-dock-grill-with-docs",
    "version": "0.2.4",
    "candidate_digest": record["candidate_digest"],
}

print(f"dogfood-candidate={record['candidate_digest']}")
PY
```

Package/dogfood parity:

```bash
env TMPDIR=/private/tmp uv run pytest \
  -q \
  --tb=short \
  tests/integration/test_provider_lifecycle_dogfood.py::test_t13_source_wheel_sdist_installed_and_dogfood_candidate_are_identical
```

Expected: runtime mirror byte-equal、record/markers digest equal、version 0.2.4、state ready、operation null、seed policy preserve-only、parity node pass。

次が発生した場合はprojection diffを採用せず停止する。

- `pyproject.toml` version変更
- lifecycle source/schema/wire変更
- two skill `SKILL.md` bytes変更
- protected data変更
- initiatives、Artifacts、Workbench、active state変更
- ledger、timing、policy、workflow変更
- four rootsにrow 3 runtime mirror以外の意図しないtracked diff

### 9.8 Atomic ledger transition

Checkpoint 9.6と9.7がGREENになった後だけ実行する。

```bash
python - <<'PY'
from pathlib import Path
import json

path = Path("full-regression-ledger.json")
payload = json.loads(path.read_text(encoding="utf-8"))
rows = payload["failure_paths"]

fixed_in_place = {
    "tests/cli_runtime/test_delete.py::TestCliDelete::"
    "test_delete_scrubbed_meta_is_not_reobserved_by_validate_sync_active",
    "tests/cli_runtime/test_import.py::TestCliImport::"
    "test_import_accepts_canonical_url_when_origin_is_credentialed_https_remote",
    "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
    "test_parent_fallback_regression",
    "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
    "test_load_active_manifest_chain_regression",
    "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
    "test_parent_fallback_re_resolves_inside_lock_when_parent_drifts_regression",
    "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
    "test_import_numeric_target_uses_resolved_current_repo_slug_for_github_read",
    "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
    "test_import_issue_uses_target_repo_slug_for_same_repo_url_when_present",
    "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
    "test_import_then_sync_artifact_path_name_content_regression",
    "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
    "test_post_import_sync_negative_path_regression",
    "tests/cli_runtime/test_runtime_import_s10.py::TestRuntimeImportS10::"
    "test_execute_create_plan_reuse_seam",
    "tests/cli_runtime/test_runtime_shell_s11.py::TestRuntimeShellS11::"
    "test_final_api_call_site_and_structural_regression",
    "tests/cli_runtime/test_sync.py::TestCliSync::"
    "test_new_and_active_and_sync",
    "tests/cli_runtime/test_sync.py::TestCliSync::"
    "test_sync_emits_tree_puml_ready_board_at_spec_dock_root",
    "tests/cli_runtime/test_workbench.py::TestCliWorkbench::"
    "test_copied_workbench_readme_and_payloads_remain_opaque_to_runtime_commands",
}

assert len(rows) == 15
assert {
    row["nodeid"]
    for row in rows
    if row["lifecycle"] == "active"
} == fixed_in_place

row_2_before = json.dumps(
    rows[1],
    sort_keys=True,
    ensure_ascii=False,
)

for row in rows:
    if row["nodeid"] not in fixed_in_place:
        continue

    assert row["lifecycle"] == "active"
    assert "resolution_mode" not in row
    assert "successor_nodeid" not in row

    row["lifecycle"] = "resolved"
    row["resolution_mode"] = "fixed-in-place"

assert json.dumps(
    rows[1],
    sort_keys=True,
    ensure_ascii=False,
) == row_2_before

path.write_text(
    json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
    encoding="utf-8",
)
print("ledger-transitioned-15-0-15")
PY
```

Shape validation:

```bash
python - <<'PY'
from pathlib import Path
import json

rows = json.loads(
    Path("full-regression-ledger.json").read_text(encoding="utf-8")
)["failure_paths"]

assert len(rows) == 15
assert sum(row["lifecycle"] == "active" for row in rows) == 0
assert sum(row["lifecycle"] == "resolved" for row in rows) == 15
assert sum(
    row.get("resolution_mode") == "fixed-in-place"
    for row in rows
) == 14
assert sum(
    row.get("resolution_mode") == "superseded"
    for row in rows
) == 1

assert rows[1]["nodeid"] == (
    "tests/cli_runtime/test_distribution_cutover.py::"
    "test_s40b_retained_skill_identity_matches_issue359_final_source"
)
assert rows[1]["successor_nodeid"] == (
    "tests/cli_runtime/test_distribution_cutover.py::"
    "test_s40b_retained_skill_identity_matches_current_provider_and_dogfood"
)

print("baseline=15/0/15 fixed=14 superseded=1")
PY
```

Historical nodeid、both signature fields、status、disposition、top-level historical metadataを変更しない。

## 10. Verification sequence

### 10.1 Focused post-ledger GREEN

```bash
env TMPDIR=/private/tmp uv run pytest \
  -q \
  --tb=short \
  tests/unit/test_full_regression_baseline.py

env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  "${ACTIVE_ROWS[@]}" \
  "$ROW_2_SUCCESSOR"
```

Expected:

- evaluator unit tests exit 0
- exact 15 observed nodes normal pass
- skip/xfail/xpass/error 0

### 10.2 Working-tree full verifier GREENはprovisional

```bash
export WORKTREE_DIFF_SHA256="$(
  git diff --binary \
    | shasum -a 256 \
    | awk '{print $1}'
)"

test -n "$(git status --porcelain)"

env TMPDIR=/private/tmp uv run python \
  -m scripts.quality.verify_full_regression \
  --shards 4

WORKTREE_RUN_DIR="$(
  find spec-dock/.workbench/full-regression \
    -mindepth 1 \
    -maxdepth 1 \
    -type d \
    | sort \
    | tail -1
)"

python - "$WORKTREE_RUN_DIR/result.json" "$SPEC_FREEZE_SHA" "$WORKTREE_DIFF_SHA256" <<'PY'
from pathlib import Path
import json
import sys

result_path, expected_head_sha, diff_sha256 = sys.argv[1:]
result = json.loads(Path(result_path).read_text(encoding="utf-8"))

assert result["candidate_sha"] == expected_head_sha
assert result["status"] == "verified"
assert result["evaluation"]["verified"] is True
assert result["evaluation"]["active_verified"] == []
assert len(result["evaluation"]["resolved_verified"]) == 15
assert result["evaluation"]["retired_verified"] == []
assert result["evaluation"]["violations"] == []
assert len(diff_sha256) == 64

print(
    "working-tree-full-regression-green "
    f"diff_sha256={diff_sha256}"
)
PY
```

Current verifierはGit HEADを`candidate_sha`へ記録し、uncommitted bytesのidentityを記録しない。このrunはfunctional GREENに限る。`WORKTREE_DIFF_SHA256`と組み合わせてprovisional evidenceとして記録し、merge-ready evidenceへ昇格しない。

### 10.3 Ordinary、lifecycle、platform、package、lint、validate

```bash
env TMPDIR=/private/tmp uv run pytest -q --tb=short

env TMPDIR=/private/tmp uv run pytest \
  -q \
  --tb=short \
  tests/unit/provider_lifecycle

env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  tests/cli_runtime/test_distribution_cutover.py

env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  tests/cli_runtime/test_provider_lifecycle_bootstrap.py \
  tests/cli_runtime/test_provider_lifecycle_handoff.py \
  tests/cli_runtime/test_generation_checkout.py \
  tests/cli_runtime/test_worktree_lifecycle_coordination.py

env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  tests/integration/test_epic_00343_distribution.py

env TMPDIR=/private/tmp uv run pytest \
  -q \
  --tb=short \
  tests/integration/test_provider_lifecycle_dogfood.py

env TMPDIR=/private/tmp make lint

./spec-dock/scripts/spec-dock validate \
  | tee /tmp/iss-00395-post-change-validate.txt
grep -F 'nodes=236' /tmp/iss-00395-post-change-validate.txt
```

Expected:

- 全command exit 0
- failure/error 0
- Ordinary laneのcurrent policy skip reason不変
- Provider lifecycle behavior不変
- Source/wheel/sdist/installed/dogfood candidate parity pass
- Ruff check、Ruff format、mypy pass
- SpecDock validation `nodes=236`

### 10.4 Policy、lifecycle、row 12 no-touch

```bash
git diff --exit-code "$SPEC_FREEZE_SHA" -- \
  full-regression-timing-weights.json \
  tests/conftest.py \
  scripts/quality/full_regression_baseline.py \
  scripts/quality/verify_full_regression.py \
  tests/unit/test_full_regression_baseline.py \
  .github/workflows/provider-ci.yml \
  .github/workflows/provider-full-regression.yml \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/import_node.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/repo_context.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/ports.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/cli/bootstrap.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/create_node.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/template_scaffolder.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/commands/new.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/contracts.py \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/domain/artifacts.py \
  tests/cli_runtime/test_runtime_shell_s11.py
```

Parent、#392、#396 no-touch:

```bash
git diff --exit-code "$SPEC_FREEZE_SHA" -- \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/requirement.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/design.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/plan.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/artifacts/provider-lifecycle-wire-contract.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/artifacts/active-failure-disposition-register.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/artifacts/epic-integration-branch-contract.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/artifacts/rolling-wave-issue-elaboration-contract.md \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00392-provider-lifecycle-and-regression-gate-hard-cutover \
  spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00396-build-once-provider-gate-and-regression-policy-cutover
```

Required-fast and timing:

```bash
python - <<'PY'
from pathlib import Path
import ast
import json

source = Path("tests/conftest.py").read_text(encoding="utf-8")
tree = ast.parse(source)

required = None
for node in tree.body:
    if not isinstance(node, ast.Assign):
        continue
    if not any(
        isinstance(target, ast.Name)
        and target.id == "REQUIRED_FAST_NODE_IDS"
        for target in node.targets
    ):
        continue
    required = (
        ast.literal_eval(node.value.args[0])
        if isinstance(node.value, ast.Call)
        else ast.literal_eval(node.value)
    )
    break

assert set(required) == {
    "tests/unit/cli/test_cli_smoke.py::TestCliSmoke::"
    "test_active_set_by_id_succeeds_through_runtime_subprocess",
    "tests/unit/infra/test_init_update.py::TestInitUpdate::"
    "test_checked_in_dogfooding_mirror_docs_match_provider_assets",
    "tests/unit/infra/test_init_update.py::TestInitUpdate::"
    "test_issue_68_workflow_seed_matches_repo_root_ci_workflow",
    "tests/unit/infra/test_init_update.py::TestInitUpdate::"
    "test_issue_68_provider_only_workflow_is_not_shipped_via_install_root",
}

timing = json.loads(
    Path("full-regression-timing-weights.json").read_text(encoding="utf-8")
)
assert len(timing["node_seconds"]) == 243

print("required-fast=4 timing=243")
PY
```

### 10.5 Exact changed-file set

Implementation diffは次の11 tracked pathsだけでなければならない。

```text
full-regression-ledger.json
src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py
spec-dock/scripts/spec_dock_runtime/infra/git_cli.py
spec-dock/spec-dock.version
.agents/skills/spec-dock/.spec-dock-provider-slot.json
.agents/skills/spec-dock-grill-with-docs/.spec-dock-provider-slot.json
tests/cli_runtime/test_delete.py
tests/cli_runtime/test_import.py
tests/cli_runtime/test_runtime_import_s10.py
tests/cli_runtime/test_sync.py
tests/cli_runtime/test_workbench.py
```

```bash
python - "$SPEC_FREEZE_SHA" <<'PY'
import subprocess
import sys

base = sys.argv[1]
expected = {
    "full-regression-ledger.json",
    "src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py",
    "spec-dock/scripts/spec_dock_runtime/infra/git_cli.py",
    "spec-dock/spec-dock.version",
    ".agents/skills/spec-dock/.spec-dock-provider-slot.json",
    ".agents/skills/spec-dock-grill-with-docs/.spec-dock-provider-slot.json",
    "tests/cli_runtime/test_delete.py",
    "tests/cli_runtime/test_import.py",
    "tests/cli_runtime/test_runtime_import_s10.py",
    "tests/cli_runtime/test_sync.py",
    "tests/cli_runtime/test_workbench.py",
}
actual = set(
    subprocess.check_output(
        ["git", "diff", "--name-only", base],
        text=True,
    ).splitlines()
)
if actual != expected:
    raise SystemExit(
        {
            "stage": "implementation-file-set",
            "expected": sorted(expected),
            "actual": sorted(actual),
        }
    )
print("implementation-file-set-ok")
PY

git diff --check
git status --short
```

Untracked cache、temporary log、credential-bearing output、`.workbench` raw evidenceをcommit対象にしない。

## 11. Exact candidate freeze

### 11.1 Commit/push authorization

`COMMIT_PUSH_AUTHORIZED=true`がexecution packetにある場合だけ実行する。

```bash
: "${COMMIT_PUSH_AUTHORIZED:?COMMIT_PUSH_AUTHORIZED is required}"
test "$COMMIT_PUSH_AUTHORIZED" = "true"
```

Stageするpathsはexact 11 pathsだけである。

```bash
git add -- \
  full-regression-ledger.json \
  src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py \
  spec-dock/scripts/spec_dock_runtime/infra/git_cli.py \
  spec-dock/spec-dock.version \
  .agents/skills/spec-dock/.spec-dock-provider-slot.json \
  .agents/skills/spec-dock-grill-with-docs/.spec-dock-provider-slot.json \
  tests/cli_runtime/test_delete.py \
  tests/cli_runtime/test_import.py \
  tests/cli_runtime/test_runtime_import_s10.py \
  tests/cli_runtime/test_sync.py \
  tests/cli_runtime/test_workbench.py

git diff --cached --check
test -z "$(git diff --name-only)"
test -z "$(git ls-files --others --exclude-standard)"

git commit -m "fix(iss-00395): terminalize regression baseline"

export IMPLEMENTATION_SHA="$(git rev-parse HEAD)"
export IMPLEMENTATION_TREE="$(git rev-parse 'HEAD^{tree}')"

git push origin \
  "HEAD:refs/heads/$ISSUE_BRANCH"

test "$(git rev-parse '@{upstream}')" = "$IMPLEMENTATION_SHA"
test "$(
  git ls-remote --heads origin "refs/heads/$ISSUE_BRANCH" \
    | cut -f1
)" = "$IMPLEMENTATION_SHA"
test -z "$(git status --porcelain)"
```

### 11.2 Exact clean full verifier

```bash
env TMPDIR=/private/tmp uv run python \
  -m scripts.quality.verify_full_regression \
  --shards 4

EXACT_RUN_DIR="$(
  find spec-dock/.workbench/full-regression \
    -mindepth 1 \
    -maxdepth 1 \
    -type d \
    | sort \
    | tail -1
)"

python - "$EXACT_RUN_DIR/result.json" "$IMPLEMENTATION_SHA" <<'PY'
from pathlib import Path
import json
import sys

result_path, implementation_sha = sys.argv[1:]
result = json.loads(Path(result_path).read_text(encoding="utf-8"))

assert result["candidate_sha"] == implementation_sha
assert result["status"] == "verified"
assert result["evaluation"]["verified"] is True
assert result["evaluation"]["active_verified"] == []
assert len(result["evaluation"]["resolved_verified"]) == 15
assert result["evaluation"]["retired_verified"] == []
assert result["evaluation"]["violations"] == []

print("exact-candidate-full-regression-green")
PY
```

### 11.3 Exact clean gate rerun

同じ`IMPLEMENTATION_SHA`で全commandを再実行する。

```bash
test "$(git rev-parse HEAD)" = "$IMPLEMENTATION_SHA"

env TMPDIR=/private/tmp uv run pytest -q --tb=short

env TMPDIR=/private/tmp uv run pytest \
  -q \
  --tb=short \
  tests/unit/provider_lifecycle

env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  tests/cli_runtime/test_distribution_cutover.py

env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  tests/cli_runtime/test_provider_lifecycle_bootstrap.py \
  tests/cli_runtime/test_provider_lifecycle_handoff.py \
  tests/cli_runtime/test_generation_checkout.py \
  tests/cli_runtime/test_worktree_lifecycle_coordination.py

env TMPDIR=/private/tmp uv run pytest \
  --run-full-regression \
  --full-regression-shard \
  -q \
  --tb=short \
  tests/integration/test_epic_00343_distribution.py

env TMPDIR=/private/tmp uv run pytest \
  -q \
  --tb=short \
  tests/integration/test_provider_lifecycle_dogfood.py

env TMPDIR=/private/tmp make lint

./spec-dock/scripts/spec-dock validate

test "$(git rev-parse HEAD)" = "$IMPLEMENTATION_SHA"
test -z "$(git status --porcelain)"
```

### 11.4 Independent implementation reviews

Exact clean pushed`IMPLEMENTATION_SHA`へ次を別々に実行する。

1. `chatgpt-code-review-strict`
   - fresh independent browser session
   - exact repository、branch、full SHAをGitHub connectorで再検証
   - Requirement、Design、Plan、本handoff、14 rows、diff、RED/GREEN、full verifier、dogfood、no-touch evidenceを入力
   - Acceptance: `review_status=pass`、P0=0、P1=0

2. `chatgpt-final-quality-gate-strict-v2`
   - GPT-5.6 Sol + Pro
   - exact same clean pushed full SHA
   - Acceptance: `status=pass`、`coverage_complete=true`、P0=0、P1=0、`unreviewed_areas=[]`、`unresolved_items=[]`

Finding修正でcommitが変わった場合、affected focused tests、exact full verifier、ordinary/lifecycle/package/lint/validate、Code Review Strict、Final Quality Gate Strictを新しいexact SHAへ再束縛する。過去review receiptを流用しない。

## 12. 禁止事項

- Product実装許可前のProduct、test、ledger変更
- `active set --force`または`--no-checkout`の復活
- Productionを`copy_scaffolded_tree`へ戻すこと
- `commands/new.py`から`domain.artifacts`を直接importすること
- Artifact catalogueの複製、新旧typeの二重正本
- Publication endpointでuserinfoを許可すること
- Fetch/push slug equalityを削除すること
- Credential-bearing URL、username、password、tokenをstdout、stderr、exception、evidenceへ出すこと
- Importのsame-repository validationを弱めること
- Skip、xfail、approved failure、assertion削除・弱化
- Node rename、signature rewrite、row delete、silent retirement、successor substitution
- Timing、sharder、policy hook、required-fast、current workflowsの変更
- Lifecycle wire、schema、record、migration、uninstall、recovery、coordination、bootstrapの変更
- `E384-QUAL-001`のimplementation、value変更、再解釈
- Issue #396のpolicy retirement、required-context transition、main merge
- `.meta.json`、active state、dependency storage、generated projectionの手編集
- Integration branch direct push
- AgentによるPR merge、revert、required-context変更、Issue close
- Partial row merge、ledger-only merge、Product-only merge、test-only merge
- Automatic rollback、old writer fallback、別Issueの自動作成
- Rate limitを理由とするtest、bundle、review範囲の縮小
- 未確認path/symbolを推測して追加すること

## 13. Stop-and-return

### 13.1 Stop conditions

次のいずれかで直ちに停止する。

- Repository、branch、P392 SHA/tree、spec freeze SHA、upstream、remoteの不一致
- Dirty worktree、untracked Product file、同時writerの存在
- P392からelaboration inputまでに二文書以外の差分がある
- Elaboration inputからspec freezeまでにsix pack files以外の差分がある
- Baseline row、signature、order、15/14/1 count、row 2 successor、timing 243のdrift
- Entry verifierの許容集合外violation
- Current pathまたはsymbolが存在しない
- Row 12 current application contractが失われている
- Same-repo acceptanceとpublication strictnessをexisting boundaryで両立できない
- Credential secrecyを維持できない
- Test harness修正後にaccepted assertionが別原因で失敗する
- Dogfood projectionがversion、lifecycle、protected data、policyへ波及する
- Ledger遷移前に14 rowsとrow 2 successorがnormal passしない
- Lifecycle wire、`E384-QUAL-001`、policy retirement、workflow redesign、main mergeが必要になる
- New Product、security、policy、parent decisionが必要になる
- `owner_decisions_required`がnon-emptyになる

停止後に自動再試行、別branch fallback、認証設定変更、force operation、new Issue作成を行わない。

### 13.2 Stop-and-return JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Issue395StopAndReturn",
  "type": "object",
  "required": [
    "issue",
    "stage",
    "repository",
    "branch",
    "p392_sha",
    "spec_freeze_sha",
    "observed_head_sha",
    "contract_id",
    "row_ordinal",
    "nodeid",
    "expected",
    "actual",
    "changed_paths",
    "observed_operations",
    "secret_redacted",
    "owner_decision_required",
    "next_check"
  ],
  "properties": {
    "issue": {
      "const": "iss-00395"
    },
    "stage": {
      "enum": [
        "preflight",
        "entry-red",
        "test-double-edit",
        "selection-observer-edit",
        "product-row-3-edit",
        "row-12-drift-guard",
        "combined-pre-ledger-green",
        "dogfood-projection",
        "ledger-transition",
        "focused-green",
        "working-tree-full-verifier",
        "exact-candidate-freeze",
        "exact-full-verifier",
        "ordinary-gates",
        "strict-code-review",
        "final-quality-gate",
        "pr",
        "post-merge-b1",
        "post-merge-b2",
        "rollback"
      ]
    },
    "repository": {
      "const": "chemitaro/spec-dock"
    },
    "branch": {
      "const": "iss-00395-regression-baseline-terminalization-and-product-defect-repair"
    },
    "p392_sha": {
      "const": "921bf7512c72bfa2887673cb7ec9bc512cec6ff3"
    },
    "spec_freeze_sha": {
      "type": "string",
      "pattern": "^[0-9a-f]{40}$"
    },
    "observed_head_sha": {
      "type": "string",
      "pattern": "^[0-9a-f]{40}$"
    },
    "contract_id": {
      "type": "string",
      "minLength": 1
    },
    "row_ordinal": {
      "anyOf": [
        {
          "type": "null"
        },
        {
          "enum": [
            1,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15
          ]
        }
      ]
    },
    "nodeid": {
      "anyOf": [
        {
          "type": "null"
        },
        {
          "type": "string",
          "pattern": "^tests/.+::.+$"
        }
      ]
    },
    "expected": {
      "type": "string",
      "minLength": 1
    },
    "actual": {
      "type": "string",
      "minLength": 1
    },
    "changed_paths": {
      "type": "array",
      "items": {
        "type": "string",
        "minLength": 1
      },
      "uniqueItems": true
    },
    "observed_operations": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": [
          "operation",
          "result"
        ],
        "properties": {
          "operation": {
            "type": "string",
            "minLength": 1
          },
          "result": {
            "type": "string",
            "minLength": 1
          }
        },
        "additionalProperties": false
      }
    },
    "secret_redacted": {
      "const": true
    },
    "owner_decision_required": {
      "type": "boolean"
    },
    "next_check": {
      "type": "string",
      "minLength": 1
    }
  },
  "additionalProperties": false
}
```

`owner_decision_required=true`となった場合は、実装を継続せずparent ownerへ返す。Synthetic credentialを除き、credential、token、private absolute path、秘密情報をpayloadへ含めない。

## 14. Implementation evidence schema

Completion receiptは次を満たす。Working-treeだけのcandidateは`merge_ready=false`とし、exact clean pushed implementation SHA、strict reviews、全rerunが揃うまで`merge_ready=true`を記録しない。

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Issue395ImplementationReceipt",
  "type": "object",
  "required": [
    "repository",
    "branch",
    "p392_sha",
    "spec_freeze_sha",
    "candidate_state",
    "implementation_sha",
    "implementation_tree",
    "working_tree_clean",
    "changed_files",
    "changed_symbols",
    "rows",
    "commands",
    "full_verifier",
    "ledger",
    "policy_no_touch",
    "lifecycle_no_touch",
    "dogfood",
    "reviews",
    "unresolved_findings",
    "merge_ready"
  ],
  "properties": {
    "repository": {
      "const": "chemitaro/spec-dock"
    },
    "branch": {
      "const": "iss-00395-regression-baseline-terminalization-and-product-defect-repair"
    },
    "p392_sha": {
      "const": "921bf7512c72bfa2887673cb7ec9bc512cec6ff3"
    },
    "spec_freeze_sha": {
      "type": "string",
      "pattern": "^[0-9a-f]{40}$"
    },
    "candidate_state": {
      "enum": [
        "working-tree-provisional",
        "clean-pushed-exact"
      ]
    },
    "implementation_sha": {
      "anyOf": [
        {
          "type": "null"
        },
        {
          "type": "string",
          "pattern": "^[0-9a-f]{40}$"
        }
      ]
    },
    "implementation_tree": {
      "anyOf": [
        {
          "type": "null"
        },
        {
          "type": "string",
          "pattern": "^[0-9a-f]{40}$"
        }
      ]
    },
    "working_tree_clean": {
      "type": "boolean"
    },
    "changed_files": {
      "type": "array",
      "items": {
        "type": "string",
        "minLength": 1
      },
      "uniqueItems": true
    },
    "changed_symbols": {
      "type": "array",
      "items": {
        "type": "string",
        "minLength": 1
      },
      "uniqueItems": true
    },
    "rows": {
      "type": "array",
      "minItems": 14,
      "maxItems": 14,
      "items": {
        "type": "object",
        "required": [
          "ordinal",
          "nodeid",
          "signature_sha256",
          "repair_surface",
          "red",
          "green",
          "protected_assertions",
          "ledger_before",
          "ledger_after"
        ],
        "properties": {
          "ordinal": {
            "type": "integer",
            "enum": [
              1,
              3,
              4,
              5,
              6,
              7,
              8,
              9,
              10,
              11,
              12,
              13,
              14,
              15
            ]
          },
          "nodeid": {
            "type": "string",
            "pattern": "^tests/.+::.+$"
          },
          "signature_sha256": {
            "type": "string",
            "pattern": "^[0-9a-f]{64}$"
          },
          "repair_surface": {
            "enum": [
              "test-observer",
              "test-double",
              "product",
              "product-contract-no-edit"
            ]
          },
          "red": {
            "type": "object",
            "required": [
              "command",
              "observed_failure"
            ],
            "properties": {
              "command": {
                "type": "string",
                "minLength": 1
              },
              "observed_failure": {
                "type": "string",
                "minLength": 1
              }
            },
            "additionalProperties": false
          },
          "green": {
            "type": "object",
            "required": [
              "command",
              "exit_code",
              "result"
            ],
            "properties": {
              "command": {
                "type": "string",
                "minLength": 1
              },
              "exit_code": {
                "const": 0
              },
              "result": {
                "type": "string",
                "minLength": 1
              }
            },
            "additionalProperties": false
          },
          "protected_assertions": {
            "type": "array",
            "minItems": 1,
            "items": {
              "type": "string",
              "minLength": 1
            }
          },
          "ledger_before": {
            "const": "active"
          },
          "ledger_after": {
            "const": "resolved/fixed-in-place"
          }
        },
        "additionalProperties": false
      }
    },
    "commands": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": [
          "command",
          "exit_code",
          "observed_sha",
          "result"
        ],
        "properties": {
          "command": {
            "type": "string",
            "minLength": 1
          },
          "exit_code": {
            "const": 0
          },
          "observed_sha": {
            "type": "string",
            "pattern": "^[0-9a-f]{40}$"
          },
          "result": {
            "type": "string",
            "minLength": 1
          },
          "artifact_path": {
            "anyOf": [
              {
                "type": "null"
              },
              {
                "type": "string"
              }
            ]
          },
          "artifact_sha256": {
            "anyOf": [
              {
                "type": "null"
              },
              {
                "type": "string",
                "pattern": "^[0-9a-f]{64}$"
              }
            ]
          }
        },
        "additionalProperties": false
      }
    },
    "full_verifier": {
      "type": "object",
      "required": [
        "candidate_sha",
        "status",
        "verified",
        "active_verified",
        "resolved_verified_count",
        "retired_verified",
        "violations",
        "result_path",
        "result_sha256"
      ],
      "properties": {
        "candidate_sha": {
          "type": "string",
          "pattern": "^[0-9a-f]{40}$"
        },
        "status": {
          "const": "verified"
        },
        "verified": {
          "const": true
        },
        "active_verified": {
          "type": "array",
          "maxItems": 0
        },
        "resolved_verified_count": {
          "const": 15
        },
        "retired_verified": {
          "type": "array",
          "maxItems": 0
        },
        "violations": {
          "type": "array",
          "maxItems": 0
        },
        "result_path": {
          "type": "string",
          "minLength": 1
        },
        "result_sha256": {
          "type": "string",
          "pattern": "^[0-9a-f]{64}$"
        }
      },
      "additionalProperties": false
    },
    "ledger": {
      "type": "object",
      "required": [
        "total",
        "active",
        "resolved",
        "fixed_in_place",
        "superseded",
        "approved",
        "unexpected"
      ],
      "properties": {
        "total": {
          "const": 15
        },
        "active": {
          "const": 0
        },
        "resolved": {
          "const": 15
        },
        "fixed_in_place": {
          "const": 14
        },
        "superseded": {
          "const": 1
        },
        "approved": {
          "const": 0
        },
        "unexpected": {
          "const": 0
        }
      },
      "additionalProperties": false
    },
    "policy_no_touch": {
      "const": true
    },
    "lifecycle_no_touch": {
      "const": true
    },
    "dogfood": {
      "type": "object",
      "required": [
        "provider_runtime_blob_sha",
        "dogfood_runtime_blob_sha",
        "runtime_mirror_equal",
        "version",
        "record_state",
        "record_operation",
        "seed_policy",
        "record_candidate_digest",
        "slot_candidate_digests",
        "candidate_digest_equal",
        "package_dogfood_parity_passed"
      ],
      "properties": {
        "provider_runtime_blob_sha": {
          "type": "string",
          "pattern": "^[0-9a-f]{40}$"
        },
        "dogfood_runtime_blob_sha": {
          "type": "string",
          "pattern": "^[0-9a-f]{40}$"
        },
        "runtime_mirror_equal": {
          "const": true
        },
        "version": {
          "const": "0.2.4"
        },
        "record_state": {
          "const": "ready"
        },
        "record_operation": {
          "type": "null"
        },
        "seed_policy": {
          "const": "preserve-only"
        },
        "record_candidate_digest": {
          "type": "string",
          "pattern": "^[0-9a-f]{64}$"
        },
        "slot_candidate_digests": {
          "type": "object",
          "required": [
            "spec-dock",
            "spec-dock-grill-with-docs"
          ],
          "properties": {
            "spec-dock": {
              "type": "string",
              "pattern": "^[0-9a-f]{64}$"
            },
            "spec-dock-grill-with-docs": {
              "type": "string",
              "pattern": "^[0-9a-f]{64}$"
            }
          },
          "additionalProperties": false
        },
        "candidate_digest_equal": {
          "const": true
        },
        "package_dogfood_parity_passed": {
          "const": true
        }
      },
      "additionalProperties": false
    },
    "reviews": {
      "type": "object",
      "required": [
        "code_review_status",
        "code_review_p0",
        "code_review_p1",
        "final_gate_status",
        "coverage_complete",
        "final_gate_p0",
        "final_gate_p1",
        "unreviewed_areas",
        "unresolved_items"
      ],
      "properties": {
        "code_review_status": {
          "enum": [
            "not-run",
            "pass"
          ]
        },
        "code_review_p0": {
          "type": "integer",
          "minimum": 0
        },
        "code_review_p1": {
          "type": "integer",
          "minimum": 0
        },
        "final_gate_status": {
          "enum": [
            "not-run",
            "pass"
          ]
        },
        "coverage_complete": {
          "type": "boolean"
        },
        "final_gate_p0": {
          "type": "integer",
          "minimum": 0
        },
        "final_gate_p1": {
          "type": "integer",
          "minimum": 0
        },
        "unreviewed_areas": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "unresolved_items": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      },
      "additionalProperties": false
    },
    "unresolved_findings": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "merge_ready": {
      "type": "boolean"
    }
  },
  "additionalProperties": false
}
```

Additional receipt invariants:

- `candidate_state=working-tree-provisional`では`implementation_sha`と`implementation_tree`をnullにできるが、`merge_ready=false`でなければならない。
- `merge_ready=true`では`candidate_state=clean-pushed-exact`、`working_tree_clean=true`、non-null exact SHA/tree、Code Review Strict pass、Final Quality Gate pass、P0/P1=0、empty unreviewed/unresolved arraysを要求する。
- Rows配列のordinal集合はexact `{1,3,4,5,6,7,8,9,10,11,12,13,14,15}`でなければならない。
- Credential-bearing logsをreceiptへ添付しない。必要なdiagnosticはsanitized summaryとhashだけを記録する。

## 15. Commit、PR、human merge boundary

- `COMMIT_PUSH_AUTHORIZED=false`なら、LunaMaxはworking-tree diff、provisional verifier result、completion receiptをCodexへ返して停止する。
- `COMMIT_PUSH_AUTHORIZED=true`なら、全GREEN後にexact 11 pathsだけをIssue branchへcommit/pushできる。
- Commit identity、Git author設定、commit messageはrepository rulesへ従う。
- Temporary logs、credential-bearing output、cache、`.workbench` raw evidenceをcommitしない。
- `PR_PREPARE_AUTHORIZED=true`なら、PR baseを`codex/epic-00384-provider-test-strategy-planning`、headをIssue branchへ固定してPRを作成または更新できる。
- LunaMaxはintegration branchへdirect pushしない。
- LunaMaxはPRをmergeしない。
- LunaMaxはrequired contexts、branch protection、Issue stateを変更しない。
- LunaMaxは#392/#395をcloseしない。
- LunaMaxは#396をstartしない。
- LunaMaxはmainへmergeしない。
- Human merge前にPR head SHAがCode Review Strict、Final Quality Gate Strict、exact clean full verifierの対象SHAと一致しなければならない。

## 16. Human merge後のsame-tip B1/B2

HumanがIssue PRをintegration branchへmergeした後、別のclean verification cloneで実行する。LunaMaxのimplementation taskには含めず、Codex/human gateへの引継ぎとして固定する。

### 16.1 Integrated tip固定

```bash
set -euo pipefail

git fetch --prune origin
git checkout --detach "origin/$INTEGRATION_BRANCH"

export POST_395_MERGE_SHA="$(git rev-parse HEAD)"
export POST_395_MERGE_TREE="$(git rev-parse 'HEAD^{tree}')"

test -z "$(git status --porcelain)"
test "$(
  git ls-remote --heads origin "refs/heads/$INTEGRATION_BRANCH" \
    | cut -f1
)" = "$POST_395_MERGE_SHA"
```

### 16.2 B1を先に検証する

```bash
env TMPDIR=/private/tmp uv run pytest -q --tb=short

env TMPDIR=/private/tmp uv run pytest \
  -q \
  --tb=short \
  tests/unit/provider_lifecycle

env TMPDIR=/private/tmp uv run pytest \
  -q \
  --tb=short \
  tests/integration/test_provider_lifecycle_dogfood.py

env TMPDIR=/private/tmp make lint

./spec-dock/scripts/spec-dock validate

env TMPDIR=/private/tmp uv run python \
  -m scripts.quality.verify_full_regression \
  --shards 4

test "$(git rev-parse HEAD)" = "$POST_395_MERGE_SHA"
test -z "$(git status --porcelain)"
```

B1 acceptance:

- Current required PR gate GREEN
- Ordinary tests GREEN
- Current full verifier GREEN
- Provider source/dogfood parity GREEN
- #392 lifecycle and protected-data invariants unchanged
- Unexpected failure 0
- Same `POST_395_MERGE_SHA`を保持

### 16.3 同じSHAでB2を検証する

```bash
python - "$POST_395_MERGE_SHA" <<'PY'
from pathlib import Path
import json
import subprocess
import sys

expected_sha = sys.argv[1]
actual_sha = subprocess.check_output(
    ["git", "rev-parse", "HEAD"],
    text=True,
).strip()
assert actual_sha == expected_sha

rows = json.loads(
    Path("full-regression-ledger.json").read_text(encoding="utf-8")
)["failure_paths"]

assert len(rows) == 15
assert sum(row["lifecycle"] == "active" for row in rows) == 0
assert sum(row["lifecycle"] == "resolved" for row in rows) == 15
assert sum(
    row.get("resolution_mode") == "fixed-in-place"
    for row in rows
) == 14
assert sum(
    row.get("resolution_mode") == "superseded"
    for row in rows
) == 1

timing = json.loads(
    Path("full-regression-timing-weights.json").read_text(encoding="utf-8")
)
assert len(timing["node_seconds"]) == 243

print("B2=15/0/15 approved=0 unexpected=0")
PY

test "$(git rev-parse HEAD)" = "$POST_395_MERGE_SHA"
```

B1とB2は同じexact full SHA/treeを証拠にする。別commit、別rerun、future SHAへ置換しない。

B1成立後に#392をcloseでき、B2成立後に#395をfinishできる。ただし、closureはhuman/Codex運用gateであり、LunaMaxは実行しない。#396はB2後にだけstartできる。

## 17. Rollback

### 17.1 Human merge前

Issue branchをabandonまたは修正する。Integration branchはP392のままである。Ledgerだけ、Productだけ、testだけをintegration branchへ部分導入しない。

### 17.2 Human merge後、#396開始前

B1またはB2が失敗した場合、#396を開始しない。Humanは次のいずれかを選ぶ。

1. Whole #395 merge revertでP392へ戻し、P392 invariantsを再検証する。
2. #395 owned boundary内のforward-fixを作り、new exact tipでB1/B2を完全に再実行する。

Human revertのcommand formは次である。

```bash
: "${ISS395_MERGE_SHA:?ISS395_MERGE_SHA must be the observed human merge commit}"
git revert -m 1 "$ISS395_MERGE_SHA"
```

LunaMaxはこのcommandを実行・pushしない。

### 17.3 #396 elaboration開始後

#396 workを停止・保存する。Humanがsuffix dispositionを決めるまで#395をrevertしない。Accepted suffixを戻す場合はreverse dependency orderで扱う。

### 17.4 禁止rollback

- Ledger-only rollback
- Product-only rollback
- Test-only rollback
- Generated mirrorだけを戻すrollback
- Automatic rollback
- Old API、old flags、old writerへのfallback
- Human判断前のforce pushまたはaccepted history rewrite

Rollback後はrepository identity、P392 SHA/tree、15/14/1 baseline、timing 243、policy continuity、lifecycle/protected-data、full verifierのP392許容集合を再検証する。

## 18. Terminal return

LunaMaxは次をCodexへ返し、次Issueへ進まない。

1. Exact `SPEC_FREEZE_SHA`
2. Working-tree provisional diff SHA-256
3. Commit/pushが許可された場合のexact `IMPLEMENTATION_SHA`とtree
4. Changed files exact set
5. Changed symbols exact set
6. 14 rowsそれぞれのRED/GREEN、accepted assertions、ledger before/after
7. Row 3 credential secrecyとpublication strictness evidence
8. Row 12 source drift guard evidence
9. Dogfood runtime mirror、record、two markers、candidate digest、package parity evidence
10. Exact full-verifier result pathとSHA-256
11. Ordinary、focused、lifecycle、platform、package、lint、validate command results
12. Timing、required-fast、policy、workflow、lifecycle、parent/#396 no-touch proof
13. Code Review StrictとFinal Quality Gate Strictの状態
14. Stop conditionまたはunresolved findingの有無
15. `merge_ready`のtrue/falseと、その根拠
16. Rollback readiness

LunaMaxは人間mergeを待つ。`owner_decisions_required=[]`を維持し、new decision、new Issue、#396 implementation、policy retirement、main mergeを開始しない。
