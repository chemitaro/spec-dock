---
種別: 設計書（Issue）
ID: "iss-00395"
タイトル: "Regression Baseline Terminalization and Product Defect Repair"
関連GitHub: ["#395"]
状態: "draft"
最終更新: "2026-09-15"
依存:
  - "requirement.md"
  - "../../artifacts/20260913t144152z-adr-issue-392-provisional-merge-and-deferred-b1.md"
  - "../../design.md"
  - "../../artifacts/active-failure-disposition-register.md"
  - "../../artifacts/provider-lifecycle-wire-contract.md"
親: ["epic-00384", "init-local-00003"]
実装開始許可: false
owner_decisions_required: []
repository_evidence:
  role: "elaboration-input-provenance"
  repository: "chemitaro/spec-dock"
  branch: "iss-00395-regression-baseline-terminalization-and-product-defect-repair"
  sha: "fe9ac410a23ca4ccce2de440ef0ddb6c76c48af9"
  tree: "4ee7cf0911ed6e4e51f8d50a09e2b34c71eae599"
p392_entry_evidence:
  sha: "921bf7512c72bfa2887673cb7ec9bc512cec6ff3"
  tree: "190bc566a18cd84813c4b7c043f8724e275cb55d"
---

# iss-00395 Regression Baseline Terminalization and Product Defect Repair — 設計

## 1. Design objective

本設計は、P392のProduct/test/ledgerを入力として、親registerの14 active rowsを原因に対応した最小差分でnormal passへ戻し、current evaluator上の15/0/15へ移す。設計上の中心は次の四点である。

1. Credential-bearing originのread-only repository identityと、書込み先としてのpublication endpoint policyを分離する。
2. Import S10のtest harnessをdescriptor-bound `copy_scaffolded_tree_at` portへ追随させ、本番のheld-descriptor writeを旧APIへ戻さない。
3. Selection-only active CLIへtest observerを合わせ、廃止済み`--force` / `--no-checkout`を復活させない。
4. 14 rowsがnormal passした後に、root ledgerだけを`resolved/fixed-in-place`へ遷移させる。Current policy machinery自体は変更しない。

## 2. Verified current architecture

### 2.1 Source identity

| Identity | Value |
|---|---|
| Repository | `chemitaro/spec-dock` |
| Issue branch | `iss-00395-regression-baseline-terminalization-and-product-defect-repair` |
| Elaboration source SHA | `fe9ac410a23ca4ccce2de440ef0ddb6c76c48af9` |
| Elaboration source tree | `4ee7cf0911ed6e4e51f8d50a09e2b34c71eae599` |
| P392 SHA | `921bf7512c72bfa2887673cb7ec9bc512cec6ff3` |
| P392 tree | `190bc566a18cd84813c4b7c043f8724e275cb55d` |

P392からelaboration sourceまでのchanged filesはEpic PlanとIssue #392 Reportだけである。従って、以下のProduct/test/policy blobsはP392と同一である。

| Path | Blob at elaboration input | Role |
|---|---|---|
| `full-regression-ledger.json` | `f181fd3098ef0cba8d0d17e47d00ea12fbbeb8b5` | 15-row transitional state |
| `full-regression-timing-weights.json` | `bdeeb6238609c38085aaed8023b78319a3dd0c6d` | 243 timing entries |
| `tests/conftest.py` | `d574c3a3e7a09c34f708c576a3b41a3b35772072` | lane/policy adapter |
| `scripts/quality/verify_full_regression.py` | `d01045add90b6e98b58fd210d2ade0d340f7b576` | current 4-shard verifier |
| `tests/cli_runtime/test_delete.py` | `3d694fdba352abea454b536b8d108e55e659aa49` | row 1 |
| `tests/cli_runtime/test_import.py` | `79c6a1eb25c928b447516213833e28e6af506a1b` | row 3 |
| `tests/cli_runtime/test_runtime_import_s10.py` | `6a68212573cdbecea8496e74fd5be8fcd67400c1` | rows 4–11 |
| `tests/cli_runtime/test_runtime_shell_s11.py` | `0960800ec3eb183fd2cabcf2a90a9fd220c0a62d` | row 12 |
| `tests/cli_runtime/test_sync.py` | `1f99b54b9edf2edde150ea64a9d3d6bdc6958397` | rows 13–14 |
| `tests/cli_runtime/test_workbench.py` | `d86c3a8dc62014c9607f9474f076300b0fe3d8c9` | row 15 |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/git_cli.py` | `b0e34dffb3650e7cb3d202e1db243e4c75fea341` | row 3 Product boundary |
| `spec-dock/scripts/spec_dock_runtime/infra/git_cli.py` | `b0e34dffb3650e7cb3d202e1db243e4c75fea341` | checked-in dogfood mirror |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/commands/new.py` | `c967fcd279d628bf3c98b1795ebd090eda5fb959` | row 12 thin shell |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/contracts.py` | `bc64a84f15b1176cb077c320c5fd5e7cb924589d` | row 12 application contract |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/domain/artifacts.py` | `9f62ddf799f22910efeda5eebb4ba41e775241ac` | artifact catalogue authority |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/ports.py` | `129380b6a0b24e111650b264afe78596a26c8a8a` | current ports |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/application/create_node.py` | `ef8900a71f10df4559f2290c730f032b6d306d73` | descriptor-bound write caller |
| `src/spec_dock/assets/spec_dock/scripts/spec_dock_runtime/infra/template_scaffolder.py` | `86489fdf323d0e70e52bec9d049bbd9b086c76b3` | descriptor-bound adapter |
| `.github/workflows/provider-ci.yml` | `db1adceda41e7927a9dd7e5f7934d3f88152bf06` | current PR gates |
| `.github/workflows/provider-full-regression.yml` | `259c7988f3cf13ed4484be60bc200e01680b95f2` | current main/manual full gate |

Blob identityは実装開始時のdrift detectionに使う。仕様pack自身のcommitで変わるR/D/P/Artifactsをこの表のProduct/test driftと混同しない。

### 2.2 Current full-verifier semantics

`tests/conftest.py`はpytest collection/reportを`CandidateObservation`へ変換する。`scripts/quality/verify_full_regression.py`は全full-regression nodeをcollectし、timing weightで4 shardへ分割し、全nodeのcollection/execution coverageを確認して`evaluate_baseline`へ渡す。

`scripts/quality/full_regression_baseline.py::evaluate_baseline`は次を要求する。

- `active`: historical nodeがexactly once collect/executeされ、normal failureかつsignature一致
- `resolved/fixed-in-place`: historical nodeがexactly once collect/executeされ、normal pass
- `resolved/superseded`: successorがexactly once collect/executeされ、normal pass
- baseline外のfailure/error: unexpected violation

このため、Product/test修復後にledgerをactiveのまま残すと、正常化したnodeは`coverage_mismatch`になる。逆に、修復前にledgerをresolvedへ変えると`unexpected_failure`になる。設計上の安全な順序は、focused shardで14 normal passを先に証明し、その後にledgerを一括遷移し、current full verifierを実行する順で固定する。

## 3. Component and responsibility inventory

### 3.1 Product row 3: repository identity boundary

| Layer | Path | Existing symbol | Responsibility |
|---|---|---|---|
| Command | `commands/import_cmd.py` | `_run_import_initiative`、`_run_import_epic`、`_run_import_issue` | CLI argsを`ImportNodeRequest`へ写す。変更しない。 |
| Application | `application/import_node.py` | `import_node_core`、`_validate_url_repo_identity`、`_require_numeric_import_repo_scope` | Target URLとcurrent repo slugのsame-repo policy、GitHub read、create plan。変更しない。 |
| Application | `application/repo_context.py` | `require_current_repo_slug`、`resolve_current_repo_slug` | `GitGateway.origin_github_repo_slug`の結果をnormalizeする。signatureを変更しない。 |
| Port | `application/ports.py` | `GitGateway.origin_github_repo_slug` | Read-only repository identity contract。signatureを変更しない。 |
| Adapter binding | `cli/bootstrap.py` | `_GitGateway.origin_github_repo_slug` | Infra functionへ委譲する。変更しない。 |
| Infra | `infra/git_cli.py` | `_remote_get_url`、`_parse_github_repo_slug`、`_remote_has_userinfo`、`_redact_remote_url`、`origin_github_repo_slug`、`origin_github_publication_endpoint` | Read-only identityとpublication endpoint policyのfirst incorrect layer。本IssueのProduct edit対象。 |
| Generated mirror | `spec-dock/scripts/spec_dock_runtime/infra/git_cli.py` | 同じsymbols | Provider sourceからSpecDock updateで投影。直接編集しない。 |

### 3.2 Test rows 4–11: scaffolder observer seam

| Layer | Path | Existing symbol | Responsibility |
|---|---|---|---|
| Port | `application/ports.py` | `TemplateScaffolder.copy_scaffolded_tree_at` | `src_dir`、logical `dest_dir`、held `dest_dir_fd`、replacementsを受けるcurrent port。 |
| Application | `application/create_node.py` | `execute_create_plan` | Temporary payload directory FDを保持し、`copy_scaffolded_tree_at`、`write_meta_at`、no-replace publicationを実行する。 |
| Infra | `infra/template_scaffolder.py` | `copy_scaffolded_tree_at` | Descriptor-relative collision check、directory creation、binary/text copy、replacement、mode/shebang preservation。 |
| Test | `tests/cli_runtime/test_runtime_import_s10.py` | `_StubTemplateScaffolder` | Current portを欠いている唯一のfirst incorrect layer。current adapterへ委譲するmethodを追加する。 |

### 3.3 Test rows 1、13、14、15: active observer seam

`commands/active.py::_add_active_set_arguments`が許容するのは、positional `target`、`--id`、`--github-issue`だけである。`ActiveSetArgs`は`target_ref`と`target_display`だけを持ち、`_run_active_set`は`SetActiveRequest`を呼ぶ。従って、testからretired active flagsを除去するだけで、Product command surfaceは変更しない。

### 3.4 Product row 12: thin-shell boundary

Current sourceは既に次の依存方向である。

```text
commands/new.py
  -> application/contracts.py::CURRENT_CREATABLE_ARTIFACT_TYPES
     -> domain/artifacts.py::CURRENT_CREATABLE_ARTIFACT_TYPES
```

`commands/new.py`は`domain.artifacts`を直接importしていない。`tests/cli_runtime/test_runtime_shell_s11.py::TestRuntimeShellS11::test_final_api_call_site_and_structural_regression`はcommands layerから`domain`、`infra`、`app`への直接importを禁止し、applicationからinfra concreteへの依存とinfraからshellへの依存も禁止する。P392でrow 12が`coverage_mismatch`なのは、Product/testがnormal passしているのにledgerがactiveだからである。

Current three blobsが§2.1と一致する場合、row 12のproduction editは0とする。BlobまたはASTが一致しなければ、現行仕様入力のdriftとして停止する。Catalogueをcommandsへ複製したり、新しいwrapper typeを発明したりしない。

## 4. Runtime flow design

### 4.1 Current failing read-only import flow

```text
CLI import issue URL
  -> commands/import_cmd.py::_run_import_issue
  -> application/import_node.py::import_node_core
  -> application/repo_context.py::resolve_current_repo_slug
  -> GitGateway.origin_github_repo_slug
  -> cli/bootstrap.py::_GitGateway.origin_github_repo_slug
  -> infra/git_cli.py::origin_github_repo_slug
  -> origin_github_publication_endpoint
  -> _parse_github_repo_slug(fetch URL)
  -> _remote_has_userinfo == true
  -> slug resolution failure
```

Read-only identity lookupがpublication policyを経由するため、`https://token@github.com/example/repo.git`をsame repositoryとして認識できない。

### 4.2 Target read-only identity flow

```text
application read-only identity request
  -> origin_github_repo_slug(repo_root)
  -> _remote_get_url(repo_root, push=False)
  -> _parse_github_repo_slug(fetch_url)
  -> normalized owner/repo only
  -> application same-repo comparison
```

`_parse_github_repo_slug`はURL自体を返さず、lowercase owner/repoだけを返す。HTTPS userinfoが存在してもregexでhost/pathを解析できる場合はidentityを返す。Malformed URL、non-GitHub remote、empty owner/repoは`None`とする。Applicationは既存の`require_current_repo_slug` contractによりunknown identityをfail-closedで扱う。

### 4.3 Target publication flow

```text
publication request
  -> origin_github_publication_endpoint(repo_root)
  -> fetch_url = _remote_get_url(push=False)
  -> push_url  = _remote_get_url(push=True)
  -> _remote_has_userinfo(fetch_url or push_url)
       true  -> reject with redacted diagnostic
  -> _parse_github_repo_slug(fetch_url)
  -> _parse_github_repo_slug(push_url)
  -> both GitHub and exact slug equality
  -> return (slug, push_url)
```

Publicationはcredential-bearing fetch/push URLを引き続き拒否する。`_redact_remote_url`はuserinfoを含む値を`<credential-bearing remote>`へ置換する。Fetch/push mismatchはslugだけを表示し、secretを表示しない。

### 4.4 Exact existing-symbol edits

`infra/git_cli.py`以外のProduct pathを変更せず、existing symbolsを次のように分担する。

1. `_parse_github_repo_slug`: `_remote_has_userinfo`によるpolicy rejectionを削除し、GitHub repository identity parserに限定する。
2. `origin_github_repo_slug`: `origin_github_publication_endpoint`を呼ばず、fetch URLを直接取得して`_parse_github_repo_slug`へ渡す。
3. `origin_github_publication_endpoint`: `_parse_github_repo_slug`を呼ぶ前にfetch/push双方のuserinfoを明示的に拒否する。既存redaction、GitHub validation、fetch/push equalityを維持する。
4. `_remote_get_url`、`_remote_has_userinfo`、`_redact_remote_url`のsignatureと既存error classificationを維持する。

新しいpublic function、port、request/result type、CLI flagは追加しない。

## 5. Test harness seam design

### 5.1 Descriptor-bound test double

`_StubTemplateScaffolder`へ次のexisting port methodと同じsignatureを追加する。

```python
def copy_scaffolded_tree_at(
    self,
    src_dir: Path,
    dest_dir: Path,
    dest_dir_fd: int,
    replacements: dict[str, str],
) -> list[Path]:
```

Methodは`self.events`へ`copy_scaffolded_tree_at`を一度記録し、`spec_dock_runtime.infra.template_scaffolder.copy_scaffolded_tree_at`へ同じ引数を委譲する。これによりtest独自のpathname writerを増やさず、production adapterと同じdescriptor-relative behaviorを使う。Existing `copy_scaffolded_tree`は他のtest compatibilityのため削除しないが、`execute_create_plan`を旧methodへ戻さない。

### 5.2 Rows 4–11のprotected assertions

| Row | Protected observation |
|---:|---|
| 4 | fallback parent ID、GitHub read repo slug、`load_active_manifest_no_migrate`のみ |
| 5 | issue active chain、precheckとlock-sideの2 manifest reads、sync result |
| 6 | lock前後でparentを2回解決、second parent path、GitHub read |
| 7 | numeric targetにcurrent repo slug、stored owner/name |
| 8 | explicit same-repo target slug、foreign rejection不変 |
| 9 | generated index/tree/PUML/deps/dashboard pathとimported node projection |
| 10 | post-sync failureのstatus/reason、committed `.meta.json`保持 |
| 11 | `execute_create_plan` exactly once、rules symlink、no second writer、no retired output |

### 5.3 Selection-only observer edits

| Row | Existing invocation | Target invocation | Additional ordering |
|---:|---|---|---|
| 1 | `active set --id iss-00058 --force` | `active set --id iss-00058` | Existing return-code assertionを保持。 |
| 13 | `active set iss-00003 --force` | `active set iss-00003` | Capture resultへ変更する必要はないが、helperはnonzeroをfailさせる。Existing generated-state assertionsを保持。 |
| 14 | `active set 305 --force --no-checkout` | `active set 305` | Existing `p_active.returncode == 0`を保持。 |
| 15 | `active set --id scope_id --force` | `active set --id scope_id` | `active.json` readより先に`active_result.returncode == 0`をassertする。 |

### 5.4 Row 3 test strengthening

Existing row 3 nodeをrenameせず、credential-bearing originでimport successを確認した後に次を追加する。

- `combined = p.stdout + p.stderr`
- `"token" not in combined`
- `"https://token@github.com/example/repo.git" not in combined`
- success textは従来どおり`stdout`に存在

同node内でbehaviorを強化し、新しいbaseline rowを増やさない。Publication policyはProduct code reviewとfocused diagnosticで、userinfo fetch/push rejection、fetch/push mismatch rejection、redacted errorを確認する。

## 6. Ledger state design

### 6.1 Transition unit

Ledger変更は14 rows一括である。Row単位の中間commitをmerge-readyにしない。

Before:

```json
{"lifecycle":"active"}
```

After for rows 1 and 3–15:

```json
{"lifecycle":"resolved","resolution_mode":"fixed-in-place"}
```

同じrowに`successor_nodeid`を追加しない。Historical `current_status: failed`、`fixed_point_status: failed`、`disposition: approved-no-op`、signaturesは観測履歴として保持する。Active approvalはlifecycleから導出されるため、resolved化後のapproved failureは0である。

### 6.2 Row 2

Row 2は次を変更しない。

```json
{
  "lifecycle": "resolved",
  "resolution_mode": "superseded",
  "successor_nodeid": "tests/cli_runtime/test_distribution_cutover.py::test_s40b_retained_skill_identity_matches_current_provider_and_dogfood"
}
```

### 6.3 Historical top-level metadata

`fixed_point_verification`、`current_head_verification`、`subset_comparison`、`conclusion`、old head SHA、27-countはhistorical non-authorityである。本Issueでは書換えない。Current countは`failure_paths`のlengthとlifecycleからだけ導出する。

### 6.4 Evaluator result after transition

Current full verifierは次を返さなければならない。

- process exit 0
- top-level `status="verified"`
- `candidate_sha` equals actual clean implementation SHA
- `evaluation.verified=true`
- `evaluation.active_verified=[]`
- `evaluation.resolved_verified` contains 15 historical rows, including row 2 represented by its successor
- `evaluation.violations=[]`
- collection/execution coverage exact、duplicate 0

## 7. Dogfood and packaging design

`infra/git_cli.py`はshipped runtimeなのでcandidate-changing Product editである。Provider sourceを先に変更し、focused tests、lint、ordinary laneをGREENにした後、current lifecycle commandでchecked-in dogfoodへcomplete projectionする。

```text
provider source edit
  -> source-focused GREEN
  -> package/dogfood candidate proof
  -> spec-dock update . --json
  -> generated mirror byte equality
  -> package/dogfood parity rerun
```

`spec-dock/scripts/spec_dock_runtime/infra/git_cli.py`、`spec-dock/spec-dock.version`、`.agents/skills/spec-dock/.spec-dock-provider-slot.json`、`.agents/skills/spec-dock-grill-with-docs/.spec-dock-provider-slot.json`を直接編集しない。Current lifecycle updateは、runtime mirror bytesの変更に伴ってaggregate candidate digestを更新するため、terminal recordと二slot markerの`candidate_digest`変更を同じprojectionの必須出力とする。Recordはversion `0.2.4`、state `ready`、operation `null`、`seed_policy=preserve-only`、二slot名を保持し、二markerはversion `0.2.4`とexact slot名を保持し、三者のdigestが一致しなければ停止する。Two skillの`SKILL.md` bytes、他のprovider roots、bootstrap、Wire、consumer dataにdiffがあればstopする。

## 8. Compatibility and dependency direction

- CLI args、exit code、JSON/text formatを変更しない。
- `GitGateway.origin_github_repo_slug` signatureを変更しない。
- Import node ID、repo linkage、parent resolution、lock/revalidationを変更しない。
- `TemplateScaffolder.copy_scaffolded_tree_at` signatureとproduction callerを変更しない。
- `CURRENT_CREATABLE_ARTIFACT_TYPES`のsingle authorityを維持する。
- Current test lane、timing、sharder、policy hook、workflowsを維持する。
- #392 lifecycle outputをread-onlyでconsumeし、#396 toolingをimportしない。

Dependency directionは次で固定する。

```text
commands -> application contracts/use cases -> ports/domain
infra adapters -> application contracts/ports
Issue #395 tests -> public/runtime behavior or current ports
Issue #395 ledger -> current evaluator
Issue #396 -> accepted clean #395 output
```

## 9. Error, stop and recovery design

| Failure | Required behavior |
|---|---|
| Credential-bearing read-only origin cannot resolve | Row 3 remains RED。Publication policyを緩和して通さない。 |
| Publication accepts userinfo or leaks secret | Blocking。Product editを戻し、redaction/strict checkを修正する。 |
| Fetch/push publication mismatch accepted | Blocking。Existing equality policyを回復する。 |
| S10 double still lacks current port or writes by pathname | Blocking。Production APIを戻さずtest seamを修正する。 |
| Observer needs retired active flags | Blocking。Product flagを復活させない。 |
| Row 12 structure differs from verified blob | Drift stop。推測修正せずexact AST/import diffを返す。 |
| One repaired row fails after ledger transition | Full verifier fails closed。Ledgerだけを戻すのでなく、unmerged candidate全体を修正する。 |
| Unexpected failure outside 14 rows | Blocking。New approved rowを追加しない。 |
| Dogfood/lifecycle/protected data drift | Blocking。Generated projectionをdiscardし、provider sourceとlifecycle ownerへ戻る。 |
| B1/B2 fails after human merge | #396を停止。Humanがwhole #395 merge revertまたはowned forward-fixを選ぶ。 |

Unmerged changesのrollbackはIssue branch上でcandidate全体を戻す。Integrated rollbackはwhole mergeでP392へ戻す。Partial ledger-only、test-only、Product-only rollbackは禁止する。

## 10. Observation and evidence model

### 10.1 Per-row evidence

各rowに次を記録する。

- `row_ordinal`
- `nodeid`
- `historical_signature_sha256`
- `repair_surface`
- `entry_outcome`
- `entry_violation_code`
- `changed_paths`
- `changed_symbols`
- `red_command`
- `red_reason`
- `green_command`
- `green_outcome`
- `protected_assertions`
- `ledger_lifecycle_before`
- `ledger_lifecycle_after`

### 10.2 Candidate evidence

- repository、branch、base P392 SHA/tree、spec freeze SHA/tree、implementation SHA/tree
- precommit working-tree diff SHA-256と、そのverifier `candidate_sha`がspec freeze HEADであることを示すprovisional label
- final implementation commit後のlocal/upstream/remote equality、clean status
- exact implementation SHAへ束縛したfull-verifier rerun
- changed-file inventory
- source/dogfood runtime blob equalityと、ready record／二slot markerのcandidate digest equality
- ordinary/focused/full verifier/lint/validate results
- baseline counts、timing count、required-fast IDs
- current workflow blobs/no-touch diff
- lifecycle/protected-data parity
- Code Review Strict receipt
- Final Quality Gate Strict v2 Pro receipt
- human merge SHA/tree
- same-tip B1 then B2 receipts
- rollback command/authority state

Evidenceにremote credential、token、absolute private workspace contentを含めない。

## 11. Requirement-to-design traceability

| Requirement | Design section |
|---|---|
| I395-RQ-001 | §2、§10 |
| I395-RQ-002 | §3–§6 |
| I395-RQ-003 | §3.1、§4 |
| I395-RQ-004 | §3.2、§5.1–5.2 |
| I395-RQ-005 | §3.3、§5.3 |
| I395-RQ-006 | §3.4 |
| I395-RQ-007 | §6 |
| I395-RQ-008 | §5、§6、§8 |
| I395-RQ-009 | §2.2、§6.4、§8 |
| I395-RQ-010 | §7 |
| I395-RQ-011 | §10 |
| I395-RQ-012 | §10.2 |
| I395-RQ-013 | §2、§10 |
| I395-RQ-014 | §10 |
| I395-RQ-015 | §9 |
| I395-RQ-016 | §9 |

## 12. Decision state

`owner_decisions_required=[]`である。Current verified paths/symbolsでimplementation-readyな修復が可能であり、新しいProduct、policy、security、lifecycle判断を追加しない。独立spec reviewと実装dispatch前は`実装開始許可: false`である。
