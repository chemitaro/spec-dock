# Issue #396 承認済み仕様パック

## 承認状態と実装ゲート（2026-09-18）

- Requirement / Design / Plan: #395 corrected merge統合後の仕様candidateを更新中。直近candidate `f4efb5dc8fd62bb36f3a5b11ad26dd8a12275184`のStrict reviewは`fail`（P1=2、P2=3、P3=1）。現在はP1のrole graph/evidence不整合を上位契約に沿って修正し、同じreview objectiveの再レビューを準備している。
- 過去の同一Red session `iss396-spec-review-red` reviewはSHA `0c7cdd484c82142333f035df9488cf60586c2aea` / tree `4ba6fc830e7d2d5d9767ba36c00459371e360aa2`で`review_status=pass`、P0=0、P1=0、findings=0。これは履歴であり、新freezeのpassではない。
- #395 correction PR #403は2026-09-18に人間がEpic integration branchへmerge。corrected merge SHA `3c69af78843b04a13bde2f93eb3b1eb4081cdb33` / tree `38e2f9a50f7cae14ef24fa1187a559c592729e3b`。
- 同一tipでfresh B1/B2は実行され、parent ownerが受入済み。B1: pytest 1,368 passed / 848 skipped、lint (Ruff check/format, mypy 196 files) pass、SpecDock validate nodes=236、provider parity 524 passed。B2 attempt 1はdefault-tempで`unsafe-repository-binding`失敗し、証拠を保持。private TMPDIRを設定したattempt 2は2,216 collected、2,191 passed、25 skipped、resolved=15、violations=0でpassし、親owner受入済み。
- #396 branchへのrealignment mergeはSHA `a7f66ca5f8ca2e0571505ac8bf2466144186f769` / tree `38e2f9a50f7cae14ef24fa1187a559c592729e3b`。pre-realignment commit `59da598a6352c447711399d3a1adab871e6b4a8a` / tree `dfcc40204df51930d446aa65d343a5549857e381`とはtreeが異なる。PR #403由来の7 path（provider-slot metadata 2件、#395 plan、runtime provider sourceとdogfood mirror、`spec-dock.version`、`tests/cli_runtime/test_new.py`）を取り込んだ。Issue #396のP02/I0–I22 Product実装は未開始。
- 別途報告された#395症状とA395-SEC-001の同一性は推定しない。Issue #395はOPENのまま。
- Product実装許可: **false / 保留**。ユーザーの明示dispatchは受領済み。新しいspec freezeに対するStrict pass、Issue projection readback、final exact identity/no concurrent writerを確認するまではProduct変更を開始しない。

このREADMEはcurrent admission状況を記録します。`authoring-gate-status-v1.json`はcandidate組み立て時点のsnapshotとして保存し、現在のgate statusへ読み替えません。Issue body projection、#395 correction、B1/B2 acceptanceは別々の証跡で確認します。このarchiveはlive status boardではありません。
本archiveはIssue #396のcanonical Requirement / Design / Plan、GPT-5.6 Luna Max handoff、closed schema、machine-readable implementation contracts、historical evidence、human guideをrepository-relative hierarchyで格納した**承認済み仕様パック**です。展開した各pathを同じrepository pathへ適用できます。

このREADMEは上記の承認状態を反映します。`authoring-gate-status-v1.json`はcandidate組み立て時点のsnapshotとして保存し、現在のgate statusへ読み替えません。Issue body projection、#395 correction、B1/B2 acceptanceはそれぞれ別の証跡で確認します。このarchive自体はlive status boardではありません。

次の状態は明確に分離されています。

- Blue Strict authoring input: `chemitaro/spec-dock` / `iss-00396-build-once-provider-gate-and-regression-policy-cutover` / `4d68bce3f3ee977548a3c467476da39c15f43594` / tree `80ade10f57cd5f4140daa03ca8a40b844f1fcc53`。
- #395 original human merge readback: PR #401、SHA `fd5df1d64b5d7ebf7bd4b41bb35fd8760d17e65d`、tree `37eabc1aa250838dcd9f61d627309b0ff27e0db7`。Owner correction reports the implementation incorrect; this identity is historical only.
- #395 defect disposition: specific defect and corrective outcome are not independently verified; the #395 owner must correct and accept it under Issue #395.
- Formal Issue start / active branch: 保持。巻き戻しや再startを行いません。
- B1: **not performed / not accepted**。
- B2: **not performed / not accepted**。
- Historical: pre-remediation review (`d9a775e0fd11735eb3ba7b89149c5f8b5b1aa2aa`) was `fail`, P0=0, P1=4, P2=3, P3=0。最終の実質仕様はREADME冒頭のexact SHA/treeでreview pass済みであり、今回のstatus-only承認revisionはユーザー指示により再reviewしていません。
- 修正は既存のgate/command/schemaを具体化する範囲です。Product component、state machine、ownership node、checkpoint、parent policyは追加しません。
- 2026-09-18のStrict review（修正前SHA `cc8b6800b1439a81cd8513977f48e5221ac21965`）はP1=2、P2=3でした。分析では、1件は引用箇所の誤認を含むrebuttal（Design §8.7はTruthful stopであり、write scopeはPlan §3とHandoff §6が既に定義）、もう1件は有効な矛盾（full manifestを読むfocused pytest command）と判定しました。このrevisionは既存のwrite boundaryをHandoff §3で明記し、full qualificationとfocused checkpoint検証を区別して、P07/P08/P10のfocused commandをmanifest内の完全なnode IDに限定します。
- 上記のP1修正はschema、component、state、ownership assignment、checkpoint、delta、Epic policyを追加しない範囲で行いました。過去reviewのP2/P3は履歴としてrecord-onlyであり、現在のfinal review findingsへ混ぜません。
- Issue projection update/readback: 旧review revisionのreadbackはあります。Approved状態とこのrevisionを示すGitHub bodyの更新・readbackは未完了です。
- 最新f4efb5d Strict reviewはP1-001で`candidate-resolve`を要求・設計・schema間で一貫して表現していない点を指摘しました。上位Epicはcandidateを一度だけmaterializeし、後続attemptが同じstored bytesを利用することを定め、Issue Planは`resolve-candidate` CLIを既に指定しています。この既存契約に従い、candidate resolveをnon-build stage resultとして分離し、4つの`RoleResultV1`とterminal `AttemptResultV1`へ接続します。
- 最新f4efb5d reviewのP1-002はdispatch stateと古いGitHub body projectionの不一致を指摘しました。現在のtask requestは明示dispatchとして受領済みで、Plan A4にも記録済みです。Strict pass後にGitHub Issue #396 bodyを現在の正本へ更新・readbackし、他のgate確認と分離します。
- Issue projection update/readback: 新freeze review pass後の更新・readbackが未完了です。
- Explicit implementation dispatch: 現在のtask requestから受領済み。記録は`luna-max-implement/.../evidence/strict-analysis/explicit-implementation-dispatch.md`。
- Product / tests / workflow / policy / GitHub settings / merge: 未変更。
- Product implementation authorization: `false`。
- B3: `not-started`。

従来のB1/B2 receiptとraw JSONはbytesを変更せず歴史的主張として保存します。Current acceptanceには使用しません。#395 ownerがreported defectを修正・受入し、そのcorrected merge SHA/treeをGitHub readbackするまではexecution targetは未確定です。以降は`artifacts/b1-b2-admission-status-v2.json`と`artifacts/b1-b2-verification-contract-v1.json`に従ってcorrected tipでB1、続けてsame-tip B2をfresh実行・受入します。未解決・failure・identity不足の場合は#395/parent ownerへ戻してIssue #396実装を停止します。

## Authority

- Epic Requirementの`E384-QUAL-001`だけがqualificationのvalue、population、window、aggregation、platform scope、rejection、forbidden escapeのauthorityです。
- Issue #396はimplementation、measurement、evidenceのsole writerです。Issue側schemaやgenerated projectionは第二のpolicy authorityではありません。
- Issue #392 lifecycle/wire、Issue #395の既存コード・文書・証跡、15-row records、retained install-root workflowはread-onlyです。Issue #395 implementationはowner-reported incorrectであり、B1/B2受入には#395 ownerの修正・受入とfresh evidenceが必要です。
- Humanだけがrequired-context/ruleset/merge settingsを書き、PRをmerge/revertします。
- Parent Epic R/D/P、Issue #395 docs、Initiative priorityは本packで変更していません。

## Earlier P1 remediation (historical)

以下の`p1-remediation-closure-v1.json`は以前のreview batchに対する履歴です。直近d9 candidateのP1=4件のclosure証拠としては扱いません。

1. One-time materializationをattempt/role graphから分離し、complete candidate/environment後だけcampaignをfreezeします。同じSHA/treeのproducer failureはpoisonし、rebuildを拒否します。
2. `PreflightEvidenceIndexV1`と`CandidateEvidenceIndexV1`を分離し、wireには`evidence_root_id`、logical POSIX path、actual byte size/hashだけを保存します。
3. Immutable 2,214-node baselineにexact 43 add + 1 move + 69 deleteを適用し、checkpoint manifestを決定的に導出します。`collection_sha256`はDesign §7.1のnormalized node-ID encodingを使い、P03はbaseline digest、P15はfinal projectionと一致します。Finalは2,188 assignmentsです。
4. `pytest_plugin.py`を移行前後の恒久filter ownerとし、root `tests/conftest.py`はtemporary seamに限定します。
5. Fault denominatorは20 categories / exact 45 entries、finite violation inventoryは68 codesです。Input/result schema familyを実装前に閉じます。
6. `StopReturnV1`はpre/post mutation、scope impact、owner/action、changed/external surface、rollback/recoveryを表し、`automatic_rollback_performed=false`を維持します。

詳細なP1対応表は`artifacts/p1-remediation-closure-v1.json`、P2の非blocking記録は`artifacts/strict-review-p2-record-v1.json`を参照してください。

## Pack layout

- `requirement.md` / `design.md` / `plan.md`: Issue childへ直接適用するcanonical replacement。
- `artifacts/20260917t124918z--luna-max-implementation-handoff.md`: admission gate通過後のexecution contract。現在は`implementation_allowed: false`。
- `artifacts/provider-gate-contracts-v1.schema.json`: Draft 2020-12 closed schema family。
- `artifacts/role-ownership-v1.json`: 2,214-node immutable baseline。bytesを変更していません。
- `artifacts/role-ownership-delta-v1.json`: exact 43 add + 1 move + 69 delete。
- `artifacts/role-ownership-checkpoints-v1.json`: checkpointごとのfull resolved assignment。
- `artifacts/role-ownership-resolved-final-v1.json`: final 2,188 assignments。
- `artifacts/seeded-fault-catalogue-v1.json`: exact 45-entry catalogue。
- `artifacts/closed-violation-codes-v1.json`: finite 68-code inventory。
- `artifacts/old-policy-retirement-v1.json`: consumer-zero scanner/deletion/retained workflow contract。
- `artifacts/b1-b2-*.json`: corrected predecessor admission stateとfresh verification contract。
- `artifacts/issue-396-implementation-readiness.html`: ZIP内human guide。ZIP外のHTMLとbyte-identicalです。
- Parent contractsとhistorical evidence: preserved byte-for-byte。

## Manifest contract

`payload-manifest-v1.json`は自己自身と`manifest.sha256`を除く33 payloadを分類します。

| Classification | Count | Meaning |
|---|---:|---|
| `modified` | 7 | 既存pack payloadを完成版へ置換 |
| `new` | 11 | 新しいIssue-local machine-readable contract |
| `preserved` | 15 | Parent authority、immutable baseline、historical evidenceをbyte-preserve |

`manifest.sha256`はREADME、`payload-manifest-v1.json`を含むarchive内の全file（manifest自身を除く）をpath順でhashします。

以下はrepository rootから実行します。

```bash
ISSUE_DIR="spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00396-build-once-provider-gate-and-regression-policy-cutover"
PACK="$ISSUE_DIR/artifacts/issue-396-specification-pack.zip"
UNPACKED_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/iss396-pack.XXXXXXXX")"
python -m zipfile -t "$PACK"
python -m zipfile -e "$PACK" "$UNPACKED_ROOT"
python - "$UNPACKED_ROOT" <<'PY'
import hashlib
import sys
from pathlib import Path

root = Path(sys.argv[1])
for line in (root / "manifest.sha256").read_text(encoding="ascii").splitlines():
    expected, relative = line.split("  ", 1)
    actual = hashlib.sha256((root / relative).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit(f"hash mismatch: {relative}")
print("PASS manifest.sha256")
PY
cmp "$ISSUE_DIR/artifacts/issue-396-implementation-readiness.html" \
  "$UNPACKED_ROOT/$ISSUE_DIR/artifacts/issue-396-implementation-readiness.html"
```

## Remaining stop conditions

Product implementation開始には、次が順にすべて成立する必要があります。

1. 本仕様candidateをcleanなIssue branchへcommit/pushし、exact SHA/treeを固定。
2. Same Red session `iss396-spec-review-red`で`review_status=pass`、P0=0、P1=0。P2/P3はreview contractに従う。
3. Pass後にGitHub Issue #396 canonical projectionを更新し、readback。
4. #395 ownerがreported implementation defectを修正・受入。
5. Corrected #395 merge SHA/treeをGitHub readbackし、B1/B2 execution targetとして固定。
6. Corrected exact SHA/treeでfresh B1、その同一SHA/treeでfresh B2をaccepted。
7. Corrected #395 merge SHAがIssue #396の`SPEC_FREEZE_SHA`のancestorであることを確認。falseならowner-authorized branch dispositionへ戻し、realignment後にsource-bound artifact、ZIP、same-Red review、Issue projection readbackをやり直す。
8. Current specification freezeがclean・exactで、concurrent writerがない。
9. 受領済みdispatchのtask identityを記録と照合し、他の全gate完了後に実装着手可否を判定。
