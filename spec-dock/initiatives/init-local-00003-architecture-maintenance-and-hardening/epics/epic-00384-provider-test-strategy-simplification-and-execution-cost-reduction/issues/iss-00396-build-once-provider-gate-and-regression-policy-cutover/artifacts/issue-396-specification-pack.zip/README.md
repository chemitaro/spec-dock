# Issue #396 完成版仕様パック

## このcandidateの読み方

本archiveはIssue #396のcanonical Requirement / Design / Plan、GPT-5.6 Luna Max handoff、closed schema、machine-readable implementation contracts、historical evidence、human guideをrepository-relative hierarchyで格納した**authoring candidate**です。展開した各pathを同じrepository pathへ適用できます。

このREADMEと`authoring-gate-status-v1.json`はcandidate組み立て時点のsnapshotです。後続のStrict review、GitHub Issue projection readback、B1/B2 acceptanceはexact SHAへ結び付けた別証跡で確認します。このarchive自体は後続の実行結果を含むlive status boardではありません。

次の状態は明確に分離されています。

- Blue Strict authoring input: `chemitaro/spec-dock` / `iss-00396-build-once-provider-gate-and-regression-policy-cutover` / `4d68bce3f3ee977548a3c467476da39c15f43594` / tree `80ade10f57cd5f4140daa03ca8a40b844f1fcc53`。
- #395 original human merge readback: PR #401、SHA `fd5df1d64b5d7ebf7bd4b41bb35fd8760d17e65d`、tree `37eabc1aa250838dcd9f61d627309b0ff27e0db7`。Owner correction reports the implementation incorrect; this identity is historical only.
- #395 defect disposition: specific defect and corrective outcome are not independently verified; the #395 owner must correct and accept it under Issue #395.
- Formal Issue start / active branch: 保持。巻き戻しや再startを行いません。
- B1: **not performed / not accepted**。
- B2: **not performed / not accepted**。
- 直近pre-remediation same-Red review (`d9a775e0fd11735eb3ba7b89149c5f8b5b1aa2aa`): `fail`, P0=0, P1=4, P2=3, P3=0。
- 本pack revisionはその4件を、branch ancestry gate、B1 parity実行条件、既存nodeに限定したP04/P05/P11コマンド、closed admission/review fieldsで修正します。現在revisionの判定は同じRed sessionから得るexact-SHA-bound receiptで確認してください。
- 修正は既存のgate/command/schemaを具体化する範囲です。Product component、state machine、ownership node、checkpoint、parent policyは追加しません。
- 直近reviewのP2=3とP3はreview contractに従いrecord-onlyです。修正、task化、合否条件化していません。
- Issue projection update/readback: Strict pass後の独立gateです。完了は別途GitHub readbackで確認してください。
- Explicit implementation dispatch: 未受領。
- Product / tests / workflow / policy / GitHub settings / merge: 未変更。
- Product implementation authorization: `false`。
- B3: `not-started`。

従来のB1/B2 receiptとraw JSONはbytesを変更せず歴史的主張として保存します。Current acceptanceには使用しません。#395 ownerがreported defectを修正・受入し、そのcorrected merge SHA/treeをGitHub readbackするまではexecution targetは未確定です。以降は`artifacts/b1-b2-admission-status-v2.json`と`artifacts/b1-b2-verification-contract-v1.json`に従ってcorrected tipでB1、続けてsame-tip B2をfresh実行・受入します。未解決・failure・identity不足の場合は#395/parent ownerへ戻してIssue #396実装を停止します。

## Authority

- Epic Requirementの`E384-QUAL-001`だけがqualificationのvalue、population、window、aggregation、platform scope、rejection、forbidden escapeのauthorityです。
- Issue #396はimplementation、measurement、evidenceのsole writerです。Issue側schemaやgenerated projectionは第二のpolicy authorityではありません。
- Issue #392 lifecycle/wire、Issue #395の既存コード・文書・証跡、15-row records、retained install-root workflowはread-onlyです。Issue #395 implementationはowner-reported incorrectであり、B1/B2受入には#395 ownerの修正・受入とfresh evidenceが必要です。
- Humanだけがrequired-context/ruleset/merge settingsを書き、PRをmerge/revertします。
- Parent Epic R/D/P、Issue #395 docs、Initiative priorityは本packで変更していません。

## Earlier P1 remediation (historical)

以下の`p1-remediation-closure-v1.json`は以前のreview batchに対する履歴です。直近d9 candidateのP1=4件のclosure証拠としては扱いません。

1. One-time materializationをattempt/role graphから分離し、complete candidate/environment後だけcampaignをfreezeします。同じSHA/treeのproducer failureはpoisonし、rebuildを拒否します。
2. `PreflightEvidenceIndexV1`と`CandidateEvidenceIndexV1`を分離し、wireには`evidence_root_id`、logical POSIX path、actual byte size/hashだけを保存します。
3. Immutable 2,214-node baselineにexact 43 add + 1 move + 69 deleteを適用し、checkpoint manifestを決定的に導出します。`collection_sha256`はDesign §7.1のnormalized node-ID encodingを使い、P03はbaseline digest、P15はfinal projectionと一致します。Finalは2,188 assignmentsです。
4. `pytest_plugin.py`を移行前後の恒久filter ownerとし、root `tests/conftest.py`はtemporary seamに限定します。
5. Fault denominatorは20 categories / exact 45 entries、finite violation inventoryは68 codesです。Input/result schema familyを実装前に閉じます。
6. `StopReturnV1`はpre/post mutation、scope impact、owner/action、changed/external surface、rollback/recoveryを表し、`automatic_rollback_performed=false`を維持します。

詳細なP1対応表は`artifacts/p1-remediation-closure-v1.json`、P2の非blocking記録は`artifacts/strict-review-p2-record-v1.json`を参照してください。

## Pack layout

- `requirement.md` / `design.md` / `plan.md`: Issue childへ直接適用するcanonical replacement。
- `artifacts/20260917t124918z--luna-max-implementation-handoff.md`: implementation dispatch後のexecution contract。現在は`implementation_allowed: false`。
- `artifacts/provider-gate-contracts-v1.schema.json`: Draft 2020-12 closed schema family。
- `artifacts/role-ownership-v1.json`: 2,214-node immutable baseline。bytesを変更していません。
- `artifacts/role-ownership-delta-v1.json`: exact 43 add + 1 move + 69 delete。
- `artifacts/role-ownership-checkpoints-v1.json`: checkpointごとのfull resolved assignment。
- `artifacts/role-ownership-resolved-final-v1.json`: final 2,188 assignments。
- `artifacts/seeded-fault-catalogue-v1.json`: exact 45-entry catalogue。
- `artifacts/closed-violation-codes-v1.json`: finite 68-code inventory。
- `artifacts/old-policy-retirement-v1.json`: consumer-zero scanner/deletion/retained workflow contract。
- `artifacts/b1-b2-*.json`: corrected predecessor admission stateとfresh verification contract。
- `artifacts/issue-396-implementation-readiness.html`: ZIP内human guide。ZIP外のHTMLとbyte-identicalです。
- Parent contractsとhistorical evidence: preserved byte-for-byte。

## Manifest contract

`payload-manifest-v1.json`は自己自身と`manifest.sha256`を除く33 payloadを分類します。

| Classification | Count | Meaning |
|---|---:|---|
| `modified` | 7 | 既存pack payloadを完成版へ置換 |
| `new` | 11 | 新しいIssue-local machine-readable contract |
| `preserved` | 15 | Parent authority、immutable baseline、historical evidenceをbyte-preserve |

`manifest.sha256`はREADME、`payload-manifest-v1.json`を含むarchive内の全file（manifest自身を除く）をpath順でhashします。

以下はrepository rootから実行します。

```bash
ISSUE_DIR="spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00396-build-once-provider-gate-and-regression-policy-cutover"
PACK="$ISSUE_DIR/artifacts/issue-396-specification-pack.zip"
UNPACKED_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/iss396-pack.XXXXXXXX")"
python -m zipfile -t "$PACK"
python -m zipfile -e "$PACK" "$UNPACKED_ROOT"
python - "$UNPACKED_ROOT" <<'PY'
import hashlib
import sys
from pathlib import Path

root = Path(sys.argv[1])
for line in (root / "manifest.sha256").read_text(encoding="ascii").splitlines():
    expected, relative = line.split("  ", 1)
    actual = hashlib.sha256((root / relative).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit(f"hash mismatch: {relative}")
print("PASS manifest.sha256")
PY
cmp "$ISSUE_DIR/artifacts/issue-396-implementation-readiness.html" \
  "$UNPACKED_ROOT/$ISSUE_DIR/artifacts/issue-396-implementation-readiness.html"
```

## Remaining stop conditions

Product implementation開始には、次が順にすべて成立する必要があります。

1. 本仕様candidateをcleanなIssue branchへcommit/pushし、exact SHA/treeを固定。
2. Same Red session `iss396-spec-review-red`で`review_status=pass`、P0=0、P1=0。P2/P3はreview contractに従う。
3. Pass後にGitHub Issue #396 canonical projectionを更新し、readback。
4. #395 ownerがreported implementation defectを修正・受入。
5. Corrected #395 merge SHA/treeをGitHub readbackし、B1/B2 execution targetとして固定。
6. Corrected exact SHA/treeでfresh B1、その同一SHA/treeでfresh B2をaccepted。
7. Corrected #395 merge SHAがIssue #396の`SPEC_FREEZE_SHA`のancestorであることを確認。falseならowner-authorized branch dispositionへ戻し、realignment後にsource-bound artifact、ZIP、same-Red review、Issue projection readbackをやり直す。
8. Current specification freezeがclean・exactで、concurrent writerがない。
9. 別途のexplicit implementation dispatchを受領。
