# Issue #396 仕様書パック

## 目的

Epic #384の受入条件を保ちながら、Issue #396のbuild-once Provider Gate、テスト役割分担、evidence、required-context切替、旧policy撤去を実装できるよう、正本と必要な証拠を一つにまとめています。

## 正本と依存関係

- Issue #396のrequirement.md、design.md、plan.mdがIssue要件・設計・実装計画の正本です。
- 親Epicのrequirement.mdにあるE384-QUAL-001がqualification数値とpredicateの唯一のauthorityです。Issue #396で独立したqualification policyを作りません。
- artifacts/provider-gate-contracts-v1.schema.jsonがIssueのwire contract schemaです。実装時runtime copyはこのschemaとbyte-identicalにします。
- artifacts/role-ownership-v1.jsonと二つのcollect-only raw outputが、2,214 test nodeの事前割当と根拠です。
- B1/B2 receiptとraw JSONは#395 post-merge sourceのentry evidenceです。#396のreplacement gateやB3の証明には使いません。
- artifacts/issue-396-implementation-readiness.htmlは人向けの説明資料であり、Issue正本やEpic requirementを置き換えません。
- 初回Strict reviewで検出したP1の検証と修正はartifacts/20260917t162312z-strict-review-remediation-analysis.mdに記録しています。最新のレビュー判定はIssue #396のGitHub上の記録を参照してください。

## B1/B2から引き継ぐ入口証拠

B1/B2は#395のpost-merge source fd5df1d64b5d7ebf7bd4b41bb35fd8760d17e65d、tree 37eabc1aa250838dcd9f61d627309b0ff27e0db7で実施されています。B1はordinary pytest 1,367 passed / 847 skipped、lint・SpecDock validate・security guards GREEN。B2は2,188 passed / 26 skipped、15 total / 0 active / 15 resolved、violation 0です。これは#396の開始入力のみを証明します。

#396 replacement gate、required-contextの安全な切替、post-merge B3、Epic main受入は独立した後続ゲートです。Human mergeと明示dispatchも別の判断・操作です。仕様レビューpassのみではProduct実装を認可しません。

## パッケージ構成

このarchiveはrepository-relative hierarchyを保つため、MarkdownとHTMLの相対リンクを展開後も解決できます。manifest.sha256はREADMEを含む全payload fileのSHA-256をpath順に記録します。manifest自身とZIP自身は自己参照のため含めません。展開後は次でentryを検証できます。

    shasum -a 256 -c manifest.sha256

ZIPの最終SHA-256とGit blob IDは、review済み候補のIssue branch上の記録から確認できます。
