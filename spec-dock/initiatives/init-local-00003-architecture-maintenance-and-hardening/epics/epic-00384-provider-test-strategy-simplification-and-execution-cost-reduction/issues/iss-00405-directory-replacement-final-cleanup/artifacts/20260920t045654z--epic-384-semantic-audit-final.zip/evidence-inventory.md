# Epic #384 証拠・実装／テスト完全棚卸し

## 1. 対象identity

| field | value |
|---|---|
| repository | chemitaro/spec-dock |
| branch | codex/epic-00384-provider-test-strategy-planning |
| expected SHA | 396dadc78b4dfae043064438035e77ab1ab3aa56 |
| observed SHA | 396dadc78b4dfae043064438035e77ab1ab3aa56 |
| tree | 43f2b942a8ff211e7558e1d40a0e6203b45127e7 |
| audit verdict | PARTIAL |

## 2. connector操作と観測結果

| 操作 | 対象 | 観測結果 |
|---|---|---|
| GitHub tool discovery | branch/ref/fetch/file/tree/PR operations | 利用可能。empty searchだけをabsence判断に使用していない。 |
| exact ref fetch | chemitaro/spec-dock refs/heads/codex/epic-00384-provider-test-strategy-planning | object.type=commit, object.sha=396dadc78b4dfae043064438035e77ab1ab3aa56 |
| AGENTS.md fetch | 396dadc78b4dfae043064438035e77ab1ab3aa56:AGENTS.md | repository固有指示を確認。 |
| commit fetch | 396dadc78b4dfae043064438035e77ab1ab3aa56 | tree=43f2b942a8ff211e7558e1d40a0e6203b45127e7 |
| recursive tree / contents | 396dadc78b4dfae043064438035e77ab1ab3aa56:tests, src/spec_dock, workflows, docs | exact target path inventoryを取得。 |
| PR #404 changed filenames | PR #404 | 旧engine/CI/tests削除とcurrent source/test変更面を取得。 |
| main/target compare | relation check only | same tree/file diff 0。mainをsource代用にはしていない。 |
| check-run fetch | strict SHA / same-tree PR head | 履歴statusを取得。test再実行とは扱わない。 |

未実行: connector authentication変更、request再送、default branch fallback、write operation、pytest/lint/build。

## 3. authority inventory

| path | 分類 | 要点 |
|---|---|---|
| Epic requirement.md | CURRENT AUTHORITY | R1-R10、撤去対象、受入条件。 |
| Epic design.md | CURRENT AUTHORITY | provider auth/shared lease撤去、clean/fixed ref/safe worktree保持。 |
| Epic plan.md | CURRENTだがstatus stale | U1/U2 integration中、U3未実施の更新が必要。 |
| 20260919 ADR | ACCEPTED AUTHORITY | 6directory交換、data保持、外部installer再実行。 |
| Epic report.md | CURRENT READ SURFACE / stale | 旧parent-planning/lease/qualification narrativeをHistoricalへ降格要。 |
| #392/#395 R/D/P、old Wire/qualification artifacts | HISTORICAL | current義務へ戻さない。 |

## 4. production implementation inventory

| path / symbol | 到達性 | 分類 | 根拠 |
|---|---|---|---|
| src/spec_dock/installer.py:ROOTS/SKILLS/TOOL_DIRECTORIES | installer init/update/uninstall | KEEP | 6directory boundary。 |
| installer.py::_check_target/_sources/_copy/install/uninstall | public installer CLI | KEEP | small preflight + sequential replace + final version。 |
| src/spec_dock/cli.py::main | entrypoint | KEEP | init/update/uninstall grammar/data purge rejection。 |
| runtime commands/update.py / uninstall.py | runtime command | KEEP | fixed upstream external installer request。 |
| runtime wrapper `_installer_exec` | terminal request | KEEP | root FDを閉じてexternal uvxへexec。 |
| infra/git_cli.py::_run_git_write | issue/worktree writes | REWRITE/SPLIT | automatic root shared leaseを撤去しtarget-bound worktree責務だけ分離。 |
| infra/git_cli.py::assess_capabilities | issue/worktree | DELETE/SPLIT | provider full-tree gate撤去。materializer固有検査のみ残す。 |
| infra/git_cli.py::pinned_checkout/verify_pinned_checkout | issue start | REWRITE | generation witnessを外しfixed target/HEAD checkへ縮退。 |
| infra/git_helper.py | Git child | REWRITE/DELETE | provider lease helperをgeneric target-bound helperへ縮退する場合のみ残す。 |
| application/contracts.py::GitCapabilityAssessment | ports/application | DELETE | provider capability result。 |
| application/contracts.py::PinnedCheckout | issue lifecycle | REWRITE/DELETE | minimal checkout resultへ縮退。 |
| application/set_active.py::_LAST_PINNED_CHECKOUT/last_pinned_checkout | issue start | DELETE | global generation witness。 |
| application/issue_lifecycle.py::issue_start | public command | REWRITE | deps/active/syncを残し二重generation authを撤去。 |
| application/worktree.py::_pin_worktree_source/_open_source_shared | worktree create | REWRITE | fixed commit保持、repository shared flock撤去。 |
| application/worktree.py target no-follow/EX/inode functions | worktree create/remove | KEEP | safe target general feature。 |
| git_cli materialize/publish tree primitives | worktree create | KEEP/REWRITE adapter | fixed commit、safe tree、entrypoint-last。 |
| ConsumerHookRequest + wrapper `_consumer_hook` | worktree create terminal | KEEP | bound cwd/inode general feature。 |
| create/import create.lock | node/data mutation | KEEP | data-operation lock。 |
| .github/workflows/provider-ci.yml | PR CI | KEEP | direct pytest/lint + Linux/macOS basics。 |
| provider-full-regression.yml / ledger/sharder | current tree absent | HISTORICAL | PR #404で撤去済み。 |

## 5. F001 call graph

```text
issue start
  issue_lifecycle.issue_start
    checkout_active_target
      GitGateway.pinned_checkout
        git_cli.assess_capabilities
        git_cli._run_git_write
          fcntl.LOCK_SH(repository root)
          python -m spec_dock_runtime.infra.git_helper
      GitGateway.verify_pinned_checkout
    last_pinned_checkout
    GitGateway.verify_pinned_checkout  # second check

worktree create/remove
  worktree._pin_worktree_source -> assess_capabilities
  worktree._open_source_shared -> LOCK_SH(source repo)
  add/remove/materialize -> _run_git_write -> git_helper
  target path no-follow/EX/inode + consumer hook binding  # KEEP
```

## 6. focused test inventory summary

- individual focused test cases（ASTと明示parametrizeから静的展開）: **100**
- `test_init_update.py`: 57 functions / **58 cases**
- dispositions (cases only): KEEP=88, REWRITE=9, DELETE=3
- support/group/historical rowsを含むCSV総行数: **125**

完全なmachine-readable版は`test-inventory.csv`です。`pytest --collect-only`は本監査で実行しておらず、parameter caseはsource decoratorから静的展開しています。

### 6.1 `test_init_update.py` 全case

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/unit/infra/test_init_update.py::test_issue_334_init_and_update_install_current_target_catalog_byte_exact | 65 | — | KEEP | R1/R4: init/update後のcurrent target catalog byte parity。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::test_issue_334_update_preserves_unmanaged_content | 84 | — | REWRITE | R2/R10: 対象外データと無関係pathの保持。 | 利用者データ保持の本体を残し、`spec-dock-issue-planning`単独の不存在assertを削除する。 |
| tests/unit/infra/test_init_update.py::test_issue_334_checked_in_dogfood_projection_matches_provider | 100 | — | KEEP | provider sourceとdogfood projectionのbyte parity。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::test_grill_with_docs_source_boundary_separates_access_context_from_evidence | 124 | — | KEEP | 外部grill skillのread-only source boundary。Epic外の現行機能。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::test_issue_360_spec_dock_guidance_is_agent_first_and_not_present_only | 159 | — | KEEP | agent-first guidanceのcurrent public contract。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_init_gitignore_ignores_exact_workbench_directories_at_supported_scopes | 1189 | — | KEEP | Workbench ignore boundary。管理6directory交換とは独立した一般機能。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_workbench_readme_assets_are_byte_identical_and_complete | 1233 | — | KEEP | Workbench README asset parity。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_issue_78_init_allows_install_when_legacy_hidden_workspace_exists | 1260 | — | KEEP | R2: 旧hidden workspaceは固定6directory外の利用者データとして保持。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_issue_78_update_keeps_legacy_hidden_workspace_untouched_during_coexistence | 1278 | — | KEEP | R2: updateでも旧hidden workspaceを不変にする。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_init_and_update_ship_root_artifact_rules_and_import_links_them_safely[init] | 1301 | init | KEEP | root Artifact rulesのinit/update配布と安全なsymlink。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_init_and_update_ship_root_artifact_rules_and_import_links_them_safely[update] | 1301 | update | KEEP | root Artifact rulesのinit/update配布と安全なsymlink。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_issue_69_native_build_venv_installs_backend_requirements_in_place | 1343 | — | KEEP | isolated package build helperの正しさ。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_issue_69_pip_unavailable_fallback_keeps_target_install_semantics | 1405 | — | KEEP | pip不在時のpackage install fallback。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_built_wheel_replaces_stale_python_and_asset_output | 1449 | — | REWRITE | stale build outputをwheelへ混入させないpackage hygiene。 | `spec_dock/provider_lifecycle/retired.py`という旧名称fixtureを一般的なstale module名へ変更する。package hygieneの検査自体は残す。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_distribution_full_install_root_inventory_is_packaged_in_wheel_sdist_and_installed_resources | 1492 | — | KEEP | wheel/sdist/installed resourceのinstall_root完全一致。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_workbench_readme_distribution_inventory_and_bytes_match_all_surfaces | 1506 | — | KEEP | Workbench READMEのsource/wheel/sdist/install parity。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_surface_includes_doctor_and_explicit_target_hint | 1568 | — | KEEP | dogfood runtimeのcurrent command surface。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_mirror_docs_match_provider_assets | 1596 | — | KEEP | shipped docsのprovider/dogfood parity。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_active_none_reports_match_provider_assets | 1600 | — | KEEP | active-none reportsのprovider/dogfood parity。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_deps_mutation_on_cutover_snapshot | 1604 | — | KEEP | dogfood runtimeのdeps mutation一般機能。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_mirror_match_provider_assets | 1674 | — | KEEP | runtime source mirrorの完全一致。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_dogfooding_runtime_inventory_excludes_generated_python_caches | 1678 | — | KEEP | generated Python cacheを配布inventoryから除外。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_keeps_repo_scoped_import_uniqueness_parity | 1693 | — | KEEP | repo-scoped import identity一般機能。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_import_release_lock_backward_compat_parity | 1917 | — | REWRITE | create/import data-operation lockのownership/release。 | 挙動は残し、`backward_compat`を外してcurrent create-lock ownership/release契約として改名する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_import_import_race_revalidation_parity | 1967 | — | KEEP | import/import race revalidation。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_import_new_race_revalidation_parity | 2211 | — | KEEP | import/new race revalidation。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_no_write_preflight_collision_with_active_parent_fallback_parity | 2462 | — | KEEP | preflight collision時のzero-write。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_keeps_repo_scoped_sync_snapshot_parity | 2718 | — | KEEP | repo-scoped sync snapshot。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_non_issue_deps_target_status_parity | 2929 | — | KEEP | non-Issue deps target status。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_issue_create_lock_scope_narrowing_parity | 3087 | — | KEEP | GitHub create中のdata-operation lock scope。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_issue_create_pre_github_validation_parity | 4013 | — | KEEP | GitHub副作用前のcreate validation。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_non_issue_create_guidance_parity | 4232 | — | KEEP | non-Issue create失敗時のrecovery guidance。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_create_mode_graph_preflight_parity | 4465 | — | KEEP | create mode graph preflight。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_keeps_unscoped_current_repo_fallback_sync_parity | 4620 | — | KEEP | unscoped current-repo fallback sync。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_keeps_repo_scoped_validation_doctor_parity | 4814 | — | KEEP | repo-scoped validate/doctor。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_keeps_numeric_branch_current_repo_overlap_parity | 4974 | — | KEEP | numeric branchのcurrent-repo scope解決。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_tool_version_fallback_reads_pyproject | 5254 | — | KEEP | package/source version resolution。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_no_skill_option_is_rejected | 5271 | — | KEEP | retired `--no-skill` option rejection。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_provider_ci_runs_normal_suite_without_a_policy_evaluator | 5275 | — | KEEP | current CI commandと旧policy evaluator/ledger非採用。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_issue_360_readme_catalog_excludes_historical_artifact_routes | 5283 | — | KEEP | current artifact route catalogの公開interface境界。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_issue_71_upstream_handoff_reports_expose_evidence_bearing_sections | 5302 | — | KEEP | historical handoff report evidence sections。Epic外の文書品質機能。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_reference_sync_doc_matches_bundled_asset | 5382 | — | KEEP | reference_sync doc parity。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_reference_deps_doc_matches_bundled_asset | 5392 | — | KEEP | reference_deps doc parity。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_import_post_sync_no_crash_parity | 5530 | — | KEEP | import後sync一般機能。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_issue_create_gateway_failure_pre_github_parity | 5560 | — | KEEP | GitHub gateway failure前のzero local write。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_numeric_deps_overlap_parity | 5617 | — | KEEP | numeric deps overlap resolution。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_scoped_deps_ref_parity | 5666 | — | KEEP | scoped deps reference resolution。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_numeric_deps_ref_foreign_only_fail_closed_parity | 5721 | — | KEEP | foreign-only numeric deps fail closed。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_keeps_lone_unscoped_legacy_without_backfill_parity | 5765 | — | KEEP | lone unscoped legacy linkをreadonly syncでbackfillしない。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_keeps_readonly_lone_unscoped_without_backfill_parity | 5801 | — | KEEP | readonly metaでもunscoped linkをbackfillしない。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_validation_boundary_prefers_structure_error | 5850 | — | KEEP | validation error precedence。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_sync_fails_when_required_artifact_missing | 5887 | — | KEEP | required artifact missing時のsync fail-fast。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_import_fails_fast_when_required_artifact_missing | 5905 | — | KEEP | required artifact missing時のimport fail-fast。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_import_partial_write_doctor_first_parity | 5948 | — | KEEP | import partial write時のdoctor-first guidance。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_sync_force_degrades_when_required_artifact_missing | 6025 | — | KEEP | forced sync degradation。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_sync_validation_boundary_prefers_structure_error | 6055 | — | KEEP | sync validation error precedence。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_validate_doctor_fail_when_required_artifact_missing | 6078 | — | KEEP | validate/doctor required artifact diagnosis。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |
| tests/unit/infra/test_init_update.py::TestInitUpdate::test_checked_in_dogfooding_runtime_subprocess_create_lock_missing_meta_diagnosis_parity | 6102 | — | KEEP | create-lock存在時のmissing-meta diagnosis。 | 現状の意味を維持する。旧Txx/Issue番号が判断を誤らせる場合のみ名称整理する。 |

### 6.2 `test_directory_installation.py` 全11 node

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/unit/infra/test_directory_installation.py::test_update_replaces_whole_directories_and_preserves_data | 8 | — | KEEP | R1/R2/R5 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_installed_runtime_starts_without_provider_markers | 21 | — | REWRITE | runtime smoke + current catalog | `test_installed_runtime_starts_from_current_catalog`等へ改名し、line 34のmarker固有assertを削除する。 |
| tests/unit/infra/test_directory_installation.py::test_failed_copy_can_be_retried_without_touching_data | 37 | — | REWRITE | R8/受入3 | 後半copy失敗を追加し、非zero、data不変、version未更新、再実行後6tree一致を検証する。2/4/6は監査提案であり承認済み要件ではない。 |
| tests/unit/infra/test_directory_installation.py::test_uninstall_dry_run_then_removes_only_tool_directories | 58 | — | KEEP | R6 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_symlink_parent_is_rejected_before_any_replacement | 71 | — | KEEP | R7 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_force_init_replaces_tools_without_reseeding_settings | 88 | — | KEEP | R3/R10 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_all_six_directories_match_package_and_discard_old_files | 98 | — | KEEP | 受入1 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_missing_source_is_rejected_before_deleting_anything | 126 | — | KEEP | R7 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_version_hard_link_does_not_modify_external_data | 139 | — | KEEP | R2/R5 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_fresh_install_rejects_copy_into_its_scaffold_source | 153 | — | KEEP | R7 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_failed_fresh_init_is_retried_after_preserving_partial_scaffold | 178 | — | KEEP | R8 fresh-init | 維持。 |

### 6.3 update/uninstall runtime nodes

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/cli_runtime/test_update.py::TestUpdateCommand::test_update_help_describes_upstream_no_cache_and_default_target | 7 | — | KEEP | fixed upstream/no-cache/default target help | 維持。 |
| tests/cli_runtime/test_update.py::TestUpdateCommand::test_update_rejects_unsupported_options | 20 | — | KEEP | arbitrary source/cache/force非公開 | 維持。 |
| tests/cli_runtime/test_uninstall.py::TestUninstallCommand::test_spec_purge_is_rejected_without_mutation | 8 | — | KEEP | R6 data purge rejection | 維持。 |
| tests/cli_runtime/test_uninstall.py::TestUninstallCommand::test_uninstall_help_describes_upstream_no_cache_and_default_target | 18 | — | KEEP | fixed upstream/no-cache/default target help | 維持。 |
| tests/cli_runtime/test_uninstall.py::TestUninstallCommand::test_uninstall_rejects_unsupported_options | 31 | — | KEEP | arbitrary source/cache非公開 | 維持。 |

### 6.4 distribution current catalog nodes

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/cli_runtime/test_distribution_cutover.py::test_s40b_provider_install_root_is_current_catalog_only | 55 | — | KEEP | current install_root exact catalog | 名称からS40Bを外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_s40b_retained_skill_identity_matches_current_provider_and_dogfood | 61 | — | KEEP | 2 retained skills provider/dogfood parity | 名称からS40Bを外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_s40b_only_runtime_wrapper_is_executable_across_current_surfaces | 71 | — | KEEP | executable mode contract | 名称からS40Bを外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_fresh_init_copies_skill_directories_without_markers | 93 | — | KEEP | fresh init current external inventory exact equality | `test_fresh_init_copies_exact_current_external_catalog`へ改名する。 |
| tests/cli_runtime/test_distribution_cutover.py::test_s45_fresh_preserves_unrelated_and_obsolete_looking_external_paths | 103 | — | KEEP | R2/R10 external data preservation | 名称からS45を外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_s45_existing_consumer_seed_is_preserved | 127 | — | KEEP | R10 existing consumer workflow preservation | 名称からS45を外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_s45_foreign_fixed_root_is_preserved_and_blocks_fresh_install | 138 | — | KEEP | R3/R7 foreign fixed root fail-before-write | 名称からS45を外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_init_replaces_the_fixed_skill_directory | 150 | — | KEEP | R1 fixed skill replacement | 維持。 |

### 6.5 provider generation / checkout nodes

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_t10_existing_and_new_checkout_are_pinned_and_generation_safe | 13 | — | REWRITE | issue startのnew/existing branch、clean tree、fixed HEAD | `test_issue_start_existing_and_new_checkout_use_fixed_head_and_clean_tree`へ再構成し、provider capability拒否部分を削る。 |
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_existing_branch_can_use_different_tooling_version | 54 | — | KEEP | provider generation差異をcheckout阻害条件にしない | class名を`TestCheckoutSafety`等へ改名する。 |
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_t10_effective_diff_and_merge_attributes_are_rejected_before_mutation[diff=custom] | 83 | diff=custom | DELETE | 現行authorityにGit diff attribute拒否契約なし | 削除。一般worktree materializerはGit blobを直接materializeする現行試験で守る。 |
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_t10_effective_diff_and_merge_attributes_are_rejected_before_mutation[merge=custom] | 83 | merge=custom | DELETE | 現行authorityにGit merge attribute拒否契約なし | 削除。 |
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_capability_guard_covers_the_materialized_tree | 123 | — | REWRITE | worktree materializerのsubmodule/unsafe tree拒否 | `test_worktree_materializer_rejects_submodule_before_publication`としてworktree領域へ移し、issue startには適用しない。 |
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_t10_sparse_checkout_effective_values_and_skip_worktree_are_rejected | 160 | — | DELETE | 現行authorityにsparse checkout一律拒否契約なし | 削除。 |

### 6.6 handoff nodes

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/cli_runtime/test_runtime_handoff.py::TestProviderLifecycleHandoff::test_t11_consumer_hook_parent_io_failure_is_detection_failure_with_exit_zero | 37 | — | KEEP | consumer hookのbest-effort result contract | class/functionからProviderLifecycle/T11を外す。 |
| tests/cli_runtime/test_runtime_handoff.py::TestProviderLifecycleHandoff::test_t11_consumer_hook_binding_mismatch_is_detection_failure_with_exit_zero | 80 | — | KEEP | consumer hook bound cwd device/inode safety | class/functionからProviderLifecycle/T11を外す。 |
| tests/cli_runtime/test_runtime_handoff.py::TestProviderLifecycleHandoff::test_t04_terminal_handoff_preserves_symlink_target_for_external_admission | 117 | — | KEEP | runtime update/uninstallからexternal installerへのtarget/exit handoff | `external_installer_handoff`へ改名する。 |
| tests/cli_runtime/test_runtime_handoff.py::TestProviderLifecycleHandoff::test_t01_relative_lifecycle_targets_use_invoking_cwd_and_preserve_symlink_text | 152 | — | KEEP | relative target resolutionとinvoking cwd | `lifecycle`/T01を外して改名する。 |
| tests/cli_runtime/test_runtime_handoff.py::TestProviderLifecycleHandoff::test_t04_git_write_helper_cannot_be_shadowed_by_consumer_module | 193 | — | REWRITE | target-bound Git childを残す場合のmodule provenance | generic helperへ書換える。helperを全廃する実装なら削除する。owner判断ではなく実装形態に従う。 |

### 6.7 worktree overlap nodes

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/cli_runtime/test_worktree_lifecycle_coordination.py::TestWorktreeLifecycleCoordination::test_t11_worktree_b_create_remove_and_make_handoff_are_inode_bound | 18 | — | KEEP | worktree target inode、entrypoint publication、consumer handoff | 挙動を維持し、T11/旧Wire由来の名称だけを整理する。cross-filesystem対応を新たに決定しない。 |
| tests/cli_runtime/test_worktree_lifecycle_coordination.py::TestWorktreeLifecycleCoordination::test_t11_cross_filesystem_worktree_admission_is_rejected_before_git_mutation | 84 | — | KEEP | current same-filesystem admissionによるpre-mutation safety | 挙動を維持し、T11/旧Wire由来の名称だけを整理する。cross-filesystem対応を新たに決定しない。 |
| tests/cli_runtime/test_worktree_lifecycle_coordination.py::TestWorktreeLifecycleCoordination::test_t11_original_worktree_inode_is_preserved_when_git_leaves_it | 102 | — | KEEP | 別inode/残存directory誤削除防止 | 挙動を維持し、T11/旧Wire由来の名称だけを整理する。cross-filesystem対応を新たに決定しない。 |
| tests/cli_runtime/test_worktree_lifecycle_coordination.py::TestWorktreeLifecycleCoordination::test_t11_worktree_remove_reports_busy_target_before_git_mutation | 160 | — | KEEP | worktree data-operation EX lockとbusy拒否 | 挙動を維持し、T11/旧Wire由来の名称だけを整理する。cross-filesystem対応を新たに決定しない。 |
| tests/cli_runtime/test_worktree.py::TestCliWorktree::test_nonlocking_hook_fd_rejects_replacement_of_locked_worktree | 93 | — | KEEP | consumer hook target binding | 維持。 |
| tests/cli_runtime/test_worktree.py::TestCliWorktree::test_materializer_rejects_foreign_existing_descendant_directory | 473 | — | KEEP | worktree target boundary | 維持。 |
| tests/cli_runtime/test_worktree.py::TestCliWorktree::test_materialize_worktree_passes_source_lease_to_read_tree_helper | 721 | — | REWRITE | fixed commit + target-bound materialization | `read-tree`がpinned commitをtarget-bound cwdで実行し、source shared flockを要求しないことへ書換える。 |

## 7. fixtures/helpers/harness

| path | symbol | 行 | 分類 | 理由/処置 |
|---|---|---|---|---|
| tests/unit/infra/conftest.py | _SETUP_ONLY_PREFIXES | 12-17 | REWRITE | `test_recognized_reconciliation_`、`test_uninstall_`、`test_update_`は現行test_init_update.pyのtest名に実在しないdead prefix。 dead prefixを削除し、残るprefixまたは明示allowlistだけにする。 |
| tests/unit/infra/conftest.py | _clone_tree_contents | 20-31 | KEEP | production provider lifecycleではなくtest setup cost削減。 維持。 |
| tests/unit/infra/conftest.py | _infra_init_template | 34-39 | KEEP | 対象testがinit自体を観測しない場合のsetup。 維持。 |
| tests/unit/infra/conftest.py | _reuse_infra_init_result | 42-65 | KEEP | fault/cutover testへ適用されない現行条件を保持。 prefix方式は明示allowlistへ簡素化可能。 |
| tests/cli_runtime/conftest.py | _TEMPLATE_MODULES | 24-42 | KEEP | init実装を観測しないmoduleだけを対象にする。 維持。 |
| tests/cli_runtime/conftest.py | _DISTRIBUTION_SETUP_OPERATIONS | 44-59 | DELETE | 現行8 node名にupdate/uninstall/recognizedがなく到達しない。 `_DISTRIBUTION_CUTOVER_MODULE`を含むspecial branch全体を削除する。 |
| tests/cli_runtime/conftest.py | _clone_tree_contents / _fresh_init_template / _reuse_fresh_init_result | 62-117 | KEEP | 一般command testのsetup costを削減し、cutover/security testはreal initへ残す。 維持。 |
| tests/cli_runtime/harness.py | _EXPECTED_MANAGED_SKILL_NAMES | 33-36 | KEEP | 現行2skillのpositive allowlist。 維持。 |
| tests/cli_runtime/harness.py | _DELETED_ROLE_SKILL_NAMES | 37-59 | DELETE | current exact catalog/assertと重複し、旧名称を恒久固定する。 削除。 |
| tests/cli_runtime/harness.py | _assert_managed_skills_installed | 560-576 | REWRITE | positive exact setは保持し、旧名称ごとのloopを削除。 current set equalityだけに簡素化する。 |
| tests/unit/infra/test_init_update.py | _managed_tree_bytes | 52-62 | REWRITE | `.spec-dock-provider-slot.json`だけを除外する旧例外が再混入を隠し得る。 marker special-caseを削除し、一般cacheのみ除外する。 |

## 8. repository-wide test groups

| path group | 分類 | 現行契約 | 根拠 |
|---|---|---|---|
| tests/cli_runtime/test_active.py; test_artifact_import*.py; test_close.py; test_delete.py; test_deps.py; test_doctor.py; test_import.py; test_issue_lifecycle.py; test_new.py; test_storage_core_cli.py; test_sync.py; test_validate.py; test_workbench.py; test_wrappers.py | KEEP | active/import/delete/deps/sync/validate/artifact/issue lifecycle | F001のprovider capability symbolsを直接所有せず、現行Storage Core/Authoring Kitの一般機能を検証する。adapter変更に伴うfixture修正だけ行い、behaviorは保持。 |
| tests/cli_runtime/test_runtime_active_s06.py; test_runtime_close_s12.py; test_runtime_delete_s13.py; test_runtime_deps_s04.py; test_runtime_import_s10.py; test_runtime_new_s08.py; test_runtime_shell_s11.py; test_runtime_validate_s02.py | KEEP | runtime layer contracts and regression observers | 旧番号を含むものがあるが、現行command/application/infra/presentation責務を守る一般test。provider generation call pathが確認されたnodeは別表へ抽出済み。 |
| tests/unit/application/** | KEEP | application use cases | data/application contractを検証。provider lifecycle engine撤去とは独立。 |
| tests/unit/cli/** | KEEP | CLI parser and smoke | 公開parser/CLI基本動作。 |
| tests/unit/commands/** | KEEP | thin command wrappers | current command layer。 |
| tests/unit/domain/** | KEEP | domain ids/models/deps/tree/naming | 固定directory installerとは独立したdomain contract。 |
| tests/unit/infra/* except conftest.py, test_directory_installation.py, test_init_update.py | KEEP | active store, artifact publisher, workbench opacity, template scaffolder, deps reader | 利用者dataとruntime infraの一般機能。旧provider engine fileはcurrent treeから削除済み。 |
| tests/unit/presentation/** | KEEP | text/JSON rendering | current output contract。 |
| tests/integration/** | KEEP | package artifact parity, installed runtime, platform probes | exact package/runtime配布を検証。旧provider marker/journal/lease語のcurrent assertionは確認されていない。 |
| tests/unit/test_discovery.py; tests/integration/test_discovery.py; tests/unit/test_static_analysis_script.py | KEEP | test discovery and lint runner | pytest discoveryとstatic analysis scriptの一般品質gate。 |

## 9. current treeから削除済みの旧test

| path | 分類 | 旧責務 |
|---|---|---|
| tests/unit/infra/test_managed_distribution.py | HISTORICAL | old per-file plan/journal/reconciliation engine suite |
| tests/unit/test_full_regression_baseline.py | HISTORICAL | old regression ledger/baseline evaluator suite |
| tests/unit/test_provider_test_lanes.py | HISTORICAL | old policy skip/provider lanes suite |
| tests/conftest.py | HISTORICAL | old full-regression policy collection hooks |

## 10. negative assertion再判定

| surface | 判定 | 重複/契約 |
|---|---|---|
| CI direct commands + evaluator/ledger absence | KEEP | CI architecture boundary。current commandのpositive assertionと一体。 |
| install_root exact equality | KEEP | extra/missingの双方を検知。 |
| single slot-marker absence in runtime smoke | DELETE/吸収 | exact equalityと重複。 |
| tree helper marker exclusion | REWRITE | 完全一致を弱める特例。 |
| fresh external inventory test | KEEP+RENAME | 全inventory equalityでありabsence-onlyではない。 |
| retired role names loop | DELETE | current exact setと重複。 |
| historical artifact route absence | KEEP | finite public CLI catalogのinterface contract。 |

## 11. dynamic evidence ledger

| evidence | target | result | authority |
|---|---|---|---|
| Codex local focused run | exact clean HEAD / tests/unit/infra/test_directory_installation.py | 11 passed in 0.96s, exit 0 | ユーザー提供の限定証拠。ChatGPT未再実行。 |
| strict SHA check runs | 396dadc78b4dfae043064438035e77ab1ab3aa56 | check/validate success | GitHub履歴。full provider suiteではない。 |
| PR #404 same-tree checks | 2a677ce5dcc547f1e0916a38431b9b7dd52c70d5 | provider-tests、Linux/macOS basics等success | 同一tree履歴。strict SHAの個別再実行ではない。 |
| ChatGPT full pytest | — | 未実行 | 合格と記載しない。 |
| ChatGPT lint/package/platform | — | 未実行 | 合格と記載しない。 |

## 12. old mechanism search classification

| term/surface | active production | current test | historical docs | 判断 |
|---|---|---|---|---|
| provider_lifecycle package | 不存在 | fixture/class名のみ一部残存 | 多数 | production撤去済み。names/fixtures cleanup。 |
| .spec-dock-provider-slot.json | 不存在 | helper exception + single absence | old artifacts | F003。current exact catalogへ吸収。 |
| distribution journal / retry guard | 不存在 | current active testなし | old artifacts | HISTORICAL。 |
| full-regression ledger/sharder | 不存在 | CI absence assertion | old artifacts | engine撤去済み。CI assertion KEEP。 |
| runtime-generation-drift / GitCapabilityAssessment | 到達可能 | generation tests | old artifacts | F001 active residual。 |
| repository shared lease / git_helper FD inheritance | 到達可能 | handoff/worktree tests | old artifacts | F001と一般target safetyを分離。 |
| create.lock | 到達可能 | init_update/general tests | current data operation | KEEP。provider shared leaseとは別責務。 |

## 13. 調査済み範囲

- exact branch/ref/SHA/tree/AGENTS
- installer/CLI/runtime update/uninstall
- Git adapters、application consumers、types/ports/bootstrap
- worktree materializer/target safety/consumer hook
- package config、CI、Makefile/static analysis
- shipped docs/skills/templates/system/scripts、dogfood mirrors
- current Epic R/D/P/ADR/ReportとIssue #396 report/plan
- exact tests tree全領域のpath inventory
- focused 100 case + helper/fixture/harness + removed historical suites
- PR #404 changed pathsとmerge/tree relation

## 14. 未実行・未確認

- full pytest collection/run、lint、build、wheel/sdist install、platform再実行
- 全historical artifactの逐語レビュー（current authorityではないため対象外）
- 外部consumer repository
- branch protection設定とraw Actions logsの全annotation
- cross-filesystem worktree supportの将来仕様（新規判断をしていない）

原因未特定のsource findingはありません。動的なfull-suite適合だけが未確認です。
