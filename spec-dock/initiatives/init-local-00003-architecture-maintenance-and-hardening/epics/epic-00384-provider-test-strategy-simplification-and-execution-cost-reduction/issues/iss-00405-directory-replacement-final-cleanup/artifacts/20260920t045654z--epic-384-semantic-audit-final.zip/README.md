# epic-384-semantic-audit-final

## 対象

- repository: `chemitaro/spec-dock`
- strict target branch: `codex/epic-00384-provider-test-strategy-planning`
- expected / connector-observed SHA: `396dadc78b4dfae043064438035e77ab1ab3aa56`
- target tree: `43f2b942a8ff211e7558e1d40a0e6203b45127e7`
- audit date: `2026-09-20`

GitHub connectorでexact branch refのfull SHAを再取得し、期待値との完全一致を確認した後、このcommitだけをsource of truthとして追加監査しました。main/PRはmerge/tree関係の確認にのみ使用し、対象の代用にはしていません。

## 結論

**PARTIAL**です。installerの6固定directory交換は概ね成立していますが、provider世代認証・repository shared lease・full-tree capability gateのactive consumerと、shipped READMEの旧保証が残っています。通常の技術P0は0件です。技術的重大度とEpic完了上のMUST-FIXを分離しています。

## ファイル

1. `index.html` — 前提知識なしで全体像を読める自己完結HTML。
2. `audit-report.md` — findings、call graph、保持/撤退境界、修正順、完了条件。
3. `evidence-inventory.md` — connector操作、source/test/docsの証拠台帳、完全なfocused node表。
4. `test-inventory.csv` — machine-readableなtest case/helper/group分類。

## 動的証拠の境界

- Codex側限定検証（ユーザー提供）: 同一clean HEADで `uv run pytest tests/unit/infra/test_directory_installation.py -q`、`11 passed in 0.96s`、exit 0。
- ChatGPTはfull pytest、lint、wheel/sdist build、Linux/macOS jobを再実行していません。
- GitHub check successは履歴証拠であり、本監査自身の実行結果ではありません。
- 静的tree/call graph網羅性と動的合格を混同していません。

## test inventoryの読み方

- `KEEP`: 現行契約を独立に守るため残す。
- `DELETE`: 旧provider機構だけを固定し、現行契約の代替testがある。
- `REWRITE`: 一般安全性を残し、provider generation/leaseへの結合だけを外す。
- `HISTORICAL`: target treeから既に削除済み。

## SHA-256

- `audit-report.md`: `566ec62665a332473a5a22a3cad38958e77422692de376bb66b40dd8fedd0c1f`
- `evidence-inventory.md`: `117f7573882fb1cb8ad5f2b02673ca98d5ceb33501a875a2330a267727d644b7`
- `index.html`: `54029dee0f4c19860529fc0b1bb6580ce25cf9503e49104263b39c9699225a4a`
- `test-inventory.csv`: `58ebb2b47ba4dbe66658c9acadbef68dc37066c27e3e4004008b63e9f19c746b`
