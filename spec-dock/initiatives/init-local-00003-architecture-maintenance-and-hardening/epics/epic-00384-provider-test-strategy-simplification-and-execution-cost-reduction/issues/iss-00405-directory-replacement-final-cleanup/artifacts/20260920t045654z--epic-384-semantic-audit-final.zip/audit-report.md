# Epic #384 追加統合・独立意味監査（最終版）

- 監査日: 2026-09-20
- repository: `chemitaro/spec-dock`
- strict target branch: `codex/epic-00384-provider-test-strategy-planning`
- expected / observed SHA: `396dadc78b4dfae043064438035e77ab1ab3aa56`
- target tree: `43f2b942a8ff211e7558e1d40a0e6203b45127e7`
- main merge SHA（関係確認のみ）: `400846141a946f7cb98de20d1f40361b8a238f10`
- PR #404 head SHA（履歴確認のみ）: `2a677ce5dcc547f1e0916a38431b9b7dd52c70d5`
- 判定: **PARTIAL**
- 本監査でChatGPTが実行したpytest / lint / package build: **未実行**

## 1. 結論

固定6ディレクトリを削除・コピーし、利用者データを境界外に残すinstaller本体は、現行R1〜R8/R10へ概ね移行しています。`src/spec_dock/installer.py`は、全sourceとtarget種別を削除前に確認し、6directoryを順次`rmtree`/`copytree`し、全copy成功後にだけversionを書きます。

ただし、**Epicの意味的完了はまだ`PARTIAL`**です。主因は次の2件です。

1. `issue start`と`worktree`の到達経路に、現行Designが撤去するとしたprovider世代認証、repository共有lease、full-tree capability gateが残っています。
2. shipped READMEが、廃止済みのdescriptor binding・semantic source equality・compatible newer package resumeをcurrent保証として説明しています。

いずれも通常のP0（緊急障害、普遍的データ損失、重大な権限侵害）を示す証拠はありません。**技術的重大度とEpic契約上の必須性を別軸**で評価しています。F001/F002は技術的にはMEDIUMですが、Epic完了宣言にはMUST-FIXです。

## 2. Strict GitHub connector検証

connectorでexact ref `refs/heads/codex/epic-00384-provider-test-strategy-planning`を直接取得し、full object ID `396dadc78b4dfae043064438035e77ab1ab3aa56`を得ました。期待値とbyte-for-byte一致した後、`AGENTS.md`、commit、tree、filesを同SHAで取得しました。default branchや別branchを監査対象の代用にしていません。

| 項目 | 結果 |
|---|---|
| repository | chemitaro/spec-dock |
| target ref | refs/heads/codex/epic-00384-provider-test-strategy-planning |
| expected SHA | 396dadc78b4dfae043064438035e77ab1ab3aa56 |
| observed SHA | 396dadc78b4dfae043064438035e77ab1ab3aa56（完全一致） |
| target tree | 43f2b942a8ff211e7558e1d40a0e6203b45127e7 |
| repository instructions | exact SHAの`AGENTS.md`を作業開始時に確認 |
| fallback | 未使用 |

main/PRは監査対象の代用ではなく、ユーザー提示のmerge関係を確認する比較対象です。connector compareではmain merge treeとstrict target treeが同一で、file差分はありません。

## 3. 証拠の区分

| 区分 | 内容 | 扱い |
|---|---|---|
| connectorで確認済み | exact ref/SHA/tree、source、tests、docs、PR changed paths、check metadata | 主要判断の根拠 |
| Codex側限定検証（ユーザー提供） | 同一clean HEADで `uv run pytest tests/unit/infra/test_directory_installation.py -q`: 11 passed in 0.96s, exit 0 | 限定11 nodeの外部実行証拠。ChatGPT自身の実行ではない |
| GitHub履歴 | 同一treeのPR headでprovider-testsとLinux/macOS基本job成功。strict SHAではcheck/validate成功 | 履歴証拠。個別nodeや本監査の再実行とはしない |
| 未実行 | full `uv run pytest`、`make lint`、wheel/sdist build、platform再実行 | 合格と扱わない |
| 静的網羅性 | exact test tree、focused node AST/line inventory、call graph | 動的成功とは区別 |

## 4. 正本と保持・撤退の境界

現行authorityはEpic `requirement.md`、`design.md`、`plan.md`、`artifacts/20260919t021920z-adr-directory-replacement-reconstruction.md`です。旧Wire、#392/#395 R/D/P、qualification、failure registerはHistoricalであり、古い保証をcurrent義務へ戻しません。

### 4.1 撤退するもの

- provider digest / slot marker / generation witness
- repository全体へ付加したprovider専用shared lease
- hooks/fsmonitor/sparse/attributes等を一括判定するprovider full-tree capability gate
- `runtime-generation-drift`による世代再認証
- journal/manifest/legacy exact migration/rollback/resume/performance ledger/sharder
- 上記だけを守るtest node、fixture例外、旧名称

### 4.2 残すもの

- installerのsource/target preflight、fixed 6-directory boundary、data preservation
- Git clean check、明示/fixed commit/ref、post-checkout HEAD確認
- worktree targetのno-follow、EX lock、device/inode binding、別inode誤削除防止
- target-bound materialization、safe symlink/submodule policy、entrypoint-last publication
- consumer hookのbound cwdとdevice/inode確認
- node create/import等のdata-operation lockとrace revalidation
- current package/dogfood/CI catalogのtest

構造上FDやflockを使うという理由だけで一括削除していません。**provider世代を認証する責務か、操作対象を安全に固定する一般責務か**で分類しています。

## 5. 旧方式・新方式・対象SHAの実態

```text
旧provider方式（撤退対象）
  generation/candidate認証
    ├─ repository shared lease + inherited FD
    ├─ full-tree capability scan
    ├─ PinnedCheckout / runtime-generation-drift
    └─ marker/journal/ledger/history

現行authority
  external installer
    ├─ 6 source/target preflight
    ├─ directory単位 rmtree → copytree（順次・非transactional）
    ├─ 全copy成功後だけversion write
    └─ failure: data保持、原因解消後に外部installerを最初から再実行

残す一般安全性
  Git clean + fixed ref
  worktree target no-follow / EX / inode
  consumer hook bound cwd
  create/import data-operation lock
```

## 6. R1〜R10適合

| ID | 判定 | 監査結果 |
|---|---|---|
| R1 | PASS | 6固定directoryの定義・交換と完全一致testがある。 |
| R2 | PASS（限定動的証拠あり） | 対象外data保持。Codex限定11testにもdata sentinelが含まれる。full suiteは未実行。 |
| R3 | PASS | fresh initとforce/update境界が実装・testにある。 |
| R4 | PASS（installer core） | 旧marker/version gateなしで順次交換。 |
| R5 | PASS | versionは全copy loop後。hard-link外部data保護testあり。 |
| R6 | PASS | dry-run/apply、6directory+versionのみ、remove-specs拒否。 |
| R7 | PASS（静的 + 限定test） | source不足、overlap、symlink/非directoryをpreflight。 |
| R8 | PARTIAL | 非transactional設計は一致するが、中間copy failureの動的証拠不足とREADME旧保証がある。 |
| R9 | FAIL | provider generation/shared lease/full-tree gateがactive call graphに残る。 |
| R10 | PASS | workflow seedなし、consumer workflow保持、current CIは直接pytest/lint。 |

## 7. Findings一覧

| ID | 技術的重大度 | Epic上の扱い | 確度 | 要旨 |
|---|---|---|---|---|
| E384-F001 | MEDIUM | MUST-FIX | 確定 | provider世代認証・repository共有lease・full-tree capability gateが通常経路に残る |
| E384-F002 | MEDIUM | MUST-FIX | 確定 | shipped READMEが廃止済みdescriptor/source-resume保証をcurrentとして記載する |
| E384-F003 | LOW | MUST-FIX | 確定 | marker固有のtest例外・absence-only assertionが旧契約を残す |
| E384-F004 | LOW | MUST-FIX | 確定（coverage gap） | update中間copy失敗後の混在状態と再実行復旧の動的証拠が不足する |
| E384-F005 | LOW | MUST-FIX | 確定 | Epic Plan/Reportがmerge後のcurrent authority/statusと不整合 |
| E384-F006 | LOW | OPTIONAL | 確定 | 両conftestに到達しない旧prefix/special branchが残る |
| E384-F007 | LOW | SHOULD-FIX | 確定 | T01/T04/T10/T11/S40B/S45/ProviderLifecycle名称が現行責務を誤表示 |
| E384-F008 | LOW | SHOULD-FIX | 確定 | READMEの管理対象説明が6directoryを正確に列挙しない |
| E384-F009 | LOW | OPTIONAL | 確定 | harnessのretired role skill名列挙がcurrent exact catalogと重複 |

重要度の意味:

- **技術的重大度**: 現時点で確認できる障害・安全性・運用影響。
- **Epic上の扱い**: 現行R/D/P/ADRに照らし完了宣言前に直す必要があるか。
- 本監査で**CRITICAL/P0は0件**です。

## 8. Findings詳細

### E384-F001 — provider世代認証・repository共有lease・full-tree capability gateが通常経路に残る

- 技術的重大度: **MEDIUM**
- Epic上の扱い: **MUST-FIX**
- 確度: **確定**
- path / symbol: `infra/git_cli.py::_run_git_write`, `assess_capabilities`, `pinned_checkout`, `verify_pinned_checkout`; `infra/git_helper.py`; `application/set_active.py`; `application/issue_lifecycle.py`; `application/worktree.py`; contracts/ports/bootstrap adapters
- 到達経路: `issue start` → `checkout_active_target` → `pinned_checkout` → `assess_capabilities` → `_run_git_write` → `git_helper`。worktree create/removeもsource/root共有lockとFD helperへ到達。
- 現行契約: Requirement R9、撤去対象一覧、Design「provider状態認証と共有leaseを削除。clean check、固定ref、安全なworktree対象判定は維持」。
- 証拠: `_run_git_write`はroot FDへ`LOCK_SH|LOCK_NB`を取りdevice/inode付きでhelperへ継承する。`assess_capabilities`はhooks/fsmonitor/sparse/attributes/submodule/他worktreeを一括gateする。issue startはcheckout後にもgeneration witnessを再検証する。
- 影響: 確認済みのデータ損失・権限侵害ではないためP0ではない。ただし通常commandを不要に拒否し、Epicの主要撤去契約と実行コスト削減を阻害する。
- 最小修正 / 撤退案: ordinary issue checkout用Git実行と、target-bound worktree実行を分離する。自動repository-root shared lease、provider full-tree gate、generation witness/global stateを撤去する。worktree target FD/EX/inode、fixed commit、clean check、consumer hookは保持する。
- 確認方法: active sourceで`GitCapabilityAssessment|runtime-generation-drift|lease-retaining`がprovider generation用途0件。issue start new/existing/fixed HEAD、dirty拒否、worktree target safety/consumer hookがGREEN。full pytest/lint/platformは別途実行。

### E384-F002 — shipped READMEが廃止済みdescriptor/source-resume保証をcurrentとして記載する

- 技術的重大度: **MEDIUM**
- Epic上の扱い: **MUST-FIX**
- 確度: **確定**
- path / symbol: `src/spec_dock/assets/spec_dock/docs/README.md:104-105` とdogfood mirror
- 到達経路: wheel/sdist → installerの`spec-dock/docs`コピー → consumerへ配布。
- 現行契約: R8は非transactional・外部installer再実行、R9はprovider認証/共有lease廃止。
- 証拠: 同READMEは直前に単純交換を説明しながら、immediate-child evidence、full descriptor binding、durable semantic digest、compatible newer package resume、semantic drift write-0を主張する。
- 影響: 利用者が存在しない復旧/認証保証を期待する運用リスク。コード障害そのものではないがcurrent shipped contractの誤表示。
- 最小修正 / 撤退案: 104-105行を削除し、6directory順次交換、混在許容、command停止、外部installer再実行、data不変だけへ統一。provider修正後dogfood同期。
- 確認方法: provider/dogfood docs byte equalityと、current shipped surfaceで旧保証語0件を確認。historical artifactは除外。

### E384-F003 — marker固有のtest例外・absence-only assertionが旧契約を残す

- 技術的重大度: **LOW**
- Epic上の扱い: **MUST-FIX**
- 確度: **確定**
- path / symbol: `test_init_update.py:52-62::_managed_tree_bytes`; `test_directory_installation.py:21`;関連test名
- 到達経路: 通常pytestのdogfood/tree parityとruntime smoke。
- 現行契約: 受入1/5は6directory完全一致と旧consumer不在。単一marker名の恒久例外ではない。
- 証拠: parity helperが`.spec-dock-provider-slot.json`だけを除外し、runtime smokeが同markerの不存在を別assertする。完全catalog testは既に全未知fileを検知する。
- 影響: 機能障害ではないが、旧marker再混入を一部parityから隠し、旧テストを維持する。
- 最小修正 / 撤退案: helperのmarker特例と単独assertを削除。全6tree/current catalog equalityを残す。`test_fresh_init_copies_skill_directories_without_markers`は実際には完全inventory testなのでKEEPし改名。
- 確認方法: markerを一時注入すると完全catalog/parity testが失敗し、marker名専用testなしでも検知できる。

### E384-F004 — update中間copy失敗後の混在状態と再実行復旧の動的証拠が不足する

- 技術的重大度: **LOW**
- Epic上の扱い: **MUST-FIX**
- 確度: **確定（coverage gap）**
- path / symbol: `tests/unit/infra/test_directory_installation.py:37-55`
- 到達経路: installer `_copy`を最初の呼出しで常に失敗させる。
- 現行契約: R8/受入3は途中copy失敗を非zeroにし、同じupdate再実行で6directory正常配置へ戻す。atomic rollbackは要求しない。
- 証拠: 現testは先行directoryが既に置換された後のfailureを注入しない。
- 影響: 実装bugは確認していない。受入証拠の空白であり、後半失敗時のversion/data/混在境界が未観測。
- 最小修正 / 撤退案: 後半copyでfailureを注入し、非zero、data不変、version未更新、混在を許容、再実行後6tree一致を確認。2/4/6は監査の代表提案で、承認済み要件ではない。全6parameterizeまたは同等の境界coverageでもよい。
- 確認方法: 追加focused test、続いてfull suite/lint/platform。

### E384-F005 — Epic Plan/Reportがmerge後のcurrent authority/statusと不整合

- 技術的重大度: **LOW**
- Epic上の扱い: **MUST-FIX**
- 確度: **確定**
- path / symbol: Epic `plan.md:16-18`; `report.md:1-80`ほか
- 到達経路: 通常のEpic read surface。
- 現行契約: 2026-09-19 R/D/P/ADRがcurrent authorityであり、PR #404はmainへmerge済み。
- 証拠: PlanはU1/U2を統合検証中、U3を未実施とする。Reportは`parent-planning`で、product source未変更、shared coordination/qualificationをcurrent narrativeとして提示する。
- 影響: コード障害ではないが、次のagentが歴史保証をcurrent義務へ戻す可能性がある。
- 最小修正 / 撤退案: Planを実績/残課題へ更新。Report冒頭をcurrent outcomeへ書換え、旧chronologyを明示的Historical appendixへ降格。
- 確認方法: current R/D/P/ADR/Report間でauthority、merge状態、残課題が一致。

### E384-F006 — 両conftestに到達しない旧prefix/special branchが残る

- 技術的重大度: **LOW**
- Epic上の扱い: **OPTIONAL**
- 確度: **確定**
- path / symbol: `tests/unit/infra/conftest.py:12-17`; `tests/cli_runtime/conftest.py:44-59`
- 到達経路: autouse setup cache。
- 現行契約: test setup cost削減は維持可能だが、dead classificationは不要。
- 証拠: unit infra側は`test_recognized_reconciliation_`、`test_uninstall_`、`test_update_`の3 prefixが現行巨大testに不存在。CLI runtime側もdistribution_cutoverの8 node名にupdate/uninstall/recognizedがなくspecial branchは発火しない。
- 影響: 機能影響はない。理解コストと将来の誤分類リスク。
- 最小修正 / 撤退案: dead prefix/special branchを削除。残りは明示allowlist化を検討。
- 確認方法: collect-only node一覧とfixture activation trace。

### E384-F007 — T01/T04/T10/T11/S40B/S45/ProviderLifecycle名称が現行責務を誤表示

- 技術的重大度: **LOW**
- Epic上の扱い: **SHOULD-FIX**
- 確度: **確定**
- path / symbol: generation checkout、runtime handoff、distribution cutover、worktree lifecycle tests
- 到達経路: test names、class names、failure output。
- 現行契約: 旧Wire/qualificationはHistorical。残す一般機能はcurrent責務名で表現する。
- 証拠: 保持対象のconsumer hook/worktree safety/current catalogにも旧番号・ProviderLifecycle名が残る。
- 影響: 動作影響はないが、削除判断とowner境界を誤らせる。
- 最小修正 / 撤退案: behavior変更なしで現行責務名へ改名。
- 確認方法: old labelsがcurrent test node名から消え、CSVのKEEP/DELETE境界と一致。

### E384-F008 — READMEの管理対象説明が6directoryを正確に列挙しない

- 技術的重大度: **LOW**
- Epic上の扱い: **SHOULD-FIX**
- 確度: **確定**
- path / symbol: root `README.md` usage comment; `src/.../scripts/README.md:64`とdogfood mirror
- 到達経路: onboarding/current shipped docs。
- 現行契約: R1の4 spec-dock dirs + 2 skill dirs。
- 証拠: root READMEはdocs/templates/scripts/skills only、scripts READMEは`spec-dock/{docs,templates,scripts}`と書き、systemを落とす。
- 影響: 低い文書誤差だが、管理境界の誤認につながる。
- 最小修正 / 撤退案: 6directoryを明示列挙し、R1/migrationと統一。
- 確認方法: root/provider/dogfood docsの管理対象表が一致。

### E384-F009 — harnessのretired role skill名列挙がcurrent exact catalogと重複

- 技術的重大度: **LOW**
- Epic上の扱い: **OPTIONAL**
- 確度: **確定**
- path / symbol: `tests/cli_runtime/harness.py:37-59,560-576`
- 到達経路: 多くのCLI runtime testsが共通harnessを使用。
- 現行契約: current skill catalogは2件のpositive equalityで定義可能。
- 証拠: 多数の旧role名ごとにabsenceを繰り返すが、install_root exact catalog testがより強い。
- 影響: 旧名称追加時の保守コスト。機能影響なし。
- 最小修正 / 撤退案: positive current set equalityだけを残す。
- 確認方法: current skills 2件のみ、未知extra skill注入でexact catalog testが失敗。

## 9. F001 consumer・撤退/保持対応表

| component | consumer | 撤退する責務 | 残す責務 | 分類 |
|---|---|---|---|---|
| `infra/git_cli.py::_run_git_write` | issue checkout、worktree add/remove/materialize | 自動root `LOCK_SH`、root FD/device/inodeを全Git writeへ付加 | ordinary Gitは直接実行。worktree target-bound FDだけを必要最小限保持 | REWRITE/SPLIT |
| `infra/git_helper.py` | `_run_git_write` subprocess | provider/shared leaseを示す型・引数・文言 | generic target-bound childが必要なら目的を限定して改名。不要なら削除 | REWRITEまたはDELETE |
| `assess_capabilities` | issue start、worktree source pin | hooks/fsmonitor/sparse/attrs/full-treeをprovider generation gate化 | clean check、fixed commit、materializer固有submodule/symlink検査 | DELETE/SPLIT |
| `GitCapabilityAssessment` | ports/bootstrap/application | provider capability gate result type | 個別のoperation safety resultへ縮退、または不要 | DELETE/REWRITE |
| `PinnedCheckout` | set_active→issue_lifecycle | generation witnessと二重再認証 | branch、target SHA、post-checkout HEAD確認という最小結果 | REWRITE |
| `set_active::_LAST_PINNED_CHECKOUT / last_pinned_checkout` | issue start | global generation witness | checkout function内で完結するlocal result | DELETE |
| `issue_lifecycle::issue_start` | 公開`issue start` | checkout後のprovider generation再検証 | deps→clean/fixed checkout→active write→sync順序 | REWRITE |
| `worktree::_pin_worktree_source` | worktree create | broad capability assessment | current HEADのfixed commit化と必要なmaterializer preflight | REWRITE |
| `worktree::_open_source_shared` | worktree create | repository root shared flock | target EX/inode safetyは別関数で保持。source bindingが必要ならlockなしで独立根拠化 | DELETE/REWRITE |
| `add_worktree_pinned/materialize_worktree/publish_worktree_entrypoint` | worktree create | source lease/helper coupling | fixed commit、target-bound cwd、safe tree materialization、entrypoint-last | KEEP/REWRITE adapter |
| `ConsumerHookRequest` + wrapper `_consumer_hook` | worktree create後make handoff | なし（provider generationではない） | bound cwd device/inode、best-effort result | KEEP |
| `create_node`/`import_node` create.lock | node/data mutation | なし（data-operation lock） | race revalidation、ownership、doctor guidance | KEEP |

この表の要点は、`git_helper.py`やFD継承を機械的に全削除することではありません。ordinary issue checkoutへ自動付加されたrepository shared leaseは撤去対象ですが、worktree targetを同じinodeへ固定するためのtarget-bound実行が必要なら、generic helperへ縮退して残せます。これは新しい仕様判断ではなく、現行Designの「safe worktree targetを維持」の実装選択です。

## 10. focused test node監査

exact sourceから**100件のfocused test case（ASTと明示parametrizeから静的展開）**を個別行として`test-inventory.csv`へ記録しました。内訳はKEEP 88、REWRITE 9、DELETE 3です。`test_init_update.py`は57 function / 58 case（`init`/`update` parameterを展開）を省略なしで棚卸ししています。

### 10.1 fixed-directory installer

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/unit/infra/test_directory_installation.py::test_update_replaces_whole_directories_and_preserves_data | 8 | — | KEEP | R1/R2/R5 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_installed_runtime_starts_without_provider_markers | 21 | — | REWRITE | runtime smoke + current catalog | `test_installed_runtime_starts_from_current_catalog`等へ改名し、line 34のmarker固有assertを削除する。 |
| tests/unit/infra/test_directory_installation.py::test_failed_copy_can_be_retried_without_touching_data | 37 | — | REWRITE | R8/受入3 | 後半copy失敗を追加し、非zero、data不変、version未更新、再実行後6tree一致を検証する。2/4/6は監査提案であり承認済み要件ではない。 |
| tests/unit/infra/test_directory_installation.py::test_uninstall_dry_run_then_removes_only_tool_directories | 58 | — | KEEP | R6 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_symlink_parent_is_rejected_before_any_replacement | 71 | — | KEEP | R7 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_force_init_replaces_tools_without_reseeding_settings | 88 | — | KEEP | R3/R10 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_all_six_directories_match_package_and_discard_old_files | 98 | — | KEEP | 受入1 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_missing_source_is_rejected_before_deleting_anything | 126 | — | KEEP | R7 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_version_hard_link_does_not_modify_external_data | 139 | — | KEEP | R2/R5 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_fresh_install_rejects_copy_into_its_scaffold_source | 153 | — | KEEP | R7 | 維持。 |
| tests/unit/infra/test_directory_installation.py::test_failed_fresh_init_is_retried_after_preserving_partial_scaffold | 178 | — | KEEP | R8 fresh-init | 維持。 |

### 10.2 provider generation / checkout

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_t10_existing_and_new_checkout_are_pinned_and_generation_safe | 13 | — | REWRITE | issue startのnew/existing branch、clean tree、fixed HEAD | `test_issue_start_existing_and_new_checkout_use_fixed_head_and_clean_tree`へ再構成し、provider capability拒否部分を削る。 |
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_existing_branch_can_use_different_tooling_version | 54 | — | KEEP | provider generation差異をcheckout阻害条件にしない | class名を`TestCheckoutSafety`等へ改名する。 |
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_t10_effective_diff_and_merge_attributes_are_rejected_before_mutation[diff=custom] | 83 | diff=custom | DELETE | 現行authorityにGit diff attribute拒否契約なし | 削除。一般worktree materializerはGit blobを直接materializeする現行試験で守る。 |
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_t10_effective_diff_and_merge_attributes_are_rejected_before_mutation[merge=custom] | 83 | merge=custom | DELETE | 現行authorityにGit merge attribute拒否契約なし | 削除。 |
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_capability_guard_covers_the_materialized_tree | 123 | — | REWRITE | worktree materializerのsubmodule/unsafe tree拒否 | `test_worktree_materializer_rejects_submodule_before_publication`としてworktree領域へ移し、issue startには適用しない。 |
| tests/cli_runtime/test_generation_checkout.py::TestGenerationCheckout::test_t10_sparse_checkout_effective_values_and_skip_worktree_are_rejected | 160 | — | DELETE | 現行authorityにsparse checkout一律拒否契約なし | 削除。 |

### 10.3 runtime handoff

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/cli_runtime/test_runtime_handoff.py::TestProviderLifecycleHandoff::test_t11_consumer_hook_parent_io_failure_is_detection_failure_with_exit_zero | 37 | — | KEEP | consumer hookのbest-effort result contract | class/functionからProviderLifecycle/T11を外す。 |
| tests/cli_runtime/test_runtime_handoff.py::TestProviderLifecycleHandoff::test_t11_consumer_hook_binding_mismatch_is_detection_failure_with_exit_zero | 80 | — | KEEP | consumer hook bound cwd device/inode safety | class/functionからProviderLifecycle/T11を外す。 |
| tests/cli_runtime/test_runtime_handoff.py::TestProviderLifecycleHandoff::test_t04_terminal_handoff_preserves_symlink_target_for_external_admission | 117 | — | KEEP | runtime update/uninstallからexternal installerへのtarget/exit handoff | `external_installer_handoff`へ改名する。 |
| tests/cli_runtime/test_runtime_handoff.py::TestProviderLifecycleHandoff::test_t01_relative_lifecycle_targets_use_invoking_cwd_and_preserve_symlink_text | 152 | — | KEEP | relative target resolutionとinvoking cwd | `lifecycle`/T01を外して改名する。 |
| tests/cli_runtime/test_runtime_handoff.py::TestProviderLifecycleHandoff::test_t04_git_write_helper_cannot_be_shadowed_by_consumer_module | 193 | — | REWRITE | target-bound Git childを残す場合のmodule provenance | generic helperへ書換える。helperを全廃する実装なら削除する。owner判断ではなく実装形態に従う。 |

### 10.4 worktree lifecycle coordination

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/cli_runtime/test_worktree_lifecycle_coordination.py::TestWorktreeLifecycleCoordination::test_t11_worktree_b_create_remove_and_make_handoff_are_inode_bound | 18 | — | KEEP | worktree target inode、entrypoint publication、consumer handoff | 挙動を維持し、T11/旧Wire由来の名称だけを整理する。cross-filesystem対応を新たに決定しない。 |
| tests/cli_runtime/test_worktree_lifecycle_coordination.py::TestWorktreeLifecycleCoordination::test_t11_cross_filesystem_worktree_admission_is_rejected_before_git_mutation | 84 | — | KEEP | current same-filesystem admissionによるpre-mutation safety | 挙動を維持し、T11/旧Wire由来の名称だけを整理する。cross-filesystem対応を新たに決定しない。 |
| tests/cli_runtime/test_worktree_lifecycle_coordination.py::TestWorktreeLifecycleCoordination::test_t11_original_worktree_inode_is_preserved_when_git_leaves_it | 102 | — | KEEP | 別inode/残存directory誤削除防止 | 挙動を維持し、T11/旧Wire由来の名称だけを整理する。cross-filesystem対応を新たに決定しない。 |
| tests/cli_runtime/test_worktree_lifecycle_coordination.py::TestWorktreeLifecycleCoordination::test_t11_worktree_remove_reports_busy_target_before_git_mutation | 160 | — | KEEP | worktree data-operation EX lockとbusy拒否 | 挙動を維持し、T11/旧Wire由来の名称だけを整理する。cross-filesystem対応を新たに決定しない。 |

### 10.5 worktree legacy-overlap nodes

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/cli_runtime/test_worktree.py::TestCliWorktree::test_nonlocking_hook_fd_rejects_replacement_of_locked_worktree | 93 | — | KEEP | consumer hook target binding | 維持。 |
| tests/cli_runtime/test_worktree.py::TestCliWorktree::test_materializer_rejects_foreign_existing_descendant_directory | 473 | — | KEEP | worktree target boundary | 維持。 |
| tests/cli_runtime/test_worktree.py::TestCliWorktree::test_materialize_worktree_passes_source_lease_to_read_tree_helper | 721 | — | REWRITE | fixed commit + target-bound materialization | `read-tree`がpinned commitをtarget-bound cwdで実行し、source shared flockを要求しないことへ書換える。 |

### 10.6 distribution cutover

| Node | 行 | case | 分類 | 現行契約 | 処置 |
|---|---|---|---|---|---|
| tests/cli_runtime/test_distribution_cutover.py::test_s40b_provider_install_root_is_current_catalog_only | 55 | — | KEEP | current install_root exact catalog | 名称からS40Bを外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_s40b_retained_skill_identity_matches_current_provider_and_dogfood | 61 | — | KEEP | 2 retained skills provider/dogfood parity | 名称からS40Bを外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_s40b_only_runtime_wrapper_is_executable_across_current_surfaces | 71 | — | KEEP | executable mode contract | 名称からS40Bを外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_fresh_init_copies_skill_directories_without_markers | 93 | — | KEEP | fresh init current external inventory exact equality | `test_fresh_init_copies_exact_current_external_catalog`へ改名する。 |
| tests/cli_runtime/test_distribution_cutover.py::test_s45_fresh_preserves_unrelated_and_obsolete_looking_external_paths | 103 | — | KEEP | R2/R10 external data preservation | 名称からS45を外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_s45_existing_consumer_seed_is_preserved | 127 | — | KEEP | R10 existing consumer workflow preservation | 名称からS45を外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_s45_foreign_fixed_root_is_preserved_and_blocks_fresh_install | 138 | — | KEEP | R3/R7 foreign fixed root fail-before-write | 名称からS45を外す。 |
| tests/cli_runtime/test_distribution_cutover.py::test_init_replaces_the_fixed_skill_directory | 150 | — | KEEP | R1 fixed skill replacement | 維持。 |

`test_fresh_init_copies_skill_directories_without_markers`は、名前にmarkerを含むものの、実際には`.agents/.github`のcurrent inventory完全一致を検査します。したがってDELETEではなくKEEP+RENAMEです。これに対して`test_installed_runtime_starts_without_provider_markers`の単一marker assertは、runtime smokeから分離して削除できます。

### 10.7 巨大`test_init_update.py`

全58 caseのpath/class/function/line/parameter/dispositionは`test-inventory.csv`と`evidence-inventory.md`に省略なしで記載しています。直接修正対象は次です。

- line 52-62 helper `_managed_tree_bytes`: marker特例を削除。
- line 84 node: old skill単独absence assertionを削除しdata preservationを残す。
- line 1449 node: `provider_lifecycle` fixture名だけを一般stale moduleへ変更。
- line 1917 node: data-operation lock testをcurrent責務名へ改名。
- line 5275 CI node: **KEEP**。current `uv run pytest`/`make lint`を正に確認し、独自evaluator/ledger非採用をCI architecture boundaryで守る。

その他はpackage parity、dogfood parity、create/import data lock、Artifact/Workbench、deps/sync/validate等の一般機能でありKEEPです。

## 11. negative assertionの一貫した判断基準

| 例 | 判定 | 基準 |
|---|---|---|
| CI: direct pytest/lint + full-regression evaluator/ledger absence | KEEP | current executable CI commandを正に確認し、別の完全tree equalityでは検知できないarchitecture再導入を防ぐ。 |
| current install_root exact catalog | KEEP | positive allowlist equalityでextra/missingを同時に検知。 |
| fresh external catalog test（名前にwithout markers） | KEEP+RENAME | 実assertは全inventory equalityであり単一absence-onlyではない。 |
| runtime smoke中の`.spec-dock-provider-slot.json`単独absence | DELETE/吸収 | 完全catalog testと重複し、retired filename自体を恒久contract化する。 |
| harnessの旧role skill名20件超のabsence loop | DELETE | current exact skill set equalityより弱く、旧名称追加の保守コストだけを残す。 |
| public artifact routesのhistorical command absence | KEEP | finite public CLI catalogの一部で、positive current catalogと対になったinterface contract。 |

件数や「absence」という形だけで判断していません。**現在のどの契約を独立に守るか、より強い代替testがあるか**で分類しています。

## 12. 全repository test treeの網羅性

connectorでexact targetの`tests` treeを再帰取得し、次の全領域を母集団にしました。

- `tests/cli_runtime/**`
- `tests/integration/**`
- `tests/unit/application/**`
- `tests/unit/cli/**`
- `tests/unit/commands/**`
- `tests/unit/domain/**`
- `tests/unit/infra/**`
- `tests/unit/presentation/**`
- root discovery/static-analysis tests
- fixturesはtest nodeではなくsupport dataとして分離

Epic直結または旧機構と構造が重なるfocused filesはnode単位で展開しました。その他はfile group単位でKEEPとし、理由を`test-inventory.csv`へ記録しています。これは「無関係だから未調査」ではなく、exact tree/PR changed paths/call graphを確認したうえで、旧provider generation consumerへ到達しない一般機能群として分類したものです。

current treeから既に削除済みの`test_managed_distribution.py`、`test_full_regression_baseline.py`、`test_provider_test_lanes.py`、旧root `tests/conftest.py`はHISTORICALです。旧artifactの言及を根拠に再導入しません。

## 13. 欠落test

必須追加は中間copy failureのsuccessorです。最小assertは以下です。

1. first copyではなく、少なくとも先行directoryが置換済みの位置でI/O failureを注入。
2. commandは非zero。
3. 6directory外のdataは不変。
4. versionは新しい値へadvanceしない。
5. 新旧混在は許容し、rollbackを要求しない。
6. 同じupdate再実行後、6directoryがsourceと完全一致。

失敗位置2/4/6は代表的なaudit案であり、正本に書かれた必須数値ではありません。全6位置parameterizationまたは同等の境界coverageも適合します。

## 14. 必須修正と任意改善

### 14.1 Epic完了前の必須修正

1. F001: provider generation/shared repo lease/full-tree gateを一般安全機能から分離して撤退。
2. F002: shipped README 104-105の旧保証を削除しdogfood同期。
3. F003: marker特例/単独absence assertionを完全catalog testへ吸収。
4. F004: mid-copy failure→rerunの動的test追加。
5. F005: Plan/Reportのcurrent status/authority更新。

### 14.2 推奨改善

- F007: 旧Txx/Sxx/ProviderLifecycle名称の改名。
- F008: README管理対象を6directoryへ統一。

### 14.3 任意改善

- F006: dead fixture branch削除。
- F009: harness旧role名列挙削除。

この区分は要約とfindingsで統一しています。dead fixtureや命名はEpicの主要動作を阻害しないためMUST-FIXへ格上げしていません。

## 15. 優先順の後続作業

1. F001のcall graphを縮退し、consumer/types/ports/adapters/testsを同一changeで整理。
2. F002/F003/F005のdocs/tests authority cleanupを同じcandidateへ統合。
3. F004 testをFirst Redとして追加し、最小実装変更が不要ならそのままGreenを記録。
4. focused tests → full `uv run pytest` → `make lint` → wheel/sdist smoke → Linux/macOS basic jobs。
5. provider/dogfood 6tree parity、old active-term scan、exact clean SHAを記録。
6. 独立再監査でPARTIAL解除を判断。

## 16. 完了条件

次をすべて満たしたexact SHAでのみPASSへ更新できます。

- F001/F002/F003/F004/F005が解消。
- fixed ref、worktree target safety、consumer hook、data-operation locksのsuccessor testsが残る。
- current source/docs/testsからprovider generation/shared leaseの到達可能consumerが消える。
- full pytest/lint/package/platform結果が取得される。
- Plan/Reportがcurrent outcomeと残課題を正確に示す。

## 17. 未確認・制約

- ChatGPTはpytest、lint、package build、platform jobを再実行していません。
- Codex提供の11 passedは限定fileのみで、full suite合格ではありません。
- connectorのtree/source静的網羅性と、runtime動的成功を混同していません。
- cross-filesystem worktree supportを新たに採用/廃止する判断はしていません。現行のpre-mutation rejection testをKEEPとし、将来変更は別仕様とします。
- target branch以外を監査対象の代用にはしていません。
