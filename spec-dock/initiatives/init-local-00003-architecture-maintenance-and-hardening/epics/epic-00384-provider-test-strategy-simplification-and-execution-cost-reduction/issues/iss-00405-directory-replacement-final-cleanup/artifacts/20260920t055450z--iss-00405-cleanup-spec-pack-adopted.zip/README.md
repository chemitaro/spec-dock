# Issue #405 採用済み仕様パック

repository: chemitaro/spec-dock
branch: iss-00405-directory-replacement-final-cleanup
著者検証SHA: 457faf31df8840d1f2fc87417d297dc318903fbe

配置先は /Volumes/990p2t/offloaded/home/iwasawayuuta/.codex/worktrees/62d6/spec-dock/spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00405-directory-replacement-final-cleanup です。各ZIP相対pathを同じ相対pathへ配置します。3仕様は完全置換、artifactsは補助資料です。状態はdraftで独立仕様review未実施、実装未着手です。ChatGPT原本からの補正はArtifact名・リンク、Green checkpoint境界、Gitコマンド形式、PlantUML改行構文、CSV改行形式のみです。HTMLは2図の実ブラウザー描画とzoom操作の検証済みです。図の初回描画には固定CDNへのインターネット接続が必要です。

## SHA-256

- `requirement.md`: `b859fc2d50e5c4452acb7e487560a2eccadbe86696fa7d12ab418ce91687a1eb`
- `design.md`: `9a87b8e6cdb35a0e3cbc421423b5a1b1df9d3c6200a51d496e458902aee61c04`
- `plan.md`: `ba48082dd8180646215291ede94e291b9c7a49fdb5640dcde1a3437a2d4d9345`
- `artifacts/cleanup-guide.html`: `34546fa7c1d1c31976bdf33f8229e58ccaf62de38ff8797fbb8c11fd1a5aa4d4`
- `artifacts/20260920t055027z-luna-max-handoff.md`: `0320438934bdfe1c971e0e54130706bee7005070f165ab5797ef829cdc21a310`
- `artifacts/20260920t055027z-01-source-symbol-map.md`: `cbf1f68b1da4ea067651791fe7b3c87982d55949070f71c96bfa1a0573e7e9d0`
- `artifacts/test-disposition.csv`: `743fe9a8a755123844d733c9417b11cc26100ed4a47179a5779eaca9fd467299`
