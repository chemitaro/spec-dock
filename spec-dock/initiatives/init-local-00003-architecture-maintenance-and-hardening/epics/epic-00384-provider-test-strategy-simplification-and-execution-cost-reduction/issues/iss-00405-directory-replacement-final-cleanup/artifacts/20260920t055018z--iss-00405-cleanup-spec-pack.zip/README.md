# iss-00405 Cleanup Specification Pack

## 用途

このpackはIssue #405のcanonical `requirement.md`、`design.md`、`plan.md`を完全置換し、実装担当・review担当・人間読者向け補助を同じ候補として配置するための成果物です。patchではありません。Product実装、Issue Report、review pass、merge resultは含みません。

## Strict source identity

- repository: `chemitaro/spec-dock`
- branch: `iss-00405-directory-replacement-final-cleanup`
- expected / observed full SHA: `457faf31df8840d1f2fc87417d297dc318903fbe`
- tree: `c28295207416e186cd2c1a0c903a84bd7debc6bb`
- Issue metadata: `iss-00405`, GitHub `#405`, parent `epic-00384` / `init-local-00003`
- canonical Issue path: `spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00405-directory-replacement-final-cleanup`
- exact audit artifact Git blob: `252cc71326e58639dbdd35220e391c21dd81854c`
- exact audit artifact SHA-256: `9d7f1813c2d724f0089f0a5ef0197c7a501629e108a96b70647bee52114a90b7`

GitHub connectorでbranch refのfull SHAをbyte-for-byte比較した後、同じcommitだけをsource of truthとして参照しました。前回Epic監査の旧branch/SHAは今回のStrict証明へ使用していません。

## 収録ファイルと配置先

| pack path | adoption target | SHA-256 |
|---|---|---|
| `requirement.md` | `spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00405-directory-replacement-final-cleanup/requirement.md` | `b859fc2d50e5c4452acb7e487560a2eccadbe86696fa7d12ab418ce91687a1eb` |
| `design.md` | `spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00405-directory-replacement-final-cleanup/design.md` | `518e2a21b897dbfaa3d7169226f035be616438f38de7c927fd7b1cab183e4f06` |
| `plan.md` | `spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00405-directory-replacement-final-cleanup/plan.md` | `fc48ae09c9a4e3f921c50f4517e144bb1e1dd248c98e49e0c02b2caf90589023` |
| `artifacts/cleanup-guide.html` | `spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00405-directory-replacement-final-cleanup/artifacts/cleanup-guide.html` | `aab5dccfa61cd4c7bdb8737b724645544516f68b65ef013bb69ec43e2d8766ce` |
| `artifacts/luna-max-handoff.md` | `spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00405-directory-replacement-final-cleanup/artifacts/luna-max-handoff.md` | `1f864eb1386dd061cdb7a790d21140aa487aa762575d3ca4dd2ae26da7a9382b` |
| `artifacts/test-disposition.csv` | `spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00405-directory-replacement-final-cleanup/artifacts/test-disposition.csv` | `b4bc0b252648b6fec752c78ab5339fa76653154990f9a60fecf8d69a7fb748a6` |
| `artifacts/source-symbol-map.md` | `spec-dock/initiatives/init-local-00003-architecture-maintenance-and-hardening/epics/epic-00384-provider-test-strategy-simplification-and-execution-cost-reduction/issues/iss-00405-directory-replacement-final-cleanup/artifacts/source-symbol-map.md` | `8cf7389bec9bd1dae3d9f0bd2dce33c8362d0792bdef4c5f5bdf42b6becb0339` |
| `README.md` | `pack root only（canonical adoption対象外）` | `SHA256SUMSに記録` |
| `SHA256SUMS` | `pack root only（checksum index）` | `self-listing対象外` |

`README.md`自身のSHA-256は自己参照を避けるため本文へ埋め込まず、pack rootの`SHA256SUMS`に記録します。`SHA256SUMS`は標準的に自身を列挙しません。

## 採用順序

1. current Issue directoryの`requirement.md`、`design.md`、`plan.md`をpackの同名ファイルで完全置換します。
2. `artifacts/`配下4ファイルを配置します。
3. `README.md`はIssue artifactとして残す必要はありません。採用receiptとして保存する場合は`artifacts/`へ移動してもcanonical R/D/Pを変更しません。
4. `./spec-dock/scripts/spec-dock validate`を実行します。
5. independent specification reviewでblocking findingを解消します。
6. Product実装はcanonical Plan S1から開始します。

## 固定した設計判断

- `git_helper.py`は削除せずtarget-bound cwd executorへ縮退します。
- ordinary checkoutはdirect fixed-ref Gitへ変更します。
- provider repository shared lease、generation witness/global、broad full-tree gate、generation reauthを削除します。
- worktree target no-follow/EX/device-inode、same-filesystem、safe materializer、entrypoint-last、consumer hook bound cwdを保持します。
- create/import locks、artifact source/publication、secret redactionを保持します。
- installerは6directory順次置換のままです。4th-copy failureはtest注入点でありProduct constantではありません。
- F001〜F009を同一cleanup scopeに含め、巨大test module分割やnew Product featureは含めません。

## 検証状態

### ChatGPT側で実施

- strict GitHub branch/SHA comparison
- audit ZIP Git blob/size/local byte identity確認
- source/test/docsの静的call graph・symbol・node照合
- Markdown internal relative linkの存在確認
- CSV parse、ID/node重複確認
- HTML contract v2、PlantUML source数、shared zoom modal数、pinned CDN、`renderToString` callback、diagnostic rejection codeの静的確認
- ZIP生成後のCRC/entry検査

### ChatGPT側で未実行

- Product実装
- pytest/lint/package build
- Ubuntu/macOS CI
- SpecDock validate
- independent spec/code/QA review
- 実ブラウザーでのPlantUML render/SVG diagnostic/zoom validator
- PR作成・merge

### Codex側から提供された限定証拠

```text
uv run pytest tests/unit/infra/test_directory_installation.py -q
11 passed in 0.96s
exit 0
```

これはexact pre-implementation 11 testsだけの証拠です。新しいmid-copy successor、full suite、本Issue完了の証拠ではありません。

## 採用時確認事項

- R/D/P frontmatterのID/親/関連GitHub/stateが維持されていること。
- current repository HEADが意図したspec adoption commitでcleanなこと。
- active Issueが`iss-00405`であること。
- `artifacts/test-disposition.csv`のcurrent nodesがcollect-only結果と一致すること。
- HTML browser validatorをCodex側で実行すること。
- Issue Reportは実装・検証後に実測だけで作成すること。
- agentはmerge-ready PRで停止し、mergeは人間が行うこと。

## 真に未決の判断

現時点でowner判断が必要なProduct/Security事項はありません。tests、review、CIの結果は未決判断ではなく未取得evidenceです。cross-filesystem support、same-EUID adversary保証、atomic installer、new CLI/schemaが必要になった場合のみRequirement/Designへ戻します。
