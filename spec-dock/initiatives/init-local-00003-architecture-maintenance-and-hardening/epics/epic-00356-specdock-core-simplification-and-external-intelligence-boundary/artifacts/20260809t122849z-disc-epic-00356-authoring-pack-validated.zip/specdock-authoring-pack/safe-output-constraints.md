---
authority: evidence_only
adoption_status: unreviewed
bundle_generation_not_promotion: true
title: "Safe Output Constraints"
source_repository: "chemitaro/spec-dock"
source_branch: "main"
source_sha: "2c75e0c02cb65a6e74040a72dc161d342d661091"
generated_on: "2026-08-09"
---

# Safe Output Constraints

## 1. Archive contract

- The only deliverable archive is a ZIP whose root is `specdock-authoring-pack/`.
- Every archive member is a regular UTF-8 text file with mode `0644`.
- No nested archive, binary payload, executable bit, symlink, device, FIFO, hidden archive member, absolute archive path, or `..` path segment is permitted.
- Allowed file suffixes are `.json` and `.md`.
- This validator-compatible pack intentionally contains no HTML; the human-facing HTML remains in the earlier presentation bundle.
- `manifest.json` lists every member. Its own cryptographic digest is null because self-hashing is not stable.

## 2. Content exclusions

- No verbatim interaction log.
- No external interaction locator.
- No ephemeral interaction identifier or connector response identifier.
- No local absolute path.
- No sensitive value, authentication material, access token, asymmetric signing material, or environment dump.
- Repository source paths may be named as evidence inventory; those names do not create hidden archive members.

## 3. Authority and status

- `authority=evidence_only`
- `adoption_status=unreviewed`
- `bundle_generation_not_promotion=true`
- Issue drafts are non-authoritative evidence.
- Source-recorded Product Owner decisions remain marked adopted, while every generated reflection remains unreviewed.
- This package does not claim promotion into repository authority, a successful review outcome, implementation authorization, change-set submission authorization, merge authorization, Issue finish, or Epic completion.

## 4. Write boundary

- Bundle generation performs no repository write, GitHub Issue mutation, dependency mutation, branch operation, commit, change-set submission, merge, close, or completion transition.
- The proposed final work item has no numeric ID and no GitHub linkage.
- Promotion into repository authority and all execution actions require a separate Human-controlled workflow against a freshly verified source identity.

## 5. Integrity checks

Before delivery, the generator validates:

1. all required paths exist;
2. all JSON parses;
3. all text decodes as UTF-8 and contains no NUL byte;
4. all archive paths remain under the required root and contain no hidden or traversal segment;
5. the Epic design contains one to three PlantUML blocks and currently contains exactly three;
6. validator-sensitive wording is absent;
7. the ZIP member count and manifest entry count agree;
8. manifest sizes and digests match every non-manifest member.
