---
authority: evidence_only
adoption_status: unreviewed
bundle_generation_not_promotion: true
title: "Epic 00356 Vertical Slice Index"
source_repository: "chemitaro/spec-dock"
source_branch: "main"
source_sha: "2c75e0c02cb65a6e74040a72dc161d342d661091"
generated_on: "2026-08-09"
---

> 本書は人間レビュー用の索引であり、promotion into repository authority、successful review outcome、implementation handoff status、change-set submission status、merge decision status、Issue finish、Epic completionを表さない。

# Vertical Slice Index

## 1. Planning result

Epic 00356はhorizontal layer別ではなく、利用者がend-to-endで確認できる5つの縦スライスとして扱う。既存Issue 357–360のID、GitHub linkage、履歴、直接dependency edgeを維持し、追加work itemはnumeric IDを持たないcandidateとして分離する。

| Marker | Work item | User-verifiable outcome | Direct dependency | Parallelism | Primary demonstration |
|---|---|---|---|---|---|
| □ candidate | `iss-00357` / GitHub #357 | Storage Core CLIでnode、deps、active、start／finish、Artifact、file importを薄い契約で安全に操作できる | なし | 358と並行可 | Fresh／historical fixture上のCLI end-to-end |
| □ candidate | `iss-00358` / GitHub #358 | Fresh nodeが一つのR/D/P、薄い常設Report、provider-neutral Guideで作成できる | なし | 357と並行可 | Template scaffold、Guide navigation、historical preservation |
| □ candidate | `iss-00359` / GitHub #359 | `spec-dock`と`spec-dock-grill-with-docs`からCore／Kitを利用でき、hidden workflowを再導入しない | 357、358 | IC-1後 | Skill contract、one-artifact output、no canonical write |
| □ candidate | `iss-00360` / GitHub #360 | Fresh／update／uninstallでTarget distributionへ移行し、既存spec／evidenceを失わない | 357、358、359 | IC-2後 | Consumer matrix、managed prune、recovery |
| △ proposed | `proposed-final-quality-integration-delivery` | 全slice統合後のfull quality、defect-only repair、diff audit、deliverable change-set handoff evidenceを独立に確認できる | 357、358、359、360 | 全implementation後 | Full suite、cross-consumer smoke、change-set handoff package |

`□ candidate`はbundle内draftであり正本ではない。`△ proposed`はnumeric ID／GitHub linkageを持たず、人間採用前はexecution itemではない。

## 2. Dependency and checkpoint sequence

```text
iss-00357 ─┐
           ├─ IC-1 ─> iss-00359 ─> IC-2 ─> iss-00360 ─> IC-3 ─> proposed-final
iss-00358 ─┘
```

- **IC-0:** bundleとsource identityのHuman review。
- **IC-1:** Core／Kit contract。Fresh scaffold、Artifact catalog、Report、help／docs wordingを一致させる。
- **IC-2:** Skill contract。二つのskill、Guide path、removed workflow absenceを一致させる。
- **IC-3:** Distribution contract。Provider、dogfood、fresh install、existing update、uninstallの整合を確認する。
- **IC-4:** Proposed final work item内の独立final exit review。

## 3. Each slice closes the full loop

| Work item | Requirement | Design | Implementation | Test | Docs | Migration／Compatibility |
|---|---|---|---|---|---|---|
| 357 | thin Runtime behavior | Current／Historical separation、failure ordering | parser／registry／lifecycle／artifact／scaffold mechanism | unit、CLI、negative、historical | CLI help、Runtime reference | existing metadata／artifact／report non-rewrite |
| 358 | Authoring contracts | Template／Guide split、level docs-only | provider／dogfood templates and guides | inventory、link、vocabulary、parity、scaffold | authoring overview and navigation | existing R/D/P/Report preserved |
| 359 | two-skill outcome | input／output／failure／authority boundary | provider and dogfood skill assets | contract、negative、link、no-canonical-write | skill usage and external capability notes | legacy skill inventory handoff |
| 360 | consumer cutover | managed ownership and transaction boundary | installer／update／uninstall／prune | fresh／update／uninstall matrix、failure injection | migration、release、recovery | user-owned and historical preservation |
| proposed final | integrated delivery evidence | verification and defect ownership | defect-only changes and PR assembly | full suite and cross-slice smoke | final consistency audit | release rollback／forward recovery evidence |

## 4. Issue draft locations

- `drafts/issues/iss-00357/`
- `drafts/issues/iss-00358/`
- `drafts/issues/iss-00359/`
- `drafts/issues/iss-00360/`
- `drafts/issues/proposed-final-quality-integration-delivery/`

## 5. Preserved identity

| Item | Preserved identity |
|---|---|
| Epic | `epic-00356`, GitHub #356 |
| Runtime slice | `iss-00357`, GitHub #357 |
| Authoring slice | `iss-00358`, GitHub #358 |
| Skill slice | `iss-00359`, GitHub #359 |
| Distribution slice | `iss-00360`, GitHub #360 |
| Proposed final | no numeric ID, no GitHub linkage |

Direct dependencies recorded at the source commit remain: 359 depends on 357 and 358; 360 depends on 357, 358, and 359. The proposed final candidate adds no repository edge in this bundle.
