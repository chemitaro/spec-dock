---
authority: evidence_only
adoption_status: unreviewed
bundle_generation_not_promotion: true
document_status: candidate
document_role: "proposed_issue_requirement_draft"
title: "Proposed Final Quality, Integration, and Deliverable Handoff — Requirement Draft"
target: "proposed-final-quality-integration-delivery"
source_repository: "chemitaro/spec-dock"
source_branch: "main"
source_sha: "2c75e0c02cb65a6e74040a72dc161d342d661091"
generated_on: "2026-08-09"
candidate_id: "proposed-final-quality-integration-delivery"
numeric_issue_id_assigned: false
github_linkage_assigned: false
depends_on:
  - "iss-00357"
  - "iss-00358"
  - "iss-00359"
  - "iss-00360"
---

> この文書は human review 用の evidence-only candidate であり、正本への採用、レビュー合格、実装着手可、PR準備完了、merge可能、Issue終了、Epic完了を表さない。

# 1. Candidate purpose

全 implementation Issue の完了候補を統合した後に、Epic 横断の final quality、integration、defect-only repair、deliverable change-set handoff evidence を独立に閉じる work item 候補である。

この candidate は numeric Issue ID と GitHub linkage を持たない。Human が採用し、正式 Issue を作成するまで execution work item ではない。

# 2. Why this is separate

`iss-00360` は distribution migration という user value を所有する。そこへ全 regression、独立 review、diff audit、PR assembly を埋め込むと:

- distribution defect と cross-slice defect の owner が曖昧になる
- 360 の acceptance が無制限に膨張する
- 357–359 の integration defect が 360 の scope に隠れる
- deliverable change-set handoff の independent evidence がなくなる

Final candidate は feature implementation ではなく、integrated candidate の検証・修復・delivery boundary を所有する。

# 3. Inputs

- exact integrated commits / branch for 357–360
- each Issue Requirement / Design / Plan
- each Issue targeted test / compatibility / handoff evidence
- IC-1 / IC-2 / IC-3 results
- target / obsolete / preserve inventory
- migration docs
- provider / dogfood / installed consumer artifacts
- known residual risks

# 4. Observable value

Human reviewer が次を一つの evidence package で確認できる:

- 357–360 が exact source identity で統合されている
- full test / static / package checks の結果
- Fresh / update / uninstall / historical consumer matrix
- retained Core behavior
- thin Authoring Kit behavior
- two-skill behavior
- removed surface absence
- provider / dogfood / installed parity
- defect-only fixes とその regression tests
- diff / generated / packaging audit
- docs / migration / release consistency
- coherent PR change set / commit structure
- unresolved risks / blockers
- independent review findings and disposition

Evidence が揃ったことをこの draft 自体は主張しない。

# 5. In scope

- integrated source identity freeze
- dependency / handoff validation
- full regression
- static typing / lint / format / package build as repository defines
- cross-slice end-to-end smoke
- consumer matrix
- historical preservation
- removed-surface scan
- link / docs / vocabulary / parity
- security / privacy / path / symlink regression relevant to changed surface
- defect triage and defect-only repairs
- re-run after repairs
- diff / generated / package payload audit
- commit / PR assembly preparation
- independent review evidence
- human handoff

# 6. Out of scope

- new Product feature
- adopted decision reopening
- new workflow / gate / metadata
- unrelated repository cleanup
- numeric ID invention
- canonical apply
- automatic PR submission / merge
- Issue close / Epic completion
- release deployment

# 7. Acceptance criteria

Future criteria:

1. All direct dependencies are represented by exact integrated commits.
2. Targeted evidence from each Issue is present and attributable.
3. Full repository-required checks have recorded outcomes.
4. Package build and isolated install work.
5. Fresh / update / uninstall / mixed / historical matrices have recorded outcomes.
6. Cross-slice smoke verifies Core + Kit + Skills + Distribution.
7. Removed commands、modules、templates、docs entrypoints、skills、provider-specific import have no executable / navigable fallback.
8. Historical R/D/P/Report/Artifact/Discussion/ADR/Assurance fixtures retain expected hashes.
9. Planning Level has no Runtime / metadata implementation.
10. Report content does not gate lifecycle.
11. Defects discovered in final integration have regression tests and minimal fixes.
12. Docs / CLI help / migration / release impact match code.
13. Diff contains no accidental generated payload、binary、secret、verbatim interaction log、external interaction locator、ephemeral interaction identifier、local absolute path、unexpected hidden path。
14. PR change set is coherent and independently reviewed.
15. Any blocker prevents a success claim and is handed to human with exact evidence.

# 8. Exit authority

Only human-controlled repository workflow may decide:

- whether candidate becomes a formal Issue
- whether the independent review outcome is successful
- whether implementation handoff is authorized
- whether a change set is submitted and suitable for a later merge decision
- whether Issues or Epic are closed

This candidate supplies evidence only.
