---
authority: evidence_only
adoption_status: unreviewed
bundle_generation_not_promotion: true
document_status: candidate
document_role: "proposed_issue_design_draft"
title: "Proposed Final Quality, Integration, and Deliverable Handoff — Design Draft"
target: "proposed-final-quality-integration-delivery"
source_repository: "chemitaro/spec-dock"
source_branch: "main"
source_sha: "2c75e0c02cb65a6e74040a72dc161d342d661091"
generated_on: "2026-08-09"
candidate_id: "proposed-final-quality-integration-delivery"
numeric_issue_id_assigned: false
github_linkage_assigned: false
depends_on:
  - "iss-00357"
  - "iss-00358"
  - "iss-00359"
  - "iss-00360"
---

> この文書は human review 用の evidence-only candidate であり、正本への採用、レビュー合格、実装着手可、PR準備完了、merge可能、Issue終了、Epic完了を表さない。

# 1. Verification architecture

```text
Integrated source identity
  -> evidence collector
    -> test / build / consumer matrix
    -> static absence / preservation audits
    -> defect classifier
      -> defect-only repair loop
        -> complete rerun
          -> diff / docs / package audit
            -> change-set handoff evidence
              -> human decision
```

No final status is derived from a single test or Issue report.

# 2. Source identity

Record:

- repository
- branch
- full commit SHA
- integrated dependency SHAs
- dirty / generated state
- package version / build identity
- consumer fixture versions

Any code change during defect repair creates a new reviewed identity and invalidates prior affected results.

# 3. Evidence matrix

| Dimension | Evidence |
|---|---|
| Runtime | retained / removed command inventory、lifecycle / Artifact / import tests |
| Authoring | template / Guide catalog、links、one Plan、thin Report、Current / Historical |
| Skills | two entrypoints、scenario / no-write / external absence tests |
| Distribution | fresh / update / uninstall、parity、preservation、recovery |
| Cross-slice | installed user journeys |
| Quality | full suite、lint/type/format、package build |
| Safety | symlink / path / collision / privacy / payload scan |
| Delivery | diff audit、commit map、review findings、PR description inputs |

# 4. Defect classifier

A final-slice change is allowed only when:

- observed behavior contradicts accepted slice contract
- test / docs / packaging defect blocks integrated exit
- repair is minimal and ownership is recorded
- regression test is added or existing test is strengthened
- feature semantics are not expanded

If the change requires new Product behavior or reopens an adopted decision, stop and return it to human / owning Issue.

# 5. Rerun policy

After a repair:

- rerun directly affected targeted tests
- rerun related slice integration
- rerun full suite before delivery evidence
- rebuild package if package / asset / installer changed
- rerun consumer matrix rows affected
- refresh source identity
- invalidate stale review evidence

# 6. Independent review

Review target is exact integrated diff / commit. Findings are classified by severity and ownership. P0 / P1 block delivery evidence. Lower findings require explicit disposition; they are not silently ignored.

Review must inspect:

- adopted decision regressions
- removed fallback
- data preservation
- partial failure
- docs / behavior mismatch
- package payload
- accidental workflow reintroduction
- test blind spots

This design does not claim a review result.

# 7. change-set handoff evidence

Prepare:

- change summary by vertical slice
- dependency / integration narrative
- test matrix
- migration / compatibility
- rollback / recovery
- removed surfaces
- residual risks
- review findings / fixes
- commit map
- exact source SHA

PR creation / readiness / merge remain external human-controlled actions.

# 8. Failure handling

| Failure | Action |
|---|---|
| dependency SHA mismatch | stop; rebuild exact integration |
| targeted evidence missing | return to owning Issue |
| full suite failure | classify and repair or block |
| consumer data mutation | block; restore fixture; root-cause |
| removed fallback found | block; repair owning surface |
| docs mismatch | repair docs or behavior based on accepted contract |
| package payload violation | block package / PR evidence |
| review P0/P1 | repair and fresh review |
| feature request | defer / new human decision; not final defect repair |
