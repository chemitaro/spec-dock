---
authority: evidence_only
adoption_status: unreviewed
bundle_generation_not_promotion: true
title: "Epic 00356 Responsibility Boundaries"
source_repository: "chemitaro/spec-dock"
source_branch: "main"
source_sha: "2c75e0c02cb65a6e74040a72dc161d342d661091"
generated_on: "2026-08-09"
---

> 本書は責務境界のevidence-only candidateであり、正本または実装状態を表さない。

# Responsibility Boundaries

## 1. Product boundary

| Actor／component | Owns | Must not own |
|---|---|---|
| Human／Operator | intent、canonical adoption、external tool selection、Issue creation、merge decision | hidden Runtime policyへの依存 |
| External Intelligence | analysis、authoring、implementation、review assistance | SpecDock-internal authority、automatic canonical adoption、provider lock-in |
| Storage Core | node identity、hierarchy、GitHub linkage、dependencies、active selection、thin lifecycle、Artifacts、worktree／workbench、sync／validate／doctor、deterministic mutation | Planning／Review／Execution workflow、Assurance／Profile、quality gate、provider-specific import、PR workflow |
| Authoring Kit | R/D/P／thin Report semantics、minimal templates、detailed guides、scope layering、docs-only Planning Level、Artifact meaning | Runtime routing、metadata gate、canonical adoption、review pass判定 |
| Repo-local `spec-dock` skill | context navigation、Core CLI invocation、Guide pointers | orchestration state machine、model choice、quality or completion verdict |
| Repo-local grill skill | explicit clarification、one scope-local evidence Artifact | R/D/P automatic write、multiple hidden outputs、durable authority |
| Local Spec Graph | durable node／docs／evidence／dependency storage | external-provider session state |
| GitHub | linked Issue identity and close state | local spec content／dependency authorityの二重化 |

## 2. Issue ownership matrix

| Surface | 357 | 358 | 359 | 360 | Proposed final |
|---|---|---|---|---|---|
| Runtime parser／registry／commands | **Owner** | no change | consume help | distribute result | integrated verification |
| active／start／finish／dependency semantics | **Owner** | explain only | point only | migration smoke | cross-slice regression |
| Artifact filename／lock／path safety | **Owner** | semantic input | consume | installed smoke | regression |
| Current／Historical Artifact meaning | implement contract | **Owner** | use contract | migrate／preserve | scan |
| R/D/P／Report template body | no body ownership | **Owner** | consume | distribute | consistency audit |
| Planning Level guides | no Runtime interpretation | **Owner** | pointer／read behavior | distribute | link／vocabulary audit |
| Repo-local skills | handoff contract | handoff paths | **Owner** | install／prune | contract verification |
| Installer／update／uninstall | inventory handoff | asset inventory handoff | skill inventory handoff | **Owner** | consumer verification |
| Full regression／PR assembly | targeted evidence | targeted evidence | targeted evidence | targeted evidence | **Owner candidate** |

## 3. Key handoff contracts

### 357 → 358／359／360

- retained CLI command inventory
- removed Runtime command／module／gate inventory
- active manifest target shape
- `active set`／`issue start`／`issue finish` behavior
- six Current Artifact types and Historical recognition behavior
- generic file import contract
- fresh scaffold mechanism and Report non-gating behavior
- Runtime tests and migration risks

### 358 → 359／360

- provider and dogfood Template／Guide tree
- canonical versus evidence versus result-summary meaning
- one Issue `plan.md` and five authoring guide paths
- Artifact catalog and reflection rules
- Current navigation entrypoints
- obsolete template／docs inventory
- existing document preservation contract

### 359 → 360

- exact managed skill set and paths
- input／output／failure contracts
- external capability dependency classification
- no-canonical-write checks
- legacy managed skill removal inventory
- docs pointers and install test expectations

### 360 → Proposed final

- package payload inventories for provider／dogfood／fresh／updated／uninstalled consumers
- migration and recovery evidence
- preserved-content hashes／fixtures
- obsolete surface absence scan
- targeted suite results and residual risks

## 4. Authority boundary

- Artifact is evidence.
- `report.md` is an optional-content result summary with a stable path.
- Requirement／Design／Plan are canonical specification locations only after an explicit canonical workflow adopts them.
- Accepted ADR may hold a durable architecture decision.
- This bundle and its HTML are not canonical authority.
- Runtime `ready` means dependency state only.
- Human review of this bundle is separate from Runtime lifecycle and separate from code delivery.

## 5. Shared-file conflict rule

357 and 358 may proceed in parallel only after IC-0 freezes contract ownership. When both need the same path:

1. 358 owns Template／Guide body semantics.
2. 357 owns Runtime copy／parse／validation mechanism.
3. Shared fixture and help wording are reconciled at IC-1.
4. Neither Issue silently changes the other's owned behavior.
5. Any durable boundary change returns to Epic or Issue R/D/P or an accepted ADR candidate; it is not buried in Report or test code.
