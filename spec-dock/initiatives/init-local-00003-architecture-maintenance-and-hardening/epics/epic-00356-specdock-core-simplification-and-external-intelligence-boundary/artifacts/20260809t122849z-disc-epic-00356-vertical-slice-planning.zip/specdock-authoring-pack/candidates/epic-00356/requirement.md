---
authority: evidence_only
adoption_status: unreviewed
bundle_generation_not_promotion: true
document_status: candidate
document_role: "epic_requirement_candidate"
title: "epic-00356 SpecDock Core Simplification and External Intelligence Boundary — Requirement Candidate"
target: "epic-00356"
source_repository: "chemitaro/spec-dock"
source_branch: "main"
source_sha: "2c75e0c02cb65a6e74040a72dc161d342d661091"
generated_on: "2026-08-09"
---

> この文書は human review 用の evidence-only candidate であり、正本への採用、レビュー合格、実装着手可、PR準備完了、merge可能、Issue終了、Epic完了を表さない。

# 1. 結論

Epic 00356 は、SpecDock を「認知的ワークフローを所有する製品」から、次の二つを提供する小さな基盤へ縮退させる。

1. **Storage Core** — Initiative / Epic / Issue、GitHub linkage、依存 DAG、active selection、薄い Issue lifecycle、scope-local Artifact、Workbench / Worktree、sync / validate / doctor、決定的な構造操作を保持する。
2. **Authoring Kit** — `requirement.md`、`design.md`、`plan.md`、薄い `report.md`、Artifact の意味、scope layering、Issue Planning Level の文書ガイドを提供する。

Planning、Review、Execution、Assurance、Profile routing、provider 固有 import、PR workflow、モデル／ブラウザ／Oracle 固有の判断は SpecDock product boundary の外へ出す。外部 Intelligence は Markdown、Git、CLI、安定した file contract を利用する client であり、Runtime の adapter や authority source にはならない。

# 2. Source-grounded Current

exact source SHA の Current には次が同居している。

- Runtime parser / registry に `assurance`、`authoring`、`guidance`、`workflow`、`delegated-authoring`、provider-specific `artifact import chatgpt-output` が登録されている。
- Issue lifecycle は active entry の authority / grants / promotion record、delegated artifact、`report.md` の Evidence Adoption Ledger を評価する。
- Artifact domain は current creation と historical recognition を一つの集合に混在させ、`pr-repair-batch` と `draft-*` routing を保持する。`draft-design` / `draft-plan` は Assurance Profile に依存する。
- Installer は多数の Planning / Execution / ChatGPT / adapter / PR helper skill を managed inventory として配布する。
- provider docs の入口は skill、phase promotion、fresh reviewer gate、ChatGPT planning pack を正規導線として案内する。
- Epic と Issue 357–360 の ID、GitHub linkage、dependency edge は存在する一方、各 Issue の Requirement は汎用 scaffold、Design / Plan は Assurance compose を要求する placeholder である。
- Existing Report は大規模な workflow ledger であり、採用済みの薄い Report contract と一致しない。
- Current dependency は `357 || 358`、`359 <- 357,358`、`360 <- 357,358,359` である。

この Current 記述は「既に Target が実装済み」という意味ではない。

# 3. Product outcome

Epic 後に利用者が確認できるべき outcome は次である。

- Fresh repository には Storage Core、薄い Authoring Kit、限定された repo-local skill surface だけが配布される。
- Existing repository の node identity、GitHub linkage、canonical documents、Artifact、Discussion、ADR、heavy Report、`.assurance.json`、profile 由来文書を一括削除・rename・rewrite せず update できる。
- CLI help と Runtime registry から removed workflow surface が消え、別名 fallback も存在しない。
- `active set`、`issue start`、`issue finish`、dependency readiness、Artifact creation / import が採用済み semantics どおり動作する。
- Fresh Initiative / Epic / Issue は単一 R/D/P と薄い常設 `report.md` を持ち、Report が空でも valid である。
- Authoring Kit は一つの canonical Issue `plan.md`、共通 Plan Guide、`light` / `standard` / `strict` / `critical` Completion Guide を提供する。Runtime は level を知らない。
- Provider source、dogfood projection、fresh installed consumer、updated existing consumer の contract が検証可能である。
- External Intelligence が存在しなくても Storage Core は利用可能であり、存在する場合も正本を自動採用しない。

# 4. 採用済み判断

以下は再質問・未決化しない。

| ID | 採用済み判断 | Epic への拘束 |
|---|---|---|
| AD-001 | Runtime workflow、Profile、Assurance を削除する | parser、registry、domain、application、tests、docs、managed assets から Current route を除去する |
| AD-002 | Planning Level は docs only。Issue `plan.md` は一つ。共通 Guide と 4 Completion Guideを用意する | level を metadata、Runtime state、gate、routing にしない |
| AD-003 | `issue finish` は GitHub close → close 成功後 active clear → post-sync の薄い便利操作。quality gate は持たない | Review、Plan、Test、Report、EAL、authority を判定しない |
| AD-004 | `active set` は selection only。`issue start` だけが unfinished active guard と dependency ready を確認する。`ready` は dependency only | blocked Issue も planning / research のため選択可能 |
| AD-005 | Artifact type は optional positional、未指定は `blank`。Current は `blank`, `research`, `interview`, `disc`, `decision-candidate`, `adr`。`analysis` は追加しない | current creatable と historical recognizable を分離する |
| AD-006 | Import は file only | provider-specific import command / module / docs / tests を Current surface から外す |
| AD-007 | Fresh node は薄い `report.md` を常設し、空でも valid。Runtime gate にしない。Existing 本文は保持する | Template は結果要約だけ。Runtime は内容を読まない |
| AD-008 | repair badge と draft の Current surface 削除 | legacy evidence は保持するが新規作成・Current navigation は終了する |
| AD-009 | durable decision は Epic / Issue の Requirement、Design、Plan または accepted ADR に置く | Artifact と Report は evidence / result summary であり正本ではない |

# 5. Vertical-slice requirement

既存 Issue を horizontal layer として扱わず、各 Issue が利用者に確認可能な end-to-end value を閉じる。

| Slice | End-to-end value | 同じ Issue 内で閉じるもの |
|---|---|---|
| `iss-00357` | 利用者が薄い Storage Core CLI で node / dependency / active / lifecycle / Artifact を安全に扱える | Runtime code、CLI help、tests、historical compatibility、Runtime migration notes |
| `iss-00358` | 利用者が Fresh node の薄い R/D/P/Report と Authoring Guide だけで仕様作成できる | templates、guides、navigation、artifact semantics、tests、projection、existing-doc preservation |
| `iss-00359` | Agent / operator が二つの repo-local skill から Core と Kit を正しく使える | skill contracts、provider assets、docs、negative behavior、tests、legacy handoff inventory |
| `iss-00360` | Fresh / update / uninstall consumer が legacy workflow を配布されず、既存データを失わない | installer、managed prune、dogfood、migration、compatibility、consumer matrix、docs、tests |
| proposed final candidate | 全 implementation slice を統合し、品質・統合・mergeable PR delivery evidence を一つの独立 work item で閉じる | full regression、cross-consumer smoke、defect-only fixes、diff audit、PR assembly、handoff evidence |

# 6. Scope

## 6.1 In scope

- Epic 00356 と Issue 357–360 の requirement / design / plan 再定義
- Runtime parser / registry / application / domain / infra / presentation の workflow removal
- Active selection、Issue start / finish、dependency semantics
- Artifact current / historical split、optional positional type、generic file import
- Fresh node scaffold と thin Report mechanism
- R/D/P/Report Template、Authoring Guide、Planning Level Completion Guide
- Current / Historical docs navigation
- Repo-local skill boundary
- Provider assets、dogfood projection、installer init / update / uninstall
- Existing consumer preservation
- Unit、integration、CLI、consumer、negative、migration、link、parity tests
- final quality / integration / mergeable PR delivery candidate

## 6.2 Out of scope

- External model、browser、Oracle、provider API の実装・運用
- Product-owned Planning / Review / Execution state machine の代替実装
- Runtime quality gate、reviewer adapter、EAL gate、PR gate
- Historical document / Artifact / Report の一括書換え
- Existing `.assurance.json` の migration 変換
- `analysis` Artifact type
- 複数 canonical Plan file
- arbitrary provider-specific import
- 新しい issue numeric ID の仮付与
- 本 bundle 自体による canonical apply、Issue close、commit、push、PR作成

# 7. Authority and evidence contract

- Canonical specification 候補は Epic / Issue の R/D/P であり、本 bundle はその replacement candidate にすぎない。
- Accepted ADR は長寿命 architecture decision の置き場である。
- Artifact は調査・対話・比較・候補・review 等の evidence surface である。
- `report.md` は Outcome / Verification / Residual Risks or Follow-ups の薄い result summary であり、空でも valid である。
- Source artifact 上で user-adopted と記録された判断を、本 bundle の未レビュー状態と混同しない。`source_decision_status=adopted` と `bundle_reflection_status=unreviewed` を分ける。
- Runtime の `ready` は dependency-only。Planning handoff の妥当性は文書レビュー上の contract であって Runtime state ではない。

# 8. Compatibility requirements

- Existing node ID、parent chain、GitHub issue number、dependency metadata、canonical file path を保持する。
- Existing canonical R/D/P/Report、Artifact、Discussion、ADR、profile-derived document、`.assurance.json` を package update で内容変更しない。
- Current creation を閉じた historical artifact type を malformed 扱いしない。
- Existing heavy Report を parse して gate を再開しない。
- Generated state は source metadata から再生成可能にする。generated view を historical truth としない。
- Update prune は managed inventory と ownership boundary に限定し、user-owned path を削除しない。
- Partial failure は再実行可能な状態と診断を残す。

# 9. Epic acceptance criteria

以下は将来の検証条件であり、達成済みの主張ではない。

1. Removed runtime command / registry key / module / docs entry / managed skill が Current surface から消え、alias fallback もない。
2. `active set` は selection-only、`issue start` は unfinished guard と dependency を確認、`--force` は unfinished guard だけを迂回する。
3. `issue finish` は close / clear / sync の順序と partial-failure contract を満たし、quality evidence を読まない。
4. Artifact type omitted と explicit `blank` が動き、Current 6 種だけを作成できる。Historical type は認識されるが新規作成できない。
5. Generic file import は一ファイルだけを opaque に保存し、provider-specific import route は存在しない。
6. Fresh node は単一 R/D/P と薄い Report を持ち、Report 空状態で validate、active、deps、start、finish が Report gate によって失敗しない。
7. Issue Plan は一つで、Base Guide と 4 Completion Guide が存在し、Runtime に Planning Level code / metadata がない。
8. Repo-local skill は Core / Kit を案内し、正本自動変更、provider-owned AI invocation、quality gate を行わない。
9. Fresh / update / uninstall の consumer matrix が historical preservation と obsolete managed asset prune を検証する。
10. Provider / dogfood / installed parity、internal link、forbidden-current-vocabulary、removed-surface absence が検証される。
11. 各 implementation Issue は自身の code / test / docs / migration or compatibility を閉じ、handoff contract を生成する。
12. proposed final candidate は全 implementation Issue に依存し、full regression、cross-slice integration、defect-only repair、PR delivery evidence を独立に扱う。

# 10. Risks and safeguards

| Risk | Safeguard |
|---|---|
| Workflow を削除した結果、構造 invariant まで失う | Storage Core retain inventory と removed inventory を別表で固定し、negative test を置く |
| 357 / 358 の shared file conflict | 357 は mechanism、358 は template / guide content を所有し、IC-1 で contract fixture を統合する |
| Historical type を unknown として壊す | current creatable と historical recognizable を別 API / test matrix にする |
| Update が user data を削除する | managed ownership manifest、preflight、dry inventory、preservation fixtures、partial-failure recovery |
| Docs-only Level が Runtime featureへ再侵入する | forbidden-code / metadata scan と behavior invariance test |
| 360 に最終品質が埋もれる | proposed final candidate を 357–360 の後段に置く |
| Evidence が正本として誤用される | 全出力に evidence-only metadata と self-claim prohibition を持たせる |

# 11. Human decisions remaining

採用済み判断は再確認対象ではない。残る human action は次に限定する。

- この vertical-slice remap を canonical replacement 作業の入力として採用するか。
- proposed final candidate を実 Issue として作成し、numeric ID / GitHub linkage を割り当てるか。
- 実装着手前に、各 Issue の exact file inventory と shared-file ownership を review するか。

これらが未実施でも、本 bundle は planning evidence として読めるが、実装着手可を意味しない。
