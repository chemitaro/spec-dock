---
authority: evidence_only
adoption_status: unreviewed
bundle_generation_not_promotion: true
document_status: candidate
document_role: "epic_plan_candidate"
title: "epic-00356 SpecDock Core Simplification and External Intelligence Boundary — Vertical Slice Plan Candidate"
target: "epic-00356"
source_repository: "chemitaro/spec-dock"
source_branch: "main"
source_sha: "2c75e0c02cb65a6e74040a72dc161d342d661091"
generated_on: "2026-08-09"
---

> この文書は human review 用の evidence-only candidate であり、正本への採用、レビュー合格、実装着手可、PR準備完了、merge可能、Issue終了、Epic完了を表さない。

# 1. Planning stance

本計画は existing Issue ID、GitHub linkage、history、dependency edge を維持しつつ、各 Issue を end-to-end vertical slice として再定義する。Issue draft は evidence only であり、canonical replacement でも execution-ready でもない。

Runtime の `ready` は dependency-only のまま維持する。本計画でいう **planning handoff readiness** は human review 用の文書 contract であり、Runtime state、gate、metadata ではない。

# 2. Tranches

| Tranche | Work item | Goal | Parallelism | Exit evidence |
|---|---|---|---|---|
| T0 — Contract preparation | Epic / Issue candidate review | 採用済み判断、vertical slice、ownership、dependencies を固定する | docs-only | human disposition、source identity、shared-file map |
| T1 — Parallel foundation slices | `iss-00357` + `iss-00358` | Storage Core user flow と Authoring Kit user flow を個別に成立させる | 並行可 | targeted tests、removal / asset inventory、IC-1 inputs |
| IC-1 — Core / Kit checkpoint | 357 + 358 integration | scaffold、Artifact catalog、Report contract、help / docs wording を一致させる | joint | contract matrix、provider / dogfood fixture、conflict resolution |
| T2 — Integration skill slice | `iss-00359` | 二つの repo-local skill から Core / Kit を end-to-end 利用できるようにする | T1 後 | skill tests、no-write negatives、legacy handoff inventory |
| IC-2 — Skill checkpoint | 359 integration | installable skill set と docs pointers を固定する | joint | skill catalog、guide links、absence matrix |
| T3 — Distribution slice | `iss-00360` | Fresh / update / uninstall を通じて Target distribution へ切り替える | T2 後 | consumer matrix、migration / rollback evidence、IC-3 input |
| IC-3 — Consumer checkpoint | 360 integration | provider / dogfood / installed contracts と historical preservation を確認する | joint | fresh / existing / uninstall reports、parity and preservation hashes |
| T4 — Proposed final slice | `proposed-final-quality-integration-delivery` | 全 implementation slice の final quality、integration、defect-only repair、mergeable PR delivery evidence | 357–360 後 | full suite、cross-slice smoke、diff audit、PR handoff package |

# 3. Dependency graph

Existing direct edges を維持する。

| Work item | Direct dependencies | Rationale |
|---|---|---|
| `iss-00357` | none | Runtime mechanism を独立に定義・実装できる |
| `iss-00358` | none | Authoring semantics / assets を独立に定義・実装できる |
| `iss-00359` | `iss-00357`, `iss-00358` | Stable Core command と Kit guide / template contract の両方を消費する |
| `iss-00360` | `iss-00357`, `iss-00358`, `iss-00359` | Runtime、assets、skills の完成 inventory を package cutover する |
| proposed final candidate | `iss-00357`, `iss-00358`, `iss-00359`, `iss-00360` | 全 implementation slice の統合結果を独立に検証する |

`iss-00357` と `iss-00358` は parallel workstream。ただし shared contracts は IC-1 で必ず統合する。Dependency edge がないことを shared-file conflict がないことと混同しない。

# 4. Slice plans and end-to-end demonstrations

## 4.1 `iss-00357` — Storage Core user flow

Demonstration:

1. Fresh fixture を Assurance / Profile なしで作成する。
2. blocked Issue を `active set` で選択できる。
3. `issue start` が unfinished guard と dependency を評価し、`--force` が dependency を迂回しない。
4. Artifact type omitted / explicit blank / typed 5種 / generic file import を実行する。
5. `issue finish` が GitHub close、active clear、post-sync を順番に行い、Report / Review / EAL を読まない。
6. Historical `.assurance.json`、draft / repair Artifact、heavy Report があっても Core operation が旧 workflow gate を再開しない。
7. Removed command は help / parser / registry から不在である。

## 4.2 `iss-00358` — Authoring Kit user flow

Demonstration:

1. Initiative / Epic / Issue template から single R/D/P + thin Report を生成する。
2. Common Guide と scope-specific guidance で R/D/P responsibility を理解できる。
3. Issue `plan.md` は一つで、Base Guide + selected Completion Guide を参照できる。
4. Current six Artifact types の用途と canonical reflection 先が明確である。
5. Current navigation は旧 workflow / phase promotion / profile / EAL / PR readiness を正規経路として案内しない。
6. Provider / dogfood parity、link、catalog、forbidden-current-vocabulary tests が通る。
7. Existing node-local documents の bytes は変更されない。

## 4.3 `iss-00359` — Repo-local skill user flow

Demonstration:

1. `spec-dock` skill が current scope、canonical docs、Artifact、deps、CLI help を案内する。
2. Agent が deterministic CLI で構造操作を行い、planning / review gate を偽装しない。
3. Explicit `spec-dock-grill-with-docs` が local context を読み、exactly one evidence Artifact を残す。
4. Skill は canonical R/D/P を自動変更しない。
5. External capability unavailable case は no-write + explicit next action になる。
6. Old managed workflow skill contract を新 skill から参照しない。
7. skill tests と docs link tests が成立する。

## 4.4 `iss-00360` — Distribution migration user flow

Demonstration:

1. Fresh init が Target assets だけを配布する。
2. Existing update が obsolete managed assets を prune し、node-local specs / evidence / historical data を保持する。
3. Uninstall が managed boundary 内を除去し、user-owned specs を削除しない。
4. provider / dogfood / installed consumer の target inventory が一致する。
5. interrupted update / prune が診断可能かつ再実行可能である。
6. migration guide、release impact、removed command guidance が current docs と一致する。
7. 357–359 の integrated smoke が package consumer で動く。

## 4.5 Proposed final — Quality / integration / PR delivery

Demonstration:

1. 357–360 の integrated branch / candidate を一つの source identity で固定する。
2. Full test suite、static checks、package build、fresh / update / uninstall matrix、cross-slice smoke を実行する。
3. Removed surface absence と historical preservation を独立に再確認する。
4. Failure があれば feature scope を増やさず defect-only repair を行う。
5. Diff、generated changes、docs、migration notes、commit boundaries を audit する。
6. Mergeable PR delivery に必要な evidence を組み立てる。ただし evidence が揃う前に PR-ready / merge-ready を自己主張しない。

# 5. Issue planning handoff readiness contract

各 Issue が implementation handoff 候補になるための文書上の条件。Runtime `ready` とは無関係。

- Requirement / Design / Plan が placeholder ではなく、Issue-specific content を持つ。
- source identity、existing ID、GitHub linkage、dependency edge が一致する。
- 採用済み判断を未決化・逆転していない。
- End-to-end user-observable outcome と negative outcome が明示される。
- code、tests、docs、migration or compatibility が同じ Issue scope にある。
- owner / non-owner surface と shared-file protocol が明示される。
- acceptance、failure、rollback / recovery、historical preservation が testable である。
- unresolved human decision がある場合は blocking / non-blocking と判断者を明示する。
- Issue completion を Report / EAL / reviewer gate に依存させない。
- Level を選ぶ場合は docs-only recommendation と rationale を `plan.md` に書き、Runtime state にしない。
- implementation file inventory は exact branch 上で再確認する。
- 本 bundle の draft だけではこの contract を満たしたと判定しない。

# 6. Integration checkpoints

## IC-0 — Candidate review

Inputs:

- exact source identity
- adoption map
- vertical slice index
- responsibility boundary
- Issue drafts
- proposed final candidate

Checks:

- ID / linkage preservation
- no adopted-decision regression
- no authority self-claim
- no hidden new horizontal Issue
- final candidate depends on all implementation Issues

## IC-1 — Core / Kit contract

Freeze only these shared contracts:

- Fresh node files: one R/D/P + thin Report
- Report path / minimal headings / empty-valid semantics
- Current six Artifact types and exact spelling
- Historical recognition policy
- optional positional Artifact type and blank filename rule
- Authoring docs paths
- Runtime non-involvement in Planning Level
- provider / dogfood fixture shape

Do not use IC-1 to reintroduce a shared workflow state machine.

## IC-2 — Skills contract

Freeze:

- managed skill names and entry files
- `spec-dock` inputs / outputs / no-go behaviors
- `spec-dock-grill-with-docs` explicit invocation / exactly-one evidence output / no canonical mutation
- guide paths and CLI help references
- missing external capability behavior
- legacy skill removal handoff to 360

## IC-3 — Distribution contract

Freeze:

- fresh installed inventory
- update prune inventory
- preserve inventory
- uninstall boundary
- provider / dogfood / installed parity definition
- migration / recovery messages
- integrated smoke entrypoints

## IC-4 — Final exit review

Performed only in proposed final candidate after all implementation Issues.

- exact integrated source identity
- all required suites and consumer matrices
- unresolved defect list
- docs / migration / changelog consistency
- generated / managed asset diff audit
- PR assembly and independent review evidence
- no success self-claim without evidence

# 7. Test strategy by tranche

| Test family | 357 | 358 | 359 | 360 | Final |
|---|---:|---:|---:|---:|---:|
| Unit / domain | primary | targeted | targeted | targeted | rerun |
| CLI parser / registry | primary | absence scan | consumes | installed smoke | rerun |
| lifecycle failures | primary | no gate invariant | consumes | installed smoke | rerun |
| artifact safety / import | primary | semantic catalog | consumes | installed smoke | rerun |
| template / link / vocabulary | contract fixture | primary | pointers | packaged parity | rerun |
| skill behavior | no | no | primary | installed smoke | rerun |
| fresh / update / uninstall | fixture only | preservation fixture | skill inventory | primary | primary rerun |
| historical compatibility | Runtime primary | docs primary | non-regression | consumer primary | cross-check |
| full regression / build | affected suite | affected suite | affected suite | broad suite | primary |
| PR / diff audit | no | no | no | handoff | primary |

# 8. Rollout and docs impact

## 8.1 Rollout order

1. Merge / integrate 357 and 358 contracts.
2. Integrate 359 against stable Core / Kit.
3. Cut distribution through 360.
4. Run proposed final quality / integration / delivery slice.
5. Only after human review, perform release / PR decisions outside this bundle.

## 8.2 Docs to replace or reroute

- Current docs entrypoint from workflow / phase promotion / ChatGPT planning pack to Storage Core + Authoring Kit
- CLI reference removing assurance / authoring / guidance / workflow / delegated-authoring / provider-specific import
- Authoring overview and R/D/P/Report guides
- Planning Level Completion Guides
- Artifact Current / Historical catalog
- Issue lifecycle reference
- migration / compatibility guide
- skill entrypoint guide
- update / uninstall recovery

Historical docs may remain in existing repositories as evidence but must not be linked as Current contract.

## 8.3 Release communication

Explain:

- what disappeared
- retained Core commands and semantics
- new Artifact syntax
- Planning Level is documentation-only
- Report is always present but optional-content and non-gating
- existing evidence is preserved
- update / uninstall ownership boundaries
- external Intelligence is operator-owned and replaceable

# 9. Rollback and recovery

| Stage | Rollback / recovery |
|---|---|
| 357 Runtime | revert provider Runtime changes; preserve user data; use targeted fixtures to confirm no format migration occurred |
| 358 assets | revert managed template / docs source; do not overwrite existing node-local docs |
| 359 skills | restore previous provider skill inventory only before 360 cutover; no canonical doc conversion |
| 360 distribution | stop before ambiguous delete; restore package asset inventory; use retry marker / diagnostic for partial update |
| final candidate | revert defect-only integration commits individually; do not reopen feature scope silently |

No stage may claim rollback safety without running the corresponding test or explicitly stating forward-recovery-only behavior.

# 10. Final exit contract

This is the evidence required from the proposed final candidate; it is not currently satisfied by this planning bundle.

- All four implementation Issues are integrated at exact reviewed commits.
- Full test suite and required static / package checks have recorded outcomes.
- Fresh install, existing update, uninstall, provider / dogfood / installed parity matrices are complete.
- Historical fixtures prove preservation of node IDs、GitHub linkage、R/D/P/Report、Artifact、Discussion、ADR、`.assurance.json`。
- Removed parser / registry / module / docs / skill / template surfaces are absent with no fallback.
- Thin lifecycle and Artifact semantics pass positive and negative tests.
- Planning Level has no Runtime / metadata implementation.
- External capability absence does not break Core or cause canonical writes.
- Docs, migration, CLI help, skill guidance, release impact are consistent.
- Residual risks and deferred non-blockers are explicit.
- Diff audit finds no accidental generated files、secret、raw transcript、local absolute path、binary、hidden managed payload。
- PR assembly has coherent scope and commit history, with independent review evidence.
- Human remains the authority for canonical adoption、PR submission、merge、Issue close、Epic completion。

# 11. Human actions

- Review this candidate package.
- Decide whether to adopt the vertical-slice remap.
- Create and number the proposed final Issue only after adoption.
- Assign exact implementation branches / commits through the normal repository workflow.
