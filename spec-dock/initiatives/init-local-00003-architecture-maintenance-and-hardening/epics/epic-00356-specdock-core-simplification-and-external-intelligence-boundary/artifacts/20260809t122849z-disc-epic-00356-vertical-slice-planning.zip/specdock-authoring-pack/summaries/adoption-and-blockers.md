---
authority: evidence_only
adoption_status: unreviewed
bundle_generation_not_promotion: true
title: "Epic 00356 Adoption and Blockers"
source_repository: "chemitaro/spec-dock"
source_branch: "main"
source_sha: "2c75e0c02cb65a6e74040a72dc161d342d661091"
generated_on: "2026-08-09"
---

> 本書はsource decisionとbundle statusを分離する。採用済みなのはProduct Ownerの明示判断であり、このbundleの文書はすべて未レビューのevidence-only candidateである。

# Adoption and Blockers

## 1. Status legend

- **◆ Source decision: adopted** — 提示されたrepository evidence／strict wrapper summary上で採用済み。再質問で未決へ戻さない。
- **□ Bundle reflection: unreviewed** — 本bundleがその判断をどう反映したかはHuman review前。
- **△ Human action required** — canonical write、Issue creation、dependency mutation、review、implementation、PR／mergeに進むには別の明示操作が必要。

## 2. Source-adopted decisions

| ID | ◆ Adopted decision | □ Bundle reflection |
|---|---|---|
| AD-001 | Runtime workflow／Profile／Assurance削除 | Epic／357／360 candidateへ反映、未レビュー |
| AD-002 | Planning Level docs-only、一つのIssue plan、Base + 4 Completion Guides | 358／359 candidateへ反映、未レビュー |
| AD-003 | issue finish = close → clear → post-sync、quality gateなし | 357 candidateへ反映、未レビュー |
| AD-004 | active set selection-only、startだけがunfinished guard + dependency ready、readyはdependency-only | 357 candidateへ反映、未レビュー |
| AD-005 | optional positional type、blank default、six Current types、no analysis、historical preserve | 357／358 candidateへ反映、未レビュー |
| AD-006 | import file-only | 357／360 candidateへ反映、未レビュー |
| AD-007 | Fresh thin Report常設、空valid、non-gating、Existing body preserve | 357／358／360 candidateへ反映、未レビュー |
| AD-008 | repair badge／draft Current surface削除 | 357／358／360 candidateへ反映、未レビュー |
| AD-009 | durable decisionはR/D/Pまたはaccepted ADR | 全candidateとHTMLへ反映、未レビュー |

Machine-readable map: `adoption/adoption-map.json`。

## 3. Current blockers to canonical use

1. **Bundle status:** 全文書の`authority=evidence_only`、`adoption_status=unreviewed`。canonical filesへ未反映。
2. **Source staleness:** source branch tipが`2c75e0c02cb65a6e74040a72dc161d342d661091`から変われば再調査が必要。
3. **Canonical consistency:** Epic／Issue whole-file replacement後にfresh defect reviewが必要だが、本bundleはその結果を含まない。
4. **Issue readiness:** 357–360のdraftはexecution-readyではない。Humanがscope、acceptance、tests、migration、dependencyを採用して初めて次工程候補になる。
5. **Proposed final Issue:** numeric ID、GitHub linkage、canonical dependency edgeがない。Humanが採用しない限り作成しない。
6. **Implementation evidence:** code change、test run、consumer smoke、package build、PR diffは本bundleに含まれない。
7. **Inventory freshness:** managed assets／Runtime files／testsは実装開始時にexact branch上で再inventoryする。

## 4. Non-blocking assumptions inside the candidate

- 既存ID 357–360とGitHub linkageを維持する。
- 357と358はownershipを守れば並行可能。
- 359は357／358後、360は357／358／359後。
- Proposed final candidateは全implementation slice後。
- Existing canonical／historical contentは自動rewriteしない。
- Final delivery candidateはfeature scopeを拡大せず、defect-only repairを所有する。

これらはbundle内planning assumptionであり、canonical adoptionではない。

## 5. Next Human decisions

| Decision | Options | Consequence |
|---|---|---|
| Epic candidate whole-file adoption | adopt／revise／reject | Canonical Epic R/D/Pの内容を決める |
| Existing Issue remap | adopt／revise per Issue | 357–360のend-to-end acceptanceとownershipを決める |
| Proposed final candidate | create later／merge responsibility elsewhere／reject | Numeric IDとGitHub dependencyを作るかを決める |
| Parallel start of 357／358 | allow after IC-0／serialize | Shared fixture／docs conflict riskを制御する |
| Migration policy for ambiguous modified managed assets | preserve-and-warn／fail-fast／explicit override design | 360のupdate／uninstall safety contractを確定する |
| External grill capability packaging | required external prerequisite／optional capability with explicit stop | 359／360のinstall and failure behaviorを確定する |

## 6. Claims deliberately not made

本bundleはcanonical adoption、review pass、implementation readiness、PR readiness、merge readiness、Issue finish、Epic completionを主張しない。Source-adopted decisionを記録していることと、生成候補が採用済みであることは別である。
