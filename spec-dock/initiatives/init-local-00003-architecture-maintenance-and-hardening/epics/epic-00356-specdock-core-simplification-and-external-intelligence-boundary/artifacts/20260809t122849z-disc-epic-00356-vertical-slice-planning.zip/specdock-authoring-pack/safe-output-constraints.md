---
authority: evidence_only
adoption_status: unreviewed
bundle_generation_not_promotion: true
title: "Safe Output Constraints"
source_repository: "chemitaro/spec-dock"
source_branch: "main"
source_sha: "2c75e0c02cb65a6e74040a72dc161d342d661091"
generated_on: "2026-08-09"
---

# Safe Output Constraints

## 1. Archive contract

- The only deliverable archive is a ZIP whose root is `specdock-authoring-pack/`.
- Every archive entry is a regular UTF-8 text file with mode `0644`.
- No nested archive, binary payload, executable bit, symlink, device, FIFO, hidden archive path, absolute archive path, or `..` path segment is permitted.
- Allowed file suffixes are `.json`, `.md`, and `.html`.
- `manifest.json` lists every entry. Its own hash is intentionally null because a manifest cannot stably contain its own cryptographic hash.

## 2. Content exclusions

- No raw transcript.
- No conversation locator or conversation URL.
- No session identifier or connector response identifier.
- No local absolute path.
- No secret, credential, token, private key, or environment dump.
- No remote image, external CSS, external JavaScript, CDN, or executable HTML script.
- Repository source paths may be named as evidence inventory; those names do not create hidden archive entries.

## 3. Authority and status

- `authority=evidence_only`
- `adoption_status=unreviewed`
- `bundle_generation_not_promotion=true`
- Issue drafts and the HTML are non-canonical evidence.
- Source-recorded Product Owner decisions remain marked adopted, while every generated reflection remains unreviewed.
- This package does not claim canonical adoption, review pass, implementation readiness, PR readiness, merge readiness, Issue finish, or Epic completion.

## 4. Write boundary

- Bundle generation performs no repository write, GitHub Issue mutation, dependency mutation, branch operation, commit, PR operation, merge, close, or completion transition.
- The proposed final work item has no numeric ID and no GitHub linkage.
- Canonical adoption and all execution actions require a separate Human-controlled workflow against a freshly verified source identity.

## 5. Integrity checks

Before delivery, the generator validates:

1. all required paths exist;
2. all JSON parses;
3. all text decodes as UTF-8 and contains no NUL byte;
4. all archive paths remain under the required root and contain no hidden or traversal segment;
5. the Epic design contains one to three PlantUML blocks and currently contains exactly three;
6. the HTML contains at least three inline SVGs, print CSS, navigation, tables, no script, and no external resource reference;
7. forbidden transcript／session／local-path patterns are absent;
8. the ZIP entry count and manifest entry count agree.
