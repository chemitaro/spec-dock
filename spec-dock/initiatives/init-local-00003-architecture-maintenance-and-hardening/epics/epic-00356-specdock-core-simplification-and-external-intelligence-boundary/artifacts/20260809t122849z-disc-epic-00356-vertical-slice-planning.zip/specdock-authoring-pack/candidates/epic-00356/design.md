---
authority: evidence_only
adoption_status: unreviewed
bundle_generation_not_promotion: true
document_status: candidate
document_role: "epic_design_candidate"
title: "epic-00356 SpecDock Core Simplification and External Intelligence Boundary — Design Candidate"
target: "epic-00356"
source_repository: "chemitaro/spec-dock"
source_branch: "main"
source_sha: "2c75e0c02cb65a6e74040a72dc161d342d661091"
generated_on: "2026-08-09"
---

> この文書は human review 用の evidence-only candidate であり、正本への採用、レビュー合格、実装着手可、PR準備完了、merge可能、Issue終了、Epic完了を表さない。

# 1. Design summary

Target architecture は、安定した構造責務と変化の速い認知責務を分離する。

- **Storage Core** は deterministic structure operations と invariants を所有する。
- **Authoring Kit** は文書の意味、薄い template、詳細 guide を所有する。
- **Repo-local skills** は Core / Kit への navigation と explicit operator action を支援する。
- **External Intelligence** は operator-owned client であり、Runtime adapter、authority、gate ではない。
- **Local Spec Graph + GitHub linkage** が durable work structure である。
- **Artifact / Report** は evidence / result summary。Durable decision は R/D/P または accepted ADR へ置く。

# 2. Diagram 1 — Product boundary

- **Title:** Current workflow-heavy product から Target boundary への分離
- **Question answered:** 何を SpecDock 内に残し、何を外部 client に移すか。
- **Scope:** product responsibility、data flow、authority boundary。
- **Excluded details:** class / function 名、installer file list、test command。
- **Update trigger:** retained / removed responsibility、external client contract、canonical authority が変わるとき。

```plantuml
@startuml
title Epic 00356 - Product Boundary
skinparam componentStyle rectangle
skinparam shadowing false
left to right direction

actor "Human / Operator" as Human
cloud "External Intelligence\nreplaceable, operator-owned" as External
package "Repo-local integration" {
  component "spec-dock skill" as Skill
  component "spec-dock-grill-with-docs" as Grill
}
package "SpecDock Product" {
  component "Storage Core\nstructure + invariants" as Core
  component "Authoring Kit\ntemplates + guides" as Kit
}
database "Local Spec Graph\nnodes / R-D-P / artifacts / deps" as Graph
cloud "GitHub Issues\nlinkage + close state" as GitHub

Human --> External : requests analysis / implementation / review
Human --> Skill : selects structural operation
Human --> Grill : explicitly requests clarification evidence
External --> Kit : reads authoring contract
External --> Graph : reads or edits Markdown under human control
Skill --> Core : invokes deterministic CLI
Grill --> Core : creates exactly one scope-local evidence artifact
Core --> Graph : validates and persists structure
Core --> GitHub : resolves linkage or closes issue
Kit --> Graph : defines fresh scaffold content
@enduml
```

# 3. Diagram 2 — Vertical slices and handoffs

- **Title:** Existing Issue ID を保つ vertical-slice dependency
- **Question answered:** どの Issue がどの end-to-end value を所有し、何を次へ渡すか。
- **Scope:** Issue 357–360、proposed final candidate、integration checkpoints。
- **Excluded details:** intra-Issue task ordering、branch names、commit structure。
- **Update trigger:** Issue dependency、ownership、handoff artifact、final candidate scope が変わるとき。

```plantuml
@startuml
title Epic 00356 - Vertical Slice Dependency and Handoff
skinparam componentStyle rectangle
skinparam shadowing false
left to right direction

component "iss-00357\nStorage Core user flow" as I357
component "iss-00358\nAuthoring Kit user flow" as I358
component "IC-1\nCore-Kit contract" as IC1
component "iss-00359\nRepo-local skill user flow" as I359
component "IC-2\nSkill integration" as IC2
component "iss-00360\nDistribution migration flow" as I360
component "IC-3\nConsumer cutover" as IC3
component "proposed-final\nquality + integration + PR delivery" as Final

I357 --> IC1 : supplies Runtime contract and removal inventory
I358 --> IC1 : supplies template / guide contract and asset inventory
IC1 --> I359 : releases stable Core + Kit inputs
I359 --> IC2 : supplies two-skill contract and legacy handoff
IC2 --> I360 : releases installable asset set
I357 --> I360 : supplies direct compatibility obligations
I358 --> I360 : supplies direct preservation and docs obligations
I360 --> IC3 : supplies fresh / update / uninstall evidence
IC3 --> Final : releases integrated implementation candidate
I357 --> Final : direct dependency retained for audit
I358 --> Final : direct dependency retained for audit
I359 --> Final : direct dependency retained for audit
I360 --> Final : direct dependency retained for audit
@enduml
```

# 4. Diagram 3 — Thin lifecycle and evidence boundary

- **Title:** Active selection、Issue start / finish、Evidence の非ゲート化
- **Question answered:** Runtime が何を判定し、何を判定しないか。
- **Scope:** selection、dependency check、GitHub close、active clear、post-sync、evidence placement。
- **Excluded details:** GitHub API adapter implementation、filesystem transaction primitives、retry backoff。
- **Update trigger:** lifecycle ordering、failure recovery、dependency semantics、Report / Artifact authority が変わるとき。

```plantuml
@startuml
title Epic 00356 - Thin Lifecycle and Evidence Boundary
skinparam shadowing false

actor Operator
participant "active set" as Select
participant "issue start" as Start
participant "Dependency DAG" as Deps
participant "Git / Branch" as Git
participant "Active Store" as Active
participant "issue finish" as Finish
participant "GitHub Issue" as GH
participant "post-sync" as Sync
database "R/D/P or accepted ADR" as Canonical
database "Artifact / thin Report" as Evidence

Operator -> Select : choose any valid scope
Select -> Active : store ID + path only
Operator -> Start : request Issue execution
Start -> Active : check unfinished active Issue guard
Start -> Deps : check dependency-only readiness
Start -> Git : checkout target branch
Start -> Active : set active Issue after checkout
Operator -> Evidence : write research / interview / result summary
Evidence --> Canonical : human-reviewed reflection only
Operator -> Finish : request close convenience operation
Finish -> GH : close linked Issue; already-closed is success
GH --> Finish : close result
Finish -> Active : clear only after close success
Finish -> Sync : regenerate projections after clear
note right of Finish
No quality, review, plan, test,
EAL, authority, or Report gate
end note
@enduml
```

# 5. Responsibility model

## 5.1 Storage Core

Storage Core owns:

- Node identity、parent chain、directory placement、GitHub linkage
- `.meta.json.depends_on` と DAG invariant
- current active ID / path と generated context pointers
- `active set` selection、`issue start` guard + dependency check、thin `issue finish`
- Artifact filename / collision / lock / symlink / path safety
- current creatable type と historical recognizable type の機械契約
- generic one-file import
- node scaffold mechanism
- sync / validate / doctor / worktree / workbench / deterministic mutation
- privacy-safe CLI output と partial-failure diagnostics

Storage Core does not own:

- Planning Level、quality level、review status、implementation readiness
- model / provider / browser / Oracle selection
- evidence adoption、canonical promotion、fresh reviewer gate
- plan / test / report completion judgment
- PR state machine

## 5.2 Authoring Kit

Authoring Kit owns:

- R/D/P/Report の意味と scope layering
- Fresh template content
- Base authoring guides
- one Issue `plan.md` + four Completion Guides
- Artifact type semantics and Current / Historical navigation
- durable decision reflection guidance
- link / vocabulary / template inventory / provider-dogfood parity expectations

Authoring Kit does not own parser、registry、lifecycle、dependency algorithm、installer prune execution。

## 5.3 Repo-local skills

`spec-dock` skill:

- Current scope、parent chain、canonical documents、Artifact、dependency、CLI help の入口
- deterministic CLI を利用する構造操作
- removed workflow を再実装しない
- planning / implementation method を強制しない

`spec-dock-grill-with-docs` skill:

- explicit invocation のみ
- local docs / artifacts を読み、必要な external capability が利用可能なら clarification を支援
- exactly one scope-local evidence Artifact を生成
- R/D/P を自動変更しない
- external capability がない場合、no-write で明示停止
- `analysis` type を作らず、用途に応じ `research` / `interview` / `disc` / `decision-candidate` を使う

## 5.4 Distribution

Installer / updater owns managed asset inventory と prune boundary。Node-local canonical documents と historical evidence は user-owned preservation surface として扱う。Provider source、dogfood、installed consumer は同じ target contract を持つが、既存 user content の byte equality を provider asset parity と混同しない。

# 6. Data and file contracts

## 6.1 Canonical and evidence hierarchy

| Surface | Role | Runtime gate |
|---|---|---|
| Epic / Issue `requirement.md` | why / what / acceptance | none |
| Epic / Issue `design.md` | boundary / structure / contract | none |
| Epic / Issue `plan.md` | sequence / verification / exit | none |
| accepted ADR | durable architecture decision | none |
| Artifact | research / question / synthesis / candidate evidence | none |
| thin `report.md` | optional-content result summary | none |
| `.meta.json.depends_on` | dependency graph source | dependency-only readiness |
| active manifest | selected ID + path | unfinished guard only in `issue start` |

## 6.2 Artifact sets

Conceptual split:

```text
CURRENT_CREATABLE = {
  blank, research, interview, disc, decision-candidate, adr
}

HISTORICAL_RECOGNIZABLE = {
  pr-repair-batch, draft-requirement, draft-design, draft-plan,
  scratch, note, legacy discussions, imported historical forms
}
```

Exact historical inventory は Issue 357 の implementation inventory で固定する。重要なのは「新規作成不可」と「既存認識不可」を同一にしないことである。

CLI target:

```text
spec-dock new artifact [type] --<scope> <id> --title <title> [--slug <slug>]
```

- `[type]` omitted → `blank`
- explicit `blank` accepted
- duplicate `--type` syntax は追加しない
- blank filename に `blank` token を含めない
- import は `artifact import file` のみ

## 6.3 Report

Fresh scope template:

```markdown
# Result Summary

## Outcome

## Verification

## Residual Risks / Follow-ups
```

必要な場合だけ `Notes` を追加する。内容が空でも valid。Existing Report は rewrite しない。Runtime は Report path / contents を lifecycle、dependency、quality、completion 判定へ利用しない。

## 6.4 Planning Level

```text
templates/issue/plan.md
  -> docs/authoring/plan.md
      -> docs/authoring/issue-plan-levels/{light|standard|strict|critical}.md
```

Level selection、理由、risk factor、re-evaluation condition は通常の `plan.md` 本文に書く。Runtime / `.meta.json` / active manifest / dependency projection へ複製しない。History は Git diff。

# 7. Slice ownership and shared-file protocol

| Surface | 357 | 358 | 359 | 360 | Final candidate |
|---|---|---|---|---|---|
| Runtime parser / registry / commands | owns | no edit | consumes | packages | verifies |
| lifecycle / active / deps | owns | documents meaning only | consumes | packages | verifies |
| templates / authoring guides | mechanism only | owns content | consumes | packages | verifies |
| artifact semantics | implements | owns wording | consumes | packages | verifies |
| node scaffold | owns mechanism | owns file content | consumes | packages | verifies |
| repo-local skills | inventory handoff | guide-path handoff | owns | packages / prunes | verifies |
| installer managed inventory | removal inventory | asset inventory | skill inventory | owns | verifies |
| existing consumer preservation | Runtime fixtures | doc fixtures | skill compatibility | owns migration | cross-checks |
| full regression / PR assembly | targeted only | targeted only | targeted only | consumer integration | owns |

Shared-file protocol:

1. 357 / 358 は provider-vs-dogfood paths を別 branch で同時大量編集しない。
2. 357 は Runtime mechanism と contract fixture を作り、Template prose は 358 に残す。
3. 358 は runtime symbol を参照する tests を contract-level に限定し、parser / registry を直接編集しない。
4. IC-1 で scaffold fixture、Artifact catalog、Report path、help wording を統合する。
5. 360 が package inventory を切り替えるまで 359 は obsolete managed skill を物理 prune しない。
6. Final candidate は feature redesign ではなく defect-only integration repair を行う。

# 8. Migration architecture

## 8.1 Fresh consumer

- Target managed assets のみを install
- single R/D/P + thin Report template
- six Current Artifact templates
- Base + four Level Guides
- two repo-local skills
- removed Runtime surface / docs / skill 不在

## 8.2 Existing consumer update

- managed ownership inventory に基づき obsolete managed assets を prune
- existing node-local R/D/P/Report、Artifact、Discussion、ADR、`.assurance.json` を preserve
- generated state は再生成
- missing external capabilities を install blocker にしない
- partial prune / copy failure は retryable diagnostic を残す

## 8.3 Uninstall

- current managed assets と known legacy managed assets を boundary 内で除去
- user-owned specs / evidence を削除しない
- retry marker / recovery contract を維持または簡素化し、silent partial success を避ける

# 9. Failure modes

| Failure | Required behavior |
|---|---|
| GitHub close fails | active を保持し、再実行方法を返す |
| close succeeds but active clear fails | partial success として close 済み可能性、active recovery、再実行を示す |
| post-sync fails after clear | lifecycle close / clear と projection stale を区別する |
| dependency blocked | `issue start --force` でも開始しない |
| blocked Issue selection | `active set` は選択を許可する |
| historical Artifact present | validate を壊さず、新規作成だけ拒否する |
| removed command invoked | unknown command / explicit migration guidance。legacy backend へ fallback しない |
| external grilling unavailable | no canonical write、no misleading success、明示的な operator action |
| update prune ownership ambiguous | fail before delete、inventory evidence を返す |
| existing Report heavy | preserve bytes、Runtime gate を起動しない |

# 10. Verification design

- **Unit:** artifact parser / sets、active data、dependency check、lifecycle ordering、installer inventory functions
- **Application integration:** start / finish failure matrix、generic import、scaffold without Assurance、Context Pack absence of authority
- **CLI:** help inventory、removed command negative tests、optional positional type、privacy-safe output
- **Asset:** template exact catalog、Level Guide links、forbidden Current vocabulary、provider / dogfood parity
- **Consumer:** fresh init、existing update、uninstall、partial failure、historical fixture preservation
- **Skill:** two skills only、no provider-owned AI call、one evidence artifact、no canonical mutation
- **Cross-slice:** Core + Kit + Skills + Distribution end-to-end
- **Delivery:** package build、full suite、diff audit、independent review evidence、mergeable PR assembly in proposed final candidate

# 11. Uncertainty

Exact removed module / test / asset list は source inspection で high-confidence inventory があるが、implementation branch 上の最終 file graph では再計算が必要である。これは Product decision の再質問ではなく、Issue 357 / 360 の mechanical inventory task である。
