# Safe Output Constraints

## Bundle identity

- expected ZIP root: `specdock-authoring-pack/`
- authority: `evidence_only`
- adoption status: `unreviewed`
- bundle generation is not promotion: `true`
- target Issue: `iss-00346`
- repository: `chemitaro/spec-dock`
- branch: `iss-00346-integration-distribution-and-final-quality`
- source revision: `2217889c31e1a8a83732c446264dec00dde77be6`

## Exact permitted entries

```text
specdock-authoring-pack/
  manifest.json
  provenance.json
  source-manifest.json
  stale-if.json
  safe-output-constraints.md
  adoption/
    adoption-map.json
    eal-candidates.json
  drafts/
    requirement.md
    design.md
    plan.md
  summaries/
    onboarding.md
```

No other ZIP entry is permitted.

## Encoding and file type

- Every payload file must decode as strict UTF-8.
- Permitted payload types are Markdown text and JSON text only.
- JSON must parse successfully.
- The outer ZIP is the only archive. Nested archives are forbidden.
- ZIP entries must be regular non-executable files; symlinks and device/special entries are forbidden.
- Directory entries may be omitted. If present, they must be ordinary directories under the exact root.

## Path safety

- No absolute ZIP entry path.
- No `..` segment or path traversal.
- No drive-letter or URI-like ZIP entry path.
- No ZIP entry outside `specdock-authoring-pack/`.
- No hidden ZIP entry segment. Repository paths such as `.workbench/README.md` may be discussed as text inside Markdown; they are not bundle entries.
- File names must match the exact permitted-entry list.

## Forbidden payloads

- raw model, worker, shell, email, or review transcript
- secret, authentication secret, access token, password, private key, session value, cookie, or private connection material
- user-file body, external-source absolute path, or host-local temporary path used during future execution
- binary, executable, compiled object, bytecode, font, image, database, or opaque artifact payload
- nested ZIP/tar/wheel or other archive
- symlink, hard-link instruction, path traversal, or filesystem mutation script

## Forbidden authority claims

The bundle must not state or imply that its generation has performed any of the following:

- 正本への審査済み反映 or promotion
- `.assurance.json` mutation
- `authorized_profile` selection or decision
- required reviewer gate completion
- implementation execution authorization
- PR readiness or pull-request handoff completion
- merge readiness or merge execution
- Issue finish or Epic completion

Future planned gates, stop conditions, and explicit statements that those states still require independent workflow evidence are permitted.

## Evidence handling

- Candidate claims remain unreviewed until Codex records a disposition.
- `adoption/adoption-map.json` and `adoption/eal-candidates.json` must leave disposition fields unset for Codex.
- Source references may contain repository-relative paths and immutable revision identifiers.
- No host-local absolute path may appear in provenance.
- Imported external-file privacy rules prohibit absolute path, body, digest, byte count, and other content-derived values in future user-visible output or tracked provenance. This bundle contains only the planned rule, not any user-file value.
- Candidate-wheel digest is distribution provenance and is distinct from imported external-file content-derived provenance.

## Staleness

The bundle is stale when any condition in `stale-if.json` is met. Stale content must be reinspected and cannot be carried forward as current evidence solely because it remains internally consistent.
